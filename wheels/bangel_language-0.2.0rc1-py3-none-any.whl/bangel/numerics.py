from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from .diagnostics import BangelDiagnostic
from .evaluator import call_builtin
from .values import Quantity


def _series(values: Iterable[Quantity], name: str, minimum: int = 1) -> tuple[Quantity, ...]:
    result = tuple(values)
    if len(result) < minimum or not all(isinstance(item, Quantity) for item in result):
        raise BangelDiagnostic("SERIES_REQUIRED", f"{name} requires at least {minimum} quantities.")
    first = result[0]
    for item in result[1:]:
        first._same_dimension(item)
    return result


def vector_add(left: Iterable[Quantity], right: Iterable[Quantity]) -> tuple[Quantity, ...]:
    lhs, rhs = _series(left, "vector_add"), _series(right, "vector_add")
    if len(lhs) != len(rhs):
        raise BangelDiagnostic("VECTOR_LENGTH", "vector_add requires equal lengths.")
    return tuple(a.add(b) for a, b in zip(lhs, rhs, strict=True))


def finite_difference(xs: Iterable[Quantity], ys: Iterable[Quantity]) -> tuple[Quantity, ...]:
    x_values, y_values = _series(xs, "finite_difference", 2), _series(ys, "finite_difference", 2)
    if len(x_values) != len(y_values):
        raise BangelDiagnostic("SERIES_LENGTH", "finite_difference requires equal series lengths.")
    result: list[Quantity] = []
    for index in range(len(x_values) - 1):
        dx = x_values[index + 1].add(x_values[index], -1)
        if dx.magnitude_si == 0:
            raise BangelDiagnostic("SERIES_INTERVAL", "finite_difference requires nonzero x intervals.")
        result.append(y_values[index + 1].add(y_values[index], -1).multiply(dx, divide=True))
    return tuple(result)


def trapezoid(xs: Iterable[Quantity], ys: Iterable[Quantity]) -> Quantity:
    x_values, y_values = _series(xs, "trapezoid", 2), _series(ys, "trapezoid", 2)
    if len(x_values) != len(y_values):
        raise BangelDiagnostic("SERIES_LENGTH", "trapezoid requires equal series lengths.")
    areas: list[Quantity] = []
    half = Quantity.known(Decimal("0.5"))
    for index in range(len(x_values) - 1):
        dx = x_values[index + 1].add(x_values[index], -1)
        if dx.magnitude_si is not None and dx.magnitude_si <= 0:
            raise BangelDiagnostic("SERIES_ORDER", "trapezoid x values must increase.")
        average = y_values[index].add(y_values[index + 1]).multiply(half)
        areas.append(average.multiply(dx))
    return call_builtin("sum", areas)


def covariance(left: Iterable[Quantity], right: Iterable[Quantity]) -> Quantity:
    lhs, rhs = _series(left, "covariance", 2), _series(right, "covariance", 2)
    if len(lhs) != len(rhs):
        raise BangelDiagnostic("SERIES_LENGTH", "covariance requires equal series lengths.")
    left_mean = call_builtin("mean", list(lhs))
    right_mean = call_builtin("mean", list(rhs))
    products = [a.add(left_mean, -1).multiply(b.add(right_mean, -1)) for a, b in zip(lhs, rhs, strict=True)]
    total = call_builtin("sum", products)
    return total.multiply(Quantity.known(Decimal(1) / Decimal(len(products))))
