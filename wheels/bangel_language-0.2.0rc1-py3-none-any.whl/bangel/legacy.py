from __future__ import annotations

import re
from dataclasses import dataclass

from .diagnostics import BangelDiagnostic, SourceSpan
from .source import logical_lines


_UINT32_MAX = 2**32 - 1
_ROOT = re.compile(r"input ([0-9a-f]{64})")
_OPERATIONS = {
    "observe resource",
    "recommend hagar",
    "verify receipt",
    "acoustic transcript",
}


@dataclass(frozen=True, slots=True)
class LegacyProgram:
    generation: int
    input_root: str
    operations: tuple[str, ...]


def parse_legacy_01(source: str) -> LegacyProgram:
    lines = logical_lines(source)
    if len(lines) < 5 or lines[0].text != "bangel 0.1" or lines[-1].text != "end":
        raise BangelDiagnostic(
            "LEGACY_ENVELOPE",
            "Bangel 0.1 requires header, generation, input, operation(s), and end.",
            SourceSpan(lines[0].number),
        )
    if not lines[1].text.startswith("generation "):
        raise BangelDiagnostic("LEGACY_GENERATION", "Bangel 0.1 requires generation.", SourceSpan(lines[1].number))
    try:
        generation = int(lines[1].text.removeprefix("generation "))
    except ValueError as exc:
        raise BangelDiagnostic("LEGACY_GENERATION", "Generation must be a canonical uint32.", SourceSpan(lines[1].number)) from exc
    if generation < 0 or generation > _UINT32_MAX or str(generation) != lines[1].text.removeprefix("generation "):
        raise BangelDiagnostic("LEGACY_GENERATION", "Generation must be a canonical uint32.", SourceSpan(lines[1].number))
    root = _ROOT.fullmatch(lines[2].text)
    if root is None:
        raise BangelDiagnostic("LEGACY_INPUT", "Input must be a lowercase SHA-256 root.", SourceSpan(lines[2].number))
    operations = tuple(line.text for line in lines[3:-1])
    for line, operation in zip(lines[3:-1], operations, strict=True):
        if operation not in _OPERATIONS:
            raise BangelDiagnostic("LEGACY_OPERATION", f"Unknown Bangel 0.1 operation {operation!r}.", SourceSpan(line.number))
    return LegacyProgram(generation, root.group(1), operations)
