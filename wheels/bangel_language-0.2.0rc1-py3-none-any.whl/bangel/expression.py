from __future__ import annotations

import json
from decimal import Decimal, InvalidOperation

from .ast import Expression
from .diagnostics import BangelDiagnostic
from .lexer import lex_expression
from .tokens import Token, TokenKind
from .units import UNITS


_PRECEDENCE = {
    "or": 5,
    "and": 6,
    "==": 10, "!=": 10, "<": 10, "<=": 10, ">": 10, ">=": 10,
    "+": 20, "-": 20,
    "*": 30, "/": 30,
}


class ExpressionParser:
    def __init__(self, text: str, line: int):
        self.tokens = lex_expression(text, line)
        self.index = 0

    def parse(self) -> Expression:
        expression = self._expression(0)
        token = self._peek()
        if token.kind is not TokenKind.EOF:
            raise BangelDiagnostic("EXPRESSION_TRAILING", "Unexpected trailing expression input.", token.span)
        return expression

    def _peek(self) -> Token:
        return self.tokens[self.index]

    def _take(self) -> Token:
        token = self.tokens[self.index]
        self.index += 1
        return token

    def _expression(self, minimum: int) -> Expression:
        token = self._take()
        if token.kind is TokenKind.OP and token.text in {"+", "-"}:
            left = Expression("unary", token.text, (self._expression(40),), token.span)
        elif token.kind is TokenKind.IDENT and token.text == "not":
            left = Expression("unary", "not", (self._expression(40),), token.span)
        elif token.kind is TokenKind.NUMBER:
            try:
                value = format(Decimal(token.text), "f")
            except InvalidOperation as exc:
                raise BangelDiagnostic("NUMBER_INVALID", "Invalid decimal literal.", token.span) from exc
            unit = "1"
            if self._peek().kind is TokenKind.IDENT and self._peek().text in UNITS:
                unit = self._take().text
            left = Expression("quantity", {"magnitude": value, "unit": unit}, span=token.span)
        elif token.kind is TokenKind.STRING:
            left = Expression("literal", json.loads(token.text), span=token.span)
        elif token.kind is TokenKind.IDENT:
            if token.text in {"true", "false"}:
                left = Expression("literal", token.text == "true", span=token.span)
            elif self._peek().kind is TokenKind.LPAREN:
                self._take()
                arguments: list[Expression] = []
                if self._peek().kind is not TokenKind.RPAREN:
                    while True:
                        arguments.append(self._expression(0))
                        if self._peek().kind is not TokenKind.COMMA:
                            break
                        self._take()
                if self._take().kind is not TokenKind.RPAREN:
                    raise BangelDiagnostic("CALL_CLOSE", "Function call requires ')'.", token.span)
                left = Expression("call", token.text, tuple(arguments), token.span)
            else:
                left = Expression("name", token.text, span=token.span)
        elif token.kind is TokenKind.LPAREN:
            left = self._expression(0)
            if self._take().kind is not TokenKind.RPAREN:
                raise BangelDiagnostic("GROUP_CLOSE", "Grouped expression requires ')'.", token.span)
        elif token.kind is TokenKind.LBRACKET:
            items: list[Expression] = []
            if self._peek().kind is not TokenKind.RBRACKET:
                while True:
                    items.append(self._expression(0))
                    if self._peek().kind is not TokenKind.COMMA:
                        break
                    self._take()
            if self._take().kind is not TokenKind.RBRACKET:
                raise BangelDiagnostic("VECTOR_CLOSE", "Vector literal requires ']'.", token.span)
            left = Expression("vector", operands=tuple(items), span=token.span)
        else:
            raise BangelDiagnostic("EXPRESSION_PRIMARY", "Expected an expression.", token.span)

        while True:
            operator = self._peek()
            is_word_operator = operator.kind is TokenKind.IDENT and operator.text in {"and", "or"}
            if not (operator.kind is TokenKind.OP or is_word_operator) or operator.text not in _PRECEDENCE:
                return left
            precedence = _PRECEDENCE[operator.text]
            if precedence < minimum:
                return left
            self._take()
            right = self._expression(precedence + 1)
            left = Expression("binary", operator.text, (left, right), operator.span)


def parse_expression(text: str, line: int) -> Expression:
    return ExpressionParser(text, line).parse()
