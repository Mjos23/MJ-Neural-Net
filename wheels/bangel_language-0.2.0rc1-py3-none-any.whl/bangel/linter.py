"""Minimum strict-source linter; warnings never alter compiler admission."""
from __future__ import annotations

from .compiler import ElsaCompiler
from .diagnostics import BangelDiagnostic, SourceSpan
from .formatter import format_source


def _finding(code: str, message: str, span: SourceSpan | None, severity: str) -> dict:
    return {'code': code, 'message': message, 'span': span.to_dict() if span else None, 'severity': severity}


def lint_source(source_name: str, source: str) -> list[dict]:
    """Check strict Bangel/1.0, then report deterministic presentation warnings.

    There are no configuration files, inline disables, network reads, or source
    rewrites. Compiler diagnostics are returned as errors, preserving identity.
    """
    try:
        ElsaCompiler().check(source_name, source)
    except BangelDiagnostic as diagnostic:
        return [_finding(diagnostic.code, diagnostic.message, diagnostic.span, 'error')]
    normalized = source.replace('\r\n', '\n').replace('\r', '\n')
    lines = normalized.splitlines()
    findings: list[dict] = []
    blanks = 0
    for number, line in enumerate(lines, 1):
        blanks = blanks + 1 if not line.strip(' ') else 0
        if blanks == 2:
            findings.append(_finding('LINT_BLANK_LINES', 'Use at most one consecutive blank line.', SourceSpan(number), 'warning'))
    try:
        formatted = format_source(source)
    except BangelDiagnostic as diagnostic:
        return [_finding(diagnostic.code, diagnostic.message, diagnostic.span, 'error')]
    actual_lines = [(number, line) for number, line in enumerate(lines, 1) if line.strip(' ')]
    expected_lines = [line for line in formatted.splitlines() if line.strip(' ')]
    for (number, actual), expected in zip(actual_lines, expected_lines, strict=True):
        if actual != expected:
            findings.append(_finding('LINT_FORMAT', 'Source presentation differs from the canonical formatter.', SourceSpan(number), 'warning'))
            break
    if not normalized.endswith('\n'):
        findings.append(_finding('LINT_FINAL_NEWLINE', 'End source with a line feed.', SourceSpan(len(lines), len(lines[-1]) + 1), 'warning'))
    return sorted(findings, key=lambda item: (item['span']['line'], item['span']['column'], item['code']))
