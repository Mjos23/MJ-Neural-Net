"""Independent B03.2 relationships after closed structural admission.

This module consumes only JP-IR records. It never calls Elsa's frontend,
semantic analyzer or lowerer and does not execute Joanna operations.
"""
from __future__ import annotations

from bisect import bisect_right
from typing import Any

from .canonical import canonical_bytes
from .diagnostics import BangelDiagnostic


STANDARD_EXPORTS = {
    'std.math': ('abs', 'min', 'max', 'sqrt'),
    'std.vector': ('length', 'at', 'sum', 'mean', 'dot', 'norm', 'moving_mean', 'slope'),
    'std.map': ('length', 'at', 'keys', 'values'),
    'std.topology': ('node_variance', 'dampen', 'step_cap', 'bound', 'shadow_speed', 'floor_challenge'),
}
CORE = ('is_known', 'nominal', 'uncertainty', 'convert')


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise BangelDiagnostic('IR_CROSS_FIELD', message)


def _fits(actual: dict, expected: dict) -> bool:
    from .ir_types import assignable
    return assignable(actual, expected)


def _unique(items: list, label: str) -> None:
    _require(len(items) == len(set(items)), f'{label} must be unique.')


def _position(value):
    return value['span']['line'], value['span']['column']


def _source_order(items, label):
    positions = [_position(item) for item in items]
    _require(positions == sorted(set(positions)), f'{label} must retain distinct source declaration order.')


def _symbol(name, kind, value_type, target, span=None, mutable=False):
    return dict(name=name, kind=kind, type=value_type, target=target,
                span=span, mutable=mutable)


def _walk(value):
    if isinstance(value, dict):
        yield value
        for nested in value.values():
            yield from _walk(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from _walk(nested)


def verify_crossfields(root: dict[str, Any]) -> None:
    if not root['analysis']:
        if root['source']['profile'] != 'bangel 0.1':
            _verify_compatibility(root)
        return
    modules = root['modules']
    _unique([m['name'] for m in modules], 'Module names')
    _unique([m['source']['name'] for m in [*modules, root]], 'Source labels')
    _require(not modules or root['analysis']['source_kind'] == 'program',
             'A linked entry must be a program.')
    module_map = {m['name']: m for m in modules}
    fragments = [*modules, root]
    definitions: dict[str, dict] = {}
    functions: dict[str, dict] = {}
    owners = {id(m): (m['name'] if m is not root else
              root['program'] if root['analysis']['source_kind'] == 'module' else
              'program.' + root['program']) for m in fragments}

    # Declare all nominal and function identities before checking references.
    for fragment in fragments:
        owner = owners[id(fragment)]
        names = []
        _source_order(fragment['type_definitions'], 'Definitions')
        for definition in fragment['type_definitions']:
            _require(fragment['analysis']['source_kind'] != 'program' or not definition['exported'],
                     'Programs cannot contain exported definitions.')
            names.append(definition['name'])
            target = owner + '.' + definition['name']
            _require(definition['identity'] == target and target not in definitions,
                     'A definition must have one correctly owned identity.')
            definitions[target] = definition
            groups = ([definition] if definition['kind'] == 'record' else
                      definition['variants'])
            if definition['kind'] == 'enum':
                _unique([v['name'] for v in groups], 'Enum variants')
                _source_order(groups, 'Enum variants')
            for group in groups:
                _unique([f['name'] for f in group['fields']], 'Definition fields')
                _source_order(group['fields'], 'Definition fields')
                _require(all(_position(group) < _position(field) for field in group['fields']),
                         'Field spans must follow their containing declaration.')
            _require(all(group is definition or _position(definition) < _position(group) for group in groups),
                     'Variant spans must follow their enum declaration.')
        for instruction in fragment['instructions']:
            if instruction['kind'] == 'function':
                target = owner + '.' + instruction['name']
                _require(instruction['details']['target'] == target and target not in functions,
                         'A function must have one correctly owned target.')
                names.append(instruction['name'])
                functions[target] = instruction
        _unique(names, 'Declaration names')

    # Nominal definitions form a finite, closed acyclic graph.
    dependencies = {}
    for target, definition in definitions.items():
        dependencies[target] = {
            node['identity'] for node in _walk(definition)
            if node.get('kind') in {'Record', 'Enum'}
        }
        _require(dependencies[target] <= definitions.keys(), 'A nominal type must resolve.')
    _acyclic_depths(dependencies, ceiling=None)

    # Deterministic lexicographic dependency-first postorder, including unused modules.
    edges = {name: {i['module'] for i in m['imports'] if i['kind'] == 'project'}
             for name, m in module_map.items()}
    for name, children in edges.items():
        _require(children <= module_map.keys(), f'Module {name} has an unresolved import.')
    expected_order = []
    active, complete = set(), set()

    def visit(name):
        _require(name not in active, 'Module import cycle.')
        if name in complete:
            return
        active.add(name)
        for child in sorted(edges[name]):
            visit(child)
        active.remove(name)
        complete.add(name)
        expected_order.append(name)

    for name in sorted(module_map):
        visit(name)
    _require([m['name'] for m in modules] == expected_order,
             'Linked modules must have canonical dependency-first order.')

    exports = {}
    for m in modules:
        items = m['exports']
        _require(items == sorted(items, key=lambda x: (x['target'] or '', x['kind'], x['name'])),
                 'Module exports must use canonical order.')
        _unique([x['name'] for x in items], 'Export names')
        _unique([x['target'] for x in items], 'Export targets')
        exports[m['name']] = {x['name']: x for x in items}

    graph = {target: set() for target in functions}
    for fragment in fragments:
        _verify_fragment(fragment, owners[id(fragment)], module_map, exports,
                         definitions, functions, graph)
    depths = _acyclic_depths(graph, ceiling=64)
    for target, instruction in functions.items():
        _require(instruction['details']['call_depth'] == depths[target],
                 'Function call_depth must equal the resolved acyclic call graph.')
    for fragment in fragments:
        local = [i['details']['target'] for i in fragment['instructions'] if i['kind'] == 'function']
        _require(fragment['analysis']['maximum_call_depth'] == max((depths[t] for t in local), default=0),
                 'Analysis maximum_call_depth must equal the maximum local function depth.')


def _acyclic_depths(graph, *, ceiling):
    # Iterative leaf removal bounds Python stack use even for a hostile long
    # nominal dependency chain. Container depth is a different resource bound.
    depths = {target: 1 for target in graph}
    parents = {target: [] for target in graph}
    pending = {target: len(children) for target, children in graph.items()}
    for target, children in graph.items():
        for child in children:
            _require(child in graph, 'Unresolved dependency target.')
            parents[child].append(target)
    ready = [target for target, count in pending.items() if count == 0]
    completed = 0
    while ready:
        child = ready.pop()
        completed += 1
        _require(ceiling is None or depths[child] <= ceiling,
                 'Function depth exceeds the frozen ceiling.')
        for parent in parents[child]:
            depths[parent] = max(depths[parent], depths[child] + 1)
            pending[parent] -= 1
            if pending[parent] == 0:
                ready.append(parent)
    _require(completed == len(graph), 'Recursive dependency is not admitted.')
    return depths


def _verify_fragment(fragment, owner, modules, exports, definitions, functions, graph):
    analysis = fragment['analysis']
    if analysis['source_kind'] == 'module':
        _require(fragment['effects'] == ['pure'] and
                 all(i['kind'] in {'function', 'let', 'derive'} for i in fragment['instructions']),
                 'Modules admit pure declarations and immutable bindings only.')
        _require(bool(fragment['type_definitions'] or fragment['instructions']), 'Modules cannot be empty.')
        if 'exports' in fragment:
            _require(bool(fragment['exports']), 'Linked modules require at least one export.')
    _require(analysis['declared_effects'] == fragment['effects'], 'Declared effect metadata disagrees.')
    inferred = ['pure', 'evidence'] if any('evidence' in i['effects'] for i in fragment['instructions']) else ['pure']
    _require(analysis['inferred_effects'] == inferred == fragment['effects'],
             'Inferred, declared and instruction effects disagree.')
    references = {canonical_bytes(x) for x in analysis['references']}
    conversions = {canonical_bytes(x) for x in analysis['conversions']}
    _require(len(references) == len(analysis['references']), 'Duplicate analysis reference.')
    _require(len(conversions) == len(analysis['conversions']), 'Duplicate analysis conversion.')
    used_references, used_conversions = set(), set()
    reference_index, constructor_index = {}, {}
    for fact in analysis['references']:
        key = (fact['source_name'], fact['symbol_kind'], fact['target'], fact['span']['line'])
        reference_index.setdefault(key, []).append(fact)
        key = (fact['symbol_kind'], fact['target'], fact['span']['line'])
        constructor_index.setdefault(key, []).append(fact)
    for index in (reference_index, constructor_index):
        for key, facts in index.items():
            ordered = sorted(facts, key=_position)
            index[key] = ([f['span']['column'] for f in ordered], ordered)

    def nearest(index, key, column):
        columns, facts = index.get(key, ((), ()))
        position = bisect_right(columns, column) - 1
        _require(position >= 0, 'Reference source must identify its corresponding expression or callee.')
        return facts[position]

    scope = {name: _symbol(name, 'intrinsic', None, 'core.' + name) for name in CORE}
    namespaces = {}
    imported_names = set()

    def define(destination, symbol):
        _require(symbol['name'] not in destination, f'Duplicate or shadowing name {symbol["name"]!r}.')
        destination[symbol['name']] = symbol

    imports = fragment['imports']
    _require(imports == sorted(imports, key=lambda i: (i['module'], i['alias'] or '', tuple(i['selection']))),
             'Imports must have canonical order.')
    for item in imports:
        module = item['module']
        standard = module.startswith('std.')
        _require(item['kind'] == ('standard' if standard else 'project'), 'Import kind disagrees with module.')
        _require(not (item['alias'] is not None and item['selection']), 'An import cannot combine alias and selection.')
        if standard:
            _require(module in STANDARD_EXPORTS, 'Unknown standard module.')
            available = {name: _symbol(name, 'intrinsic', None, module + '.' + name)
                         for name in STANDARD_EXPORTS[module]}
        else:
            _require(module in modules, 'Project import does not resolve.')
            available = exports[module]
        if item['selection']:
            for name in item['selection']:
                _require(name in available, 'Selected import must resolve to an export.')
                define(scope, dict(available[name]))
                imported_names.add(name)
        else:
            name = item['alias'] or module.rsplit('.', 1)[-1]
            define(scope, _symbol(name, 'namespace', None, module))
            namespaces[name] = available
            imported_names.add(name)

    source_items = [*fragment['type_definitions'], *fragment['instructions']]
    if source_items and imports:
        _require(max(_position(i) for i in imports) < min(_position(i) for i in source_items),
                 'Imports must precede all declarations and instructions.')
    executable = [i for i in fragment['instructions'] if i['kind'] not in {'function', 'let', 'derive'}]
    if executable:
        first = min(_position(i) for i in executable)
        _require(all(_position(d) < first for d in fragment['type_definitions']),
                 'Type definitions belong to the declaration prelude.')

    for definition in fragment['type_definitions']:
        kind = 'Record' if definition['kind'] == 'record' else 'Enum'
        value_type = dict(kind=kind, display=definition['name'], identity=definition['identity'])
        define(scope, _symbol(definition['name'], 'type', value_type,
                              definition['identity'], definition['span']))
    for instruction in fragment['instructions']:
        if instruction['kind'] == 'function':
            define(scope, _symbol(instruction['name'], 'function', None,
                                  instruction['details']['target'], instruction['span']))

    def resolve(path, current, *, callable=False):
        parts = path.split('.')
        _require(parts[0] in current, f'Unresolved lexical name {path!r}.')
        symbol = current[parts[0]]
        if symbol['kind'] == 'namespace':
            _require(len(parts) in {2, 3} and parts[1] in namespaces[parts[0]],
                     'Qualified name must address an exported symbol.')
            symbol = namespaces[parts[0]][parts[1]]
            parts = parts[1:]
        if len(parts) == 2 and symbol['kind'] == 'type' and symbol['type']['kind'] == 'Enum':
            definition = definitions[symbol['target']]
            _require(parts[-1] in {v['name'] for v in definition['variants']}, 'Unknown enum variant.')
            return _symbol(path, 'enum_variant', symbol['type'], symbol['target'] + '#' + parts[-1])
        _require(len(parts) == 1, 'Name path has extra components.')
        if callable and symbol['kind'] == 'type' and symbol['type']['kind'] == 'Record':
            return {**symbol, 'kind': 'record'}
        return symbol

    def provenance(node):
        value = node.get('provenance')
        if not value:
            return
        ref = value.get('reference')
        if ref is not None:
            _require('effects' in node and node.get('kind') in {'name', 'reference', 'argument', 'enum'},
                     'Reference provenance is not admitted on this node role.')
            if node['kind'] == 'argument':
                def related(child):
                    if ref == child.get('provenance', {}).get('reference'):
                        return True
                    payload = child.get('value')
                    if not isinstance(payload, dict):
                        return False
                    if child.get('kind') == 'call':
                        return (payload['target'], payload['source'], payload['symbol_kind']) == (
                            ref['target'], ref['source_name'], ref['symbol_kind'])
                    if child.get('kind') in {'record', 'enum'}:
                        target = payload['identity'] + ('#' + payload['variant'] if child['kind'] == 'enum' else '')
                        return target == ref['target']
                    return False
                _require(any(related(child) for child in _walk(node['operands'])),
                         'An argument reference must identify its wrapped expression or callee.')
            encoded = canonical_bytes(ref)
            _require(encoded in references, 'Local reference is missing from analysis.')
            used_references.add(encoded)
        local_conversions = value.get('conversions', [])
        _require(len(local_conversions) == len({canonical_bytes(c) for c in local_conversions}),
                 'Duplicate local conversion.')
        for conversion in local_conversions:
            encoded = canonical_bytes(conversion)
            _require(encoded in conversions, 'Local conversion is missing from analysis.')
            used_conversions.add(encoded)

    def callable_fact(expression, symbol, source):
        key = (source, symbol['kind'], symbol['target'], expression['span']['line'])
        fact = nearest(reference_index, key, expression['span']['column'])
        used_references.add(canonical_bytes(fact))

    def expression(node, current, function=None):
        provenance(node)
        kind, value = node['kind'], node.get('value')
        if kind in {'name', 'reference'}:
            source = value if kind == 'name' else value['source']
            symbol = resolve(source, current)
            _require(symbol['type'] is not None and symbol['kind'] not in {'type', 'function', 'intrinsic', 'namespace'},
                     'A value reference must resolve to a visible value.')
            _require(node['type'] == symbol['type'], 'Reference type disagrees with its visible binding.')
            ref = node['provenance'].get('reference')
            _require(ref is not None and ref['source_name'] == source and
                     ref['target'] == symbol['target'] and ref['symbol_kind'] == symbol['kind'],
                     'Reference provenance disagrees with lexical resolution.')
            if kind == 'reference':
                _require(value['target'] == symbol['target'] and value['symbol_kind'] == symbol['kind'],
                         'Qualified value payload disagrees with resolution.')
        elif kind == 'call':
            symbol = resolve(value['source'], current, callable=True)
            _require(symbol['kind'] in {'function', 'intrinsic'} and
                     value['target'] == symbol['target'] and value['symbol_kind'] == symbol['kind'],
                     'Call target and source do not resolve to the same callable.')
            callable_fact(node, symbol, value['source'])
            if symbol['kind'] == 'function':
                target = symbol['target']
                _require(target in functions, 'A called function must be linked.')
                spec = functions[target]['details']
                _arguments(node.get('operands', []), spec['parameters'], ordered=False)
                _require(node['type'] == spec['return_type'], 'Call result must equal declared return type.')
                if function is not None:
                    graph[function].add(target)
        elif kind in {'record', 'enum'}:
            target = value['identity']
            _require(target in definitions and definitions[target]['kind'] == kind,
                     'Constructor must resolve to a nominal definition of its kind.')
            definition = definitions[target]
            _require(value['name'] == definition['name'] and node['type']['identity'] == target,
                     'Constructor nominal identity and display disagree.')
            fields = definition.get('fields')
            expected_kind, expected_target = 'record', target
            if kind == 'enum':
                variants = {v['name']: v for v in definition['variants']}
                _require(value['variant'] in variants, 'Constructor variant is unknown.')
                fields = variants[value['variant']]['fields']
                expected_kind, expected_target = 'enum_variant', target + '#' + value['variant']
            _arguments(node.get('operands', []), fields, ordered=True, positional=kind == 'enum')
            key = (expected_kind, expected_target, node['span']['line'])
            fact = nearest(constructor_index, key, node['span']['column'])
            symbol = resolve(fact['source_name'], current, callable=True)
            _require(symbol['target'] == expected_target and symbol['kind'] == expected_kind,
                     'Constructor must be visible through its declared import or local definition.')
            used_references.add(canonical_bytes(fact))
        for operand in node.get('operands', []):
            expression(operand, current, function)

    def block(instructions, current, function=None, top=False):
        _source_order(instructions, 'Instructions')
        executable_seen = False
        for instruction in instructions:
            provenance(instruction)
            kind, name, details = instruction['kind'], instruction['name'], instruction['details']
            node = instruction['expression']
            if top:
                if kind in {'function', 'let', 'derive'}:
                    _require(not executable_seen, 'Top-level declarations must precede executable statements.')
                else:
                    executable_seen = True
            if kind == 'function':
                _require(top and function is None, 'Functions are top-level declarations.')
                parameters, captures = details['parameters'], details['captures']
                _source_order(parameters, 'Function parameters')
                _require(details['params'] == [p['name'] for p in parameters], 'Parameter name lists disagree.')
                _require(instruction['type'] == details['return_type'], 'Function result metadata disagrees.')
                local = {n: s for n, s in current.items() if s['kind'] in {'intrinsic', 'namespace', 'type', 'function'}
                         or (n in imported_names and not s['mutable'])}
                for capture in captures:
                    n = capture['name']
                    _require(n in current and n not in imported_names and current[n]['kind'] in {'let', 'derive'} and not current[n]['mutable'],
                             'Capture must be an earlier immutable binding.')
                    _require(capture['type'] == current[n]['type'], 'Capture type disagrees with its binding.')
                    define(local, {**current[n], 'kind': 'capture'})
                for parameter in parameters:
                    define(local, _symbol(parameter['name'], 'parameter', parameter['type'], parameter['name'], parameter['span']))
                block(details['body'], local, details['target'])
                expression(node, local, details['target'])
                _require(_fits(node['type'], details['return_type']), 'Function return expression type is incompatible.')
                continue
            if function is not None:
                _require(kind not in {'measure', 'evidence', 'require', 'emit'}, 'Function bodies must remain pure.')
            expression(node, current, function)
            if kind == 'measure':
                expression(details['uncertainty'], current, function)
            if kind in {'let', 'derive', 'var', 'evidence', 'measure'}:
                if kind != 'measure':
                    _require(_fits(node['type'], instruction['type']), 'Binding initializer type is incompatible.')
                target = owner + '.' + name if function is None and kind in {'let', 'derive', 'var'} else name
                define(current, _symbol(name, kind, instruction['type'], target, instruction['span'], kind == 'var'))
            elif kind == 'set':
                _require(name in current and current[name]['mutable'], 'Set must target a visible mutable var.')
                _require(instruction['type'] == node['type'] and _fits(node['type'], current[name]['type']),
                         'Set value type is incompatible with its target.')
            if kind == 'if':
                then_scope = dict(current)
                if node['kind'] == 'call' and node['value']['target'] == 'core.is_known':
                    args = node.get('operands', [])
                    if len(args) == 1 and args[0]['operands'][0]['kind'] == 'name':
                        n = args[0]['operands'][0]['value']
                        if then_scope[n]['type']['kind'] == 'Unknown':
                            then_scope[n] = {**then_scope[n], 'type': then_scope[n]['type']['arguments'][0], 'kind': 'refinement'}
                block(details['then'], then_scope, function)
                block(details['else'], dict(current), function)
            elif kind == 'for':
                _require(node['type']['kind'] == 'Vector' and details['item_type'] == node['type']['arguments'][0],
                         'For item type must equal its known vector element type.')
                _require(node['type'].get('size', 0) <= details['limit'], 'For limit is below its fixed vector length.')
                local = dict(current)
                define(local, _symbol(name, 'loop', details['item_type'], name, instruction['span']))
                block(details['body'], local, function)
            elif kind == 'match':
                _match(node['type'], details['cases'], current, function, block, define, definitions, resolve)
        return current

    final_scope = block(fragment['instructions'], scope, top=True)
    # Include metadata on fields, imports, parameters and captures in global parity.
    for node in _walk({k: v for k, v in fragment.items() if k != 'modules'}):
        provenance(node)
    _require(references == used_references, 'Analysis contains an unused or forged reference fact.')
    _require(conversions == used_conversions, 'Analysis contains an unused or forged conversion fact.')
    if 'exports' in fragment:
        for item in fragment['exports']:
            _require(item['name'] in final_scope, 'Export must resolve to a declared symbol.')
            symbol = final_scope[item['name']]
            _require(item['exported'] is True and not item['mutable'] and
                     all(item[k] == symbol[k] for k in ('kind', 'type', 'target', 'span', 'mutable')),
                     'Export metadata must agree with its immutable declaration.')
        expected_types = {d['identity'] for d in fragment['type_definitions'] if d['exported']}
        actual_types = {x['target'] for x in fragment['exports'] if x['kind'] == 'type'}
        _require(expected_types == actual_types, 'Exported nominal definitions must match the export table.')


def _arguments(arguments, parameters, *, ordered, positional=True):
    _require(len(arguments) == len(parameters), 'Constructor or call arity disagrees with its schema.')
    _require(all(a['kind'] == 'argument' for a in arguments), 'Constructor and call operands require argument wrappers.')
    names = [a['value']['name'] for a in arguments]
    expected = [p['name'] for p in parameters]
    if any(name is not None for name in names):
        _require(None not in names and len(set(names)) == len(names) and set(names) == set(expected),
                 'Named arguments must exactly cover the closed signature.')
        if ordered:
            _require(names == expected, 'Constructor fields must follow declaration order.')
        lookup = {p['name']: p for p in parameters}
        pairs = [(a, lookup[a['value']['name']]) for a in arguments]
    else:
        _require(positional or not parameters, 'Record constructors require named fields.')
        pairs = zip(arguments, parameters)
    for argument, parameter in pairs:
        _require(_fits(argument['type'], parameter['type']), 'Argument type disagrees with the declared field or parameter.')


def _match(value_type, cases, current, function, block, define, definitions, resolve):
    kind = value_type['kind']
    if kind == 'Result':
        variants = {'Ok': [value_type['arguments'][0]], 'Err': [{'kind': 'Failure', 'display': 'Failure'}]}
    elif kind == 'Enum':
        definition = definitions[value_type['identity']]
        variants = {v['name']: [f['type'] for f in v['fields']] for v in definition['variants']}
    else:
        _require(False, 'Match requires a known Result or Enum.')
    names = []
    for case in cases:
        tag = case['tag']
        _require(bool(tag), 'Match tag is required.')
        variant = tag[-1]
        if kind == 'Result':
            _require(tag == ['Result', variant], 'Result match tags are Result.Ok or Result.Err.')
        else:
            resolved = resolve('.'.join(tag), current, callable=True)
            _require(resolved['kind'] == 'enum_variant' and resolved['target'] == value_type['identity'] + '#' + variant,
                     'Match tag must resolve to the scrutinee enum.')
        _require(variant in variants, 'Unknown match variant.')
        names.append(variant)
        bindings = case['bindings']
        _require(len(bindings) == len(variants[variant]), 'Match binding arity disagrees with variant payload.')
        local = dict(current)
        for name, bound_type in zip(bindings, variants[variant]):
            define(local, _symbol(name, 'pattern', bound_type, name, case['span']))
        block(case['body'], local, function)
    _require(len(names) == len(set(names)) and set(names) == set(variants),
             'Match cases must be unique and exhaustive.')


def _verify_compatibility(root):
    """Closed historical references without inventing absent resolved types.

    Historical self recursion remains admitted and bounded by Joanna's existing
    function-depth budget. B03.2's strict acyclic A1 graph is a separate lane.
    """
    builtin_arities = {
        'unknown': (0, 1), 'abs': (1, 1), 'min': (1, None),
        'max': (1, None), 'mean': (1, None), 'sum': (1, None),
        'variance': (2, 2), 'dampen': (1, 1), 'step_cap': (1, 1),
        'bound': (1, 1), 'shadow_speed': (2, 2), 'floor_challenge': (1, 1),
        'signed_mass_delta': (2, 2), 'length': (1, 1), 'at': (2, 2),
        'dot': (2, 2), 'norm': (1, 1), 'select': (3, 3), 'sqrt': (1, 1),
        'moving_mean': (2, 2), 'slope': (2, 2),
    }
    symbols, mutables, declared, outputs = set(), set(), set(), set()
    functions = {}

    def expression(node, visible):
        kind = node['kind']
        if kind == 'name':
            _require(node['value'] in visible, 'Compatibility value name is not visible.')
        elif kind == 'call':
            name = node['value']
            count = len(node.get('operands', []))
            if name in functions:
                minimum = maximum = len(functions[name])
            else:
                _require(name in builtin_arities, 'Compatibility call target is not registered or visible.')
                minimum, maximum = builtin_arities[name]
            if count < minimum or (maximum is not None and count > maximum):
                raise BangelDiagnostic('ARGUMENT_COUNT', 'Compatibility call arity disagrees with its closed signature.')
        for operand in node.get('operands', []):
            expression(operand, visible)

    for instruction in root['instructions']:
        kind, name, node = instruction['kind'], instruction['name'], instruction['expression']
        if kind == 'function':
            _require(name not in declared, 'Duplicate compatibility function or binding name.')
            parameters = instruction['details']['params']
            _unique(parameters, 'Compatibility function parameters')
            functions[name] = parameters
            expression(node, symbols | set(parameters))
            declared.add(name)
            continue
        if node is not None:
            expression(node, symbols)
        if kind == 'measure' and 'uncertainty' in instruction['details']:
            expression(instruction['details']['uncertainty'], symbols)
        if kind == 'set':
            _require(name in mutables, 'Compatibility set requires a visible var binding.')
            continue
        if kind == 'evidence':
            _require('evidence' in root['effects'], 'Compatibility evidence requires its declared effect.')
        if kind == 'emit':
            output = name or f'output_{len(outputs) + 1}'
            _require(output not in outputs, 'Compatibility outputs cannot overwrite an earlier output.')
            outputs.add(output)
        if name:
            _require(name not in declared, 'Duplicate compatibility declaration or output name.')
            declared.add(name)
            if kind in {'let', 'derive', 'var', 'measure', 'evidence', 'collect'}:
                symbols.add(name)
            if kind == 'var':
                mutables.add(name)
