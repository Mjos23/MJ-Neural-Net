from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from .compiler import ElsaCompiler
from .diagnostics import BangelDiagnostic
from .formatter import format_source
from .gin import GinInputError, evaluate as evaluate_gin, make_source as make_gin_source, read_request as read_gin_request
from .inspector import inspect_receipt, query_receipt
from .project import ElsaProjectBuilder
from .runtime import JoannaRuntime


COMPATIBILITY_CHOICES = tuple(sorted(ElsaCompiler.compatibility_profiles))


def _json(value: object) -> str:
    return json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="bangel",
        description="Bangel robotics-focused measurement programming language: Elsa compiler and Joanna runtime",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("serve", help="Serve BANGEL-API/1 on local stdio")
    gin_parser = sub.add_parser("gin", help="Run GIN interval calculations and explicit clock normalization through Bangel 1.0")
    gin_parser.add_argument("action", choices=("source", "run"))
    gin_parser.add_argument("request", help="JSON interval request")
    gin_parser.add_argument("-o", "--output")
    check_parser = sub.add_parser("check", help="Check Bangel source without execution")
    check_parser.add_argument("source")
    lint_parser = sub.add_parser("lint", help="Print stable JSON linter findings")
    lint_parser.add_argument("source")
    verify_parser = sub.add_parser("verify-ir", help="Verify canonical JP-IR bytes")
    verify_parser.add_argument("ir")
    replay_parser = sub.add_parser("replay", help="Verify and replay canonical JP-IR against a receipt")
    replay_parser.add_argument("ir")
    replay_parser.add_argument("receipt")
    compile_parser = sub.add_parser("compile", help="Compile Bangel source to JP-IR")
    compile_parser.add_argument("source")
    compile_parser.add_argument("-o", "--output")
    compile_parser.add_argument("--canonical", action="store_true", help="Write canonical JP-IR bytes")
    compile_parser.add_argument(
        "--compat",
        choices=COMPATIBILITY_CHOICES,
        help="Select an explicit historical syntax profile",
    )
    run_parser = sub.add_parser("run", help="Compile and execute with Joanna")
    run_parser.add_argument("source")
    run_parser.add_argument("-o", "--output")
    run_parser.add_argument(
        "--compat",
        choices=COMPATIBILITY_CHOICES,
        help="Select an explicit historical syntax profile",
    )
    inspect_parser = sub.add_parser("inspect", help="Verify a Joanna receipt")
    inspect_parser.add_argument("receipt")
    query_parser = sub.add_parser("query", help="Query a verified Joanna receipt")
    query_parser.add_argument("receipt")
    query_parser.add_argument("path")
    format_parser = sub.add_parser("format", help="Canonicalize Bangel source newlines")
    format_parser.add_argument("source")
    format_parser.add_argument("--check", action="store_true")
    project_parser = sub.add_parser("project-build", help="Build a multi-source Bangel project")
    project_parser.add_argument("manifest")
    project_parser.add_argument("-o", "--output")
    identity_parser = sub.add_parser("identity", help="Print the canonical stack")
    preflight_parser = sub.add_parser("preflight", help="Print the non-executing passkey readiness boundary")
    preflight_parser.add_argument("--tests-passed", type=int, default=0)
    preflight_parser.add_argument("--package-root")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "gin":
            request = read_gin_request(args.request)
            rendered = (make_gin_source(request) if args.action == "source"
                        else _json(evaluate_gin(request)) + "\n")
            if args.output:
                Path(args.output).write_text(rendered, encoding="utf-8")
            else:
                print(rendered, end="")
            return 0
        if args.command == "serve":
            from .api import serve_stdin
            return serve_stdin()
        if args.command == "lint":
            from .linter import lint_source
            path = Path(args.source)
            findings = lint_source(path.name, path.read_text(encoding="utf-8"))
            print(_json({"findings": findings}))
            return 1 if findings else 0
        if args.command == "check":
            from .api import make_request, call_isolated
            path = Path(args.source)
            response = call_isolated(make_request("check", {"source": {
                "name": path.name, "text": path.read_text(encoding="utf-8")}}))
            print(_json(response))
            return 0 if response["ok"] else 2
        if args.command in {"verify-ir", "replay"}:
            from .ir import JPIR
            ir = JPIR.from_bytes(Path(args.ir).read_bytes()).to_dict()
            if args.command == "verify-ir":
                print(_json({"valid": True, "program_root": ir["program_root"]}))
            else:
                from .inspector import replay_receipt
                receipt = json.loads(Path(args.receipt).read_text(encoding="utf-8"))
                print(_json(replay_receipt(ir, receipt)))
            return 0
        if args.command == "identity":
            from .identity import CANONICAL_STACK
            print(_json(CANONICAL_STACK))
            return 0
        if args.command == "preflight":
            from .gates import passkey_preflight_report
            print(_json(passkey_preflight_report(
                tests_passed=args.tests_passed,
                package_root=args.package_root,
            )))
            return 0
        if args.command == "inspect":
            receipt = json.loads(Path(args.receipt).read_text(encoding="utf-8"))
            print(_json(inspect_receipt(receipt)))
            return 0
        if args.command == "query":
            receipt = json.loads(Path(args.receipt).read_text(encoding="utf-8"))
            print(_json(query_receipt(receipt, args.path)))
            return 0
        if args.command == "format":
            source_path = Path(args.source)
            original = source_path.read_text(encoding="utf-8")
            formatted = format_source(original)
            if args.check:
                return 0 if formatted == original else 1
            source_path.write_text(formatted, encoding="utf-8")
            return 0
        if args.command == "project-build":
            result = ElsaProjectBuilder().build_file(Path(args.manifest)).to_dict()
            rendered = _json(result) + "\n"
            if args.output:
                Path(args.output).write_text(rendered, encoding="utf-8")
            else:
                print(rendered, end="")
            return 0
        source_path = Path(args.source)
        source = source_path.read_text(encoding="utf-8")
        compilation = ElsaCompiler(compatibility_profile=args.compat).compile(
            source_path.name, source
        ).to_dict()
        result = compilation if args.command == "compile" else JoannaRuntime().execute(compilation).to_dict()
        if args.command == "compile" and args.canonical:
            from .canonical import canonical_bytes
            data = canonical_bytes(result)
            if args.output:
                Path(args.output).write_bytes(data)
            else:
                import sys
                sys.stdout.buffer.write(data)
            return 0
        rendered = _json(result) + "\n"
        if args.output:
            Path(args.output).write_text(rendered, encoding="utf-8")
        else:
            print(rendered, end="")
        return 0
    except (BangelDiagnostic, GinInputError, OSError, UnicodeError, json.JSONDecodeError) as error:
        parser.exit(2, f"{error}\n")
