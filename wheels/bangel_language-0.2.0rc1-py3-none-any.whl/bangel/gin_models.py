"""Source-backed GIN temporal states and evidence atoms.

JSON shape checks happen at the adapter boundary. Numeric validity and model
guards execute as ordinary Bangel 1.0, with native nominal output types.
"""
from __future__ import annotations

import json
import math
import re

from .gin import GinInputError, MAX_TICK, _IDENTIFIER, _integer


STATES = {"known": "GKnown", "bounded": "GBounded", "unknown": "GUnknown",
          "inapplicable": "GInapplicable", "disputed": "GDisputed", "incomparable": "GIncomparable"}
TYPES = """record GinInterval
  f_lower: Int
  f_upper: Int
  f_precision: Int
  f_clock: Text
  f_unit: Text
end
record GinEstimate
  f_modelRef: Text
  f_inputRefs: Vector[Text]
  f_assumptions: Vector[Text]
  f_authoritative: Bool
end
enum GinEstimation
  GAbsent
  GPresent(f_value: GinEstimate)
end
enum GinOptionalInterval
  GAbsent
  GPresent(f_value: GinInterval)
end
enum GinOptionalText
  GAbsent
  GPresent(f_value: Text)
end
enum GinTemporal
  GKnown(f_interval: GinInterval, f_basis: Text, f_evidenceIds: Vector[Text], f_provenanceRefs: Vector[Text], f_estimation: GinEstimation)
  GBounded(f_interval: GinInterval, f_basis: Text, f_evidenceIds: Vector[Text], f_provenanceRefs: Vector[Text], f_estimation: GinEstimation)
  GUnknown(f_reason: Text, f_evidenceIds: Vector[Text], f_provenanceRefs: Vector[Text])
  GInapplicable(f_reason: Text, f_profileRef: Text, f_evidenceIds: Vector[Text], f_provenanceRefs: Vector[Text])
  GDisputed(f_reason: Text, f_candidates: Vector[GinInterval], f_evidenceIds: Vector[Text], f_provenanceRefs: Vector[Text])
  GIncomparable(f_reason: Text, f_sourceClocks: Vector[Text], f_evidenceIds: Vector[Text], f_provenanceRefs: Vector[Text])
end
record GinEvidenceAtom
  f_profile: Text
  f_evidenceId: Text
  f_sourceRef: Text
  f_subjectRef: Text
  f_milestone: Text
  f_state: Text
  f_interval: GinOptionalInterval
  f_method: Text
  f_confidence: Vector[Real; 2]
  f_provenanceRefs: Vector[Text]
  f_digest: Text
  f_authorityRef: GinOptionalText
end
"""


def _shape(value, required, optional=(), *, code="GIN_INPUT_SHAPE"):
    if type(value) is not dict or not set(required) <= set(value) or set(value) - set(required) - set(optional):
        raise GinInputError(code, "Object fields do not match the GIN model contract.")


def _array(value, name):
    if type(value) is not list:
        raise GinInputError("GIN_INPUT_SHAPE", name + " requires an array.")
    return value


def _text(value, *, identifier=False, nonempty=True, code="GIN_TEXT_INVALID"):
    if type(value) is not str or (nonempty and not value.strip()):
        raise GinInputError(code, "A bounded text value is required.")
    try:
        # Match the reference's UTF-16 length bound and reject lone surrogates.
        if len(value.encode("utf-16-le")) // 2 > 4096:
            raise GinInputError(code, "A bounded text value is required.")
    except UnicodeError as error:
        raise GinInputError(code, "Text must contain Unicode scalar values.") from error
    if identifier and not _IDENTIFIER.fullmatch(value):
        raise GinInputError("GIN_IDENTITY_INVALID", "A bounded identifier is required.")
    return json.dumps(value)


def _instance(kind, fields):
    return kind + "(" + ", ".join("f_" + name + " = " + expression for name, expression in fields.items()) + ")"


class ModelSource:
    def __init__(self):
        self.declarations = []
        self.guards = []

    def bind(self, expression, kind=None):
        name = "g_" + str(len(self.declarations))
        annotation = ": " + kind if kind else ""
        self.declarations.append("let " + name + annotation + " = " + expression)
        return name

    def require(self, expression, code):
        self.guards.append("require " + expression + " else " + code)

    def text(self, value, **kwargs):
        return self.bind(_text(value, **kwargs))

    def texts(self, values, name, *, identifiers=False):
        return self.bind("[" + ", ".join(_text(v, identifier=identifiers) for v in _array(values, name)) + "]", "Vector[Text]")

    def member(self, name, values, code):
        self.require(" or ".join(name + " == " + json.dumps(v) for v in values), code)

    def interval(self, value):
        _shape(value, {"lower", "upper", "precision", "clock", "unit"}, code="GIN_INTERVAL_INVALID")
        fields = {k: self.bind(_integer(value[k], k)) for k in ("lower", "upper", "precision")}
        fields.update({k: self.text(value[k], identifier=True) for k in ("clock", "unit")})
        for key in ("lower", "upper", "precision"):
            self.require(f"is_known({fields[key]})", "GIN_UNKNOWN")
        for key in ("lower", "upper", "precision"):
            self.require(f"{fields[key]} >= -{MAX_TICK} and {fields[key]} <= {MAX_TICK}", "GIN_UNSAFE_QUANTITY")
        self.require(fields["precision"] + " >= 0", "GIN_QUANTITY_NEGATIVE")
        self.require(fields["lower"] + " <= " + fields["upper"], "GIN_INTERVAL_BOUNDS")
        self.require(fields["precision"] + " >= " + fields["upper"] + " - " + fields["lower"], "GIN_PRECISION_FALSE")
        return _instance("GinInterval", fields), fields

    def temporal(self, value):
        if type(value) is not dict or type(value.get("state")) is not str or value["state"] not in STATES:
            raise GinInputError("GIN_TEMPORAL_STATE_INVALID", "A recognized temporal state is required.")
        state = value["state"]
        common = {"state", "evidenceIds", "provenanceRefs"}
        if state in ("known", "bounded"):
            _shape(value, common | {"interval", "basis"}, {"estimated"})
        else:
            if "interval" in value:
                raise GinInputError("GIN_NONQUANTIFIED_HAS_VALUE", "A nonquantified temporal state cannot carry an interval.")
            extra = {"inapplicable": {"profileRef"}, "disputed": {"candidates"}, "incomparable": {"sourceClocks"}}.get(state, set())
            _shape(value, common | {"reason"} | extra)
        fields = {"evidenceIds": self.texts(value["evidenceIds"], "evidenceIds", identifiers=True),
                  "provenanceRefs": self.texts(value["provenanceRefs"], "provenanceRefs")}
        if state in ("known", "bounded"):
            fields["interval"], interval_fields = self.interval(value["interval"])
            equality = " == " if state == "known" else " != "
            self.require(interval_fields["lower"] + equality + interval_fields["upper"],
                         "GIN_KNOWN_NOT_POINT" if state == "known" else "GIN_BOUNDED_IS_POINT")
            fields["basis"] = self.text(value["basis"], nonempty=False)
            self.member(fields["basis"], ("observed", "estimated", "reconciled"), "GIN_BASIS_INVALID")
            fields["estimation"] = "GinEstimation.GAbsent"
            if "estimated" in value:
                estimate = value["estimated"]
                _shape(estimate, {"modelRef", "inputRefs", "assumptions", "authoritative"}, code="GIN_ESTIMATION_INCOMPLETE")
                if type(estimate["authoritative"]) is not bool:
                    raise GinInputError("GIN_ESTIMATION_INCOMPLETE", "Estimate authority must be a boolean.")
                estimate_fields = {"modelRef": self.text(estimate["modelRef"], identifier=True),
                                   "inputRefs": self.texts(estimate["inputRefs"], "inputRefs"),
                                   "assumptions": self.texts(estimate["assumptions"], "assumptions"),
                                   "authoritative": self.bind(str(estimate["authoritative"]).lower())}
                self.require(fields["basis"] + ' == "estimated"', "GIN_ESTIMATION_LABEL_INVALID")
                self.require("not " + estimate_fields["authoritative"], "GIN_ESTIMATION_INCOMPLETE")
                self.require(f"{len(estimate['inputRefs'])} > 0 and {len(estimate['assumptions'])} > 0", "GIN_ESTIMATION_INCOMPLETE")
                fields["estimation"] = _instance("GinEstimation.GPresent", {"value": _instance("GinEstimate", estimate_fields)})
            else:
                self.require(fields["basis"] + ' != "estimated"', "GIN_ESTIMATION_INCOMPLETE")
        else:
            fields["reason"] = self.text(value["reason"], code="GIN_STATE_REASON_MISSING")
            if state == "inapplicable":
                fields["profileRef"] = self.text(value["profileRef"], identifier=True)
            elif state == "disputed":
                candidates = _array(value["candidates"], "candidates")
                self.require(f"{len(candidates)} >= 2", "GIN_DISPUTE_EVIDENCE_MISSING")
                intervals = [self.interval(candidate)[0] for candidate in candidates]
                # Constructors stay after all guards, in the executable body.
                fields["candidates"] = "[" + ", ".join(intervals) + "]"
            elif state == "incomparable":
                fields["sourceClocks"] = self.texts(value["sourceClocks"], "sourceClocks", identifiers=True)
                self.require(f"{len(value['sourceClocks'])} > 0", "GIN_INCOMPARABLE_CLOCKS_MISSING")
        return _instance("GinTemporal." + STATES[state], fields)

    def evidence(self, value):
        required = {"profile", "evidenceId", "sourceRef", "subjectRef", "milestone", "state",
                    "method", "confidence", "provenanceRefs", "digest"}
        _shape(value, required, {"interval", "authorityRef"})
        if type(value["state"]) is not str or value["state"] not in STATES:
            raise GinInputError("GIN_EVIDENCE_STATE_INVALID", "A recognized evidence state is required.")
        fields = {"profile": self.text(value["profile"], nonempty=False)}
        self.require(fields["profile"] + ' == "GIN/EvidenceAtom/1"', "GIN_EVIDENCE_PROFILE_INVALID")
        fields.update({k: self.text(value[k], identifier=True) for k in ("evidenceId", "sourceRef", "subjectRef")})
        fields["milestone"] = self.text(value["milestone"], nonempty=False)
        self.member(fields["milestone"], ("expected", "observed", "recorded", "delivered", "reconciled"), "GIN_MILESTONE_INVALID")
        fields["state"] = self.text(value["state"])
        fields["interval"] = "GinOptionalInterval.GAbsent"
        if value["state"] in ("known", "bounded"):
            if "interval" not in value:
                raise GinInputError("GIN_INTERVAL_MISSING", "Quantified evidence requires an interval.")
            interval, interval_fields = self.interval(value["interval"])
            if value["state"] == "known":
                self.require(interval_fields["lower"] + " == " + interval_fields["upper"], "GIN_KNOWN_NOT_POINT")
            fields["interval"] = _instance("GinOptionalInterval.GPresent", {"value": interval})
        elif "interval" in value:
            raise GinInputError("GIN_NONQUANTIFIED_HAS_VALUE", "Nonquantified evidence cannot carry an interval.")
        fields["method"] = self.text(value["method"])
        confidence = _array(value["confidence"], "confidence")
        if len(confidence) != 2:
            raise GinInputError("GIN_CONFIDENCE_INVALID", "Confidence requires two numeric bounds.")
        bounds = []
        for number in confidence:
            if number is None:
                expression = 'unknown[Real]("missing confidence")'
            elif ((type(number) is int and -MAX_TICK <= number <= MAX_TICK)
                  or (type(number) is float and math.isfinite(number))):
                expression = repr(number) if type(number) is float else str(number) + ".0"
            else:
                raise GinInputError("GIN_CONFIDENCE_INVALID", "Confidence requires finite numeric bounds or null.")
            # Explicit Real annotations retain unknown values while allowing a
            # homogeneous vector after the is_known guards. No zero is inserted.
            symbol = self.bind(expression, "Real")
            bounds.append(symbol)
            self.require("is_known(" + symbol + ")", "GIN_UNKNOWN")
        self.require(f"{bounds[0]} >= 0.0 and {bounds[1]} <= 1.0 and {bounds[0]} <= {bounds[1]}", "GIN_CONFIDENCE_INVALID")
        fields["confidence"] = "[" + ", ".join(bounds) + "]"
        fields["provenanceRefs"] = self.texts(value["provenanceRefs"], "provenanceRefs")
        self.require(f"{len(value['provenanceRefs'])} > 0", "GIN_PROVENANCE_MISSING")
        fields["digest"] = self.text(value["digest"], nonempty=False)
        digest_valid = bool(re.fullmatch(r"[0-9a-fA-F]{64}", value["digest"]))
        self.require(str(digest_valid).lower(), "GIN_EVIDENCE_DIGEST_INVALID")
        fields["authorityRef"] = "GinOptionalText.GAbsent"
        if "authorityRef" in value:
            fields["authorityRef"] = _instance("GinOptionalText.GPresent", {"value": self.text(value["authorityRef"], identifier=True)})
        return _instance("GinEvidenceAtom", fields)

    def render(self, expression):
        return "\n".join(["bangel 1.0", "program gin_model", "effects pure", TYPES.rstrip(),
                          *self.declarations, *self.guards, "if true",
                          "  emit gin_value = " + expression, "end", ""])


def make_model_source(request):
    _shape(request, {"operation", "value"})
    if request["operation"] not in ("temporal", "evidence"):
        raise GinInputError("GIN_OPERATION", "Unsupported GIN model operation.")
    source = ModelSource()
    expression = source.temporal(request["value"]) if request["operation"] == "temporal" else source.evidence(request["value"])
    return source.render(expression)


def model_from_receipt(receipt):
    """Decode nominal GIN output; this is not evidence authentication or admission."""
    if receipt["status"] != "PASS" or set(receipt["outputs"]) != {"gin_value"}:
        raise ValueError("A passing GIN model receipt is required.")

    def decode(value):
        if isinstance(value, list):
            return [decode(item) for item in value]
        if not isinstance(value, dict):
            return value
        if value.get("kind") == "int" and set(value) == {"kind", "value"}:
            return int(value["value"])
        if value.get("kind") == "real" and set(value) == {"kind", "value"}:
            return float(value["value"])
        identity = value.get("identity", "")
        if not identity.startswith("program.gin_model.") or value.get("kind") not in ("record", "enum"):
            raise ValueError("Unexpected nominal GIN output.")
        fields = value.get("fields")
        if not isinstance(fields, dict) or any(not name.startswith("f_") for name in fields):
            raise ValueError("Unexpected GIN field representation.")
        fields = {name[2:]: decode(item) for name, item in fields.items()}
        kind = identity.removeprefix("program.gin_model.")
        if kind in ("GinEstimation", "GinOptionalInterval", "GinOptionalText"):
            if value.get("variant") == "GAbsent" and not fields:
                return None
            if value.get("variant") == "GPresent" and set(fields) == {"value"}:
                return fields["value"]
            raise ValueError("Unexpected optional GIN value.")
        if kind == "GinTemporal":
            states = {variant: state for state, variant in STATES.items()}
            if value.get("variant") not in states:
                raise ValueError("Unexpected temporal state variant.")
            fields["state"] = states[value["variant"]]
            if "estimation" in fields:
                estimate = fields.pop("estimation")
                if estimate is not None:
                    fields["estimated"] = estimate
        elif kind == "GinEvidenceAtom":
            for name in ("interval", "authorityRef"):
                if fields.get(name) is None:
                    fields.pop(name, None)
        elif kind not in ("GinInterval", "GinEstimate"):
            raise ValueError("Unexpected GIN record type.")
        return fields

    return decode(receipt["outputs"]["gin_value"])
