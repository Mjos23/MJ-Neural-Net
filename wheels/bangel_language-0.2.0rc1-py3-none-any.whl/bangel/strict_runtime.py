"""Joanna/1 execution for independently admitted, fully typed JP-IR/1.

This module consumes the frozen IR only. It imports no Elsa frontend rules.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from copy import deepcopy
from decimal import Context, Decimal, DecimalException, ROUND_HALF_EVEN, localcontext
from typing import Any, Callable

from .canonical import canonical_bytes
from .diagnostics import BangelDiagnostic, SourceSpan
from .evaluator import call_builtin
from .identity import CANONICAL_PATH, PREDICTION_NODES, RUNTIME_PROTOCOL, Stage
from .receipts import bind_receipt, verify_receipt
from .state import Traversal
from .units import DIMENSIONLESS, MASS, UNITS
from .values import Quantity

DECIMAL128 = Context(prec=34, Emin=-6143, Emax=6144, rounding=ROUND_HALF_EVEN)
INT_MIN, INT_MAX = -(2**63), 2**63 - 1


@dataclass(frozen=True, slots=True)
class Unknown:
    value_type: dict[str, Any]
    reason: str
    provenance: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Failure:
    code: str
    message: str


@dataclass(frozen=True, slots=True)
class Result:
    variant: str
    value: Any


@dataclass(frozen=True, slots=True)
class Nominal:
    kind: str
    identity: str
    fields: dict[str, Any]
    variant: str | None = None


@dataclass(slots=True)
class Scope:
    parent: Scope | None = None
    values: dict[str, Any] = field(default_factory=dict)
    mutable: set[str] = field(default_factory=set)

    def get(self, name: str):
        if name in self.values:
            return self.values[name]
        if self.parent is not None:
            return self.parent.get(name)
        raise BangelDiagnostic('NAME_UNBOUND', f'Unbound runtime name {name!r}.')

    def set(self, name: str, value: Any):
        if name in self.values:
            if name not in self.mutable:
                raise BangelDiagnostic('SET_IMMUTABLE', 'Runtime set target is immutable.')
            self.values[name] = value
        elif self.parent is not None:
            self.parent.set(name, value)
        else:
            raise BangelDiagnostic('NAME_UNBOUND', f'Unbound runtime name {name!r}.')


def _underlying(value_type):
    while value_type['kind'] == 'Unknown':
        value_type = value_type['arguments'][0]
    return value_type


def _unknown(value_type, values):
    origins = tuple(reason for value in values if isinstance(value, Unknown) for reason in value.provenance)
    return Unknown(_underlying(value_type), 'UNKNOWN_OPERAND', origins)


def _decimal_text(value: Decimal):
    if value == 0:
        return '0'
    # Decimal128 bounds cap fixed spelling at 6,178 characters.
    return format(value.normalize(), 'f')


class Machine:
    def __init__(self, compilation, limits, cancelled):
        self.ir, self.limits, self.cancelled = compilation, limits, cancelled
        self.instructions_used = self.evaluations_used = self.allocations_used = 0
        self.function_depth_used = self.depth = self.output_bytes = 0
        self.payload_bytes = 0
        self.functions: dict[str, tuple[dict, Scope]] = {}
        self.globals: dict[str, Any] = {}
        self.definitions = {item['identity']: item for item in compilation['type_definitions']}
        for module in compilation['modules']:
            self.definitions.update({item['identity']: item for item in module['type_definitions']})
        self.outputs, self.events, self.evidence = {}, [], []
        self.pending_indices = []
        self.status, self.hold_code = 'PASS', None
        self.traversal = Traversal()
        self.stage = Stage.R
        self.traversal.enter(Stage.R0, None, 'source_arrival')
        self.traversal.enter(Stage.R, None, 'identity_normalization')

    def poll(self):
        if self.cancelled is not None and self.cancelled():
            raise BangelDiagnostic('CANCELLED', 'Execution was cancelled.')

    def allocate(self, count=1):
        self.poll()
        if self.allocations_used + count > self.limits.allocation_limit:
            raise BangelDiagnostic('ALLOCATION_LIMIT', 'Runtime cumulative allocation budget exceeded.')
        self.allocations_used += count

    def charge_value(self, value):
        count = 1
        if isinstance(value, str):
            count += len(value.encode('utf-8'))
        elif isinstance(value, (tuple, list, dict)):
            count += len(value)
        self.allocate(count)
        return value

    def encode(self, value):
        self.allocate()
        if isinstance(value, Unknown):
            self.allocate(len(value.reason.encode('utf-8')) + sum(len(s.encode('utf-8')) for s in value.provenance))
            return {'kind':'unknown','type':deepcopy(value.value_type),'reason':value.reason,'provenance':list(value.provenance)}
        if isinstance(value, Quantity):
            result = value.to_dict()
            self.allocate(sum(len(v.encode('utf-8')) for v in result.values() if isinstance(v,str)))
            return result
        if type(value) is int:
            return {'kind':'int','value':str(value)}
        if isinstance(value, Decimal):
            text = _decimal_text(value)
            self.allocate(len(text))
            return {'kind':'real','value':text}
        if isinstance(value, Failure):
            return {'kind':'failure','code':self.encode(value.code),'message':self.encode(value.message)}
        if isinstance(value, Result):
            return {'kind':'result','variant':value.variant,'value':self.encode(value.value)}
        if isinstance(value, Nominal):
            result = {'kind':value.kind,'identity':value.identity,'fields':{key:self.encode(item) for key,item in sorted(value.fields.items())}}
            if value.kind == 'enum':
                result['variant'] = value.variant
            return result
        if isinstance(value, (tuple, list)):
            self.allocate(len(value))
            return [self.encode(item) for item in value]
        if isinstance(value, dict):
            self.allocate(len(value))
            return {'kind':'map','entries':{self.encode(k):self.encode(v) for k,v in sorted(value.items())}}
        if isinstance(value, str):
            self.allocate(len(value.encode('utf-8')))
        return value

    def event(self, event):
        if len(self.events) >= self.limits.event_limit:
            raise BangelDiagnostic('EVENT_LIMIT', 'Runtime event budget exceeded.')
        size = len(canonical_bytes(event))
        if self.payload_bytes + size > self.limits.receipt_limit:
            raise BangelDiagnostic('RECEIPT_LIMIT', 'Runtime receipt byte budget exceeded.')
        self.allocate(size + 1)
        self.payload_bytes += size
        event['stage'] = self.stage.value
        self.events.append(event)
        self.traversal.enter(self.stage,self.pending_indices.pop(),event['event'])

    def checked(self, value, value_type):
        if isinstance(value, Unknown):
            return Unknown(_underlying(value_type),value.reason,value.provenance)
        base = _underlying(value_type)
        if base['kind'] == 'Int':
            if isinstance(value, Quantity):
                value = value.magnitude_si
            if isinstance(value, Decimal):
                if value != value.to_integral_value():
                    raise BangelDiagnostic('INTEGER_INEXACT','The frozen Int result cannot represent a non-integral numeric value.')
                value = int(value)
            if type(value) is not int or not INT_MIN <= value <= INT_MAX:
                raise BangelDiagnostic('INTEGER_OVERFLOW', 'Int result is outside signed 64-bit range.')
        elif base['kind'] == 'Real':
            if isinstance(value, Quantity):
                value = value.magnitude_si
            value = +Decimal(value)
            if not value.is_finite():
                raise BangelDiagnostic('DECIMAL_NONFINITE', 'Real result is outside finite decimal128.')
        elif isinstance(value, Quantity):
            physical = base['arguments'][0] if base['kind'] == 'Measurement' else base
            if physical['kind'] in {'Quantity','MassDelta'}:
                unit = physical['unit']
                value = Quantity(Decimal(0) if value.magnitude_si == 0 else value.magnitude_si,tuple(unit['dimension']),unit['text'] if unit['text'] in UNITS else '1',Decimal(0) if value.uncertainty_si == 0 else value.uncertainty_si,physical['kind']=='MassDelta')
            if value.magnitude_si is not None and not value.magnitude_si.is_finite():
                raise BangelDiagnostic('DECIMAL_NONFINITE', 'Physical result is outside finite decimal128.')
        return value

    def evaluate(self, expression, scope):
        self.poll()
        if self.evaluations_used >= self.limits.evaluation_limit:
            raise BangelDiagnostic('EVALUATION_LIMIT', 'Expression evaluation budget exceeded.')
        self.evaluations_used += 1
        try:
            value = self._evaluate(expression, scope)
            # The +2^63 magnitude of the signed Int minimum has one explicit IR role.
            if expression['kind'] != 'map_entry' and expression.get('provenance', {}).get('role') != 'signed_literal_magnitude':
                value = self.checked(value, expression['type'])
            return self.charge_value(value)
        except BangelDiagnostic as exc:
            if exc.span is None and expression.get('span'):
                raise BangelDiagnostic(exc.code, exc.message, SourceSpan(**expression['span']), {**exc.details,'source':expression['provenance']['source']}) from exc
            raise
        except DecimalException as exc:
            raise BangelDiagnostic('DECIMAL_NONFINITE', 'Operation is outside finite decimal128.', SourceSpan(**expression['span'])) from exc

    def propagate(self, value_type, values):
        # Reserve before concatenation: repeated x+x must not grow an unbounded
        # provenance tuple before the deterministic allocation check.
        self.allocate(sum(len(v.provenance) + sum(len(s.encode('utf-8')) for s in v.provenance) for v in values if isinstance(v,Unknown)))
        return _unknown(value_type,values)

    def _evaluate(self, e, scope):
        kind, t, operands = e['kind'], e['type'], e.get('operands', [])
        ev = lambda x: self.evaluate(x, scope)
        if kind == 'literal':
            return Decimal(e['value']) if t['kind'] == 'Real' else e['value']
        if kind in {'name','reference'}:
            if kind == 'reference':
                return self.globals[e['value']['target']]
            try:
                return scope.get(e['value'])
            except BangelDiagnostic:
                ref = e['provenance'].get('reference', {})
                if ref.get('target') in self.globals:
                    return self.globals[ref['target']]
                raise
        if kind == 'quantity':
            if t['kind'] in {'Int','Real'}:
                magnitude = e['value']['magnitude']
                return int(magnitude) if t['kind'] == 'Int' else +Decimal(magnitude)
            u = t['unit']
            return Quantity(Decimal(e['value']['magnitude']) * Decimal(u['scale']), tuple(u['dimension']), u['text'] if u['text'] in UNITS else '1')
        if kind == 'mass_delta':
            value = ev(operands[0]); u = t['unit']
            return Quantity(Decimal(value) * Decimal(u['scale']), MASS, u['text'] if u['text'] in UNITS else '1', signed_delta=True)
        if kind == 'unknown':
            reason = e['value']['reason'] or ''
            return Unknown(_underlying(t), reason, (reason,))
        if kind == 'vector':
            self.allocate(len(operands))
            return tuple(ev(x) for x in operands)
        if kind == 'map':
            self.allocate(len(operands))
            return dict(ev(x) for x in operands)
        if kind == 'map_entry':
            return (e['value']['key'], ev(operands[0]))
        if kind == 'argument':
            return ev(operands[0])
        if kind == 'failure':
            return Failure(*(ev(x) for x in operands))
        if kind == 'result':
            return Result(e['value']['variant'], ev(operands[0]))
        if kind in {'record','enum'}:
            definition = self.definitions[e['value']['identity']]
            if kind == 'enum':
                definition = next(v for v in definition['variants'] if v['name'] == e['value']['variant'])
            fields = {field['name']:ev(value) for field,value in zip(definition['fields'], operands, strict=True)}
            return Nominal(kind, e['value']['identity'], fields, e['value'].get('variant'))
        if kind == 'field':
            value = ev(operands[0])
            return getattr(value, e['value']) if isinstance(value, Failure) else value.fields[e['value']]
        if kind == 'index':
            return self.index(ev(operands[0]), ev(operands[1]))
        if kind == 'unary':
            value, op = ev(operands[0]), e['value']
            if isinstance(value, Unknown):
                return self.propagate(t, [value])
            if op == 'not':
                return not value
            if op == '+':
                return value
            return value.negate() if isinstance(value, Quantity) else -value
        if kind == 'binary':
            left, op = ev(operands[0]), e['value']
            if op == 'and' and left is False:
                return False
            if op == 'or' and left is True:
                return True
            right = ev(operands[1])
            if op == 'and' and right is False:
                return False
            if op == 'or' and right is True:
                return True
            if isinstance(left, Unknown) or isinstance(right, Unknown):
                return self.propagate(t, [left,right])
            if op in {'and','or'}:
                return left and right if op == 'and' else left or right
            if op in {'==','!=','<','<=','>','>='}:
                if isinstance(left, Quantity):
                    return left.compare(right, op)
                if op in {'==','!='} and isinstance(left,(Nominal,Result,tuple,dict)):
                    equal = self.equal_values(left,right)
                    return equal if op == '==' else not equal
                return {'==':lambda:left == right, '!=':lambda:left != right, '<':lambda:left < right,'<=':lambda:left <= right,'>':lambda:left > right,'>=':lambda:left >= right}[op]()
            if isinstance(left, Quantity) or isinstance(right, Quantity):
                lq = left if isinstance(left,Quantity) else Quantity.known(Decimal(left))
                rq = right if isinstance(right,Quantity) else Quantity.known(Decimal(right))
                if op in {'+','-'}:
                    physical = _underlying(t)
                    if physical['kind'] == 'Measurement': physical = physical['arguments'][0]
                    unit = physical['unit']
                    uncertainty = None if lq.uncertainty_si is None and rq.uncertainty_si is None else (lq.uncertainty_si or Decimal(0)) + (rq.uncertainty_si or Decimal(0))
                    return Quantity(lq.magnitude_si + (1 if op == '+' else -1) * rq.magnitude_si,tuple(unit['dimension']),unit['text'] if unit['text'] in UNITS else '1',uncertainty,physical['kind']=='MassDelta')
                return lq.multiply(rq, divide=op == '/')
            if op == '/' and right == 0:
                raise BangelDiagnostic('DIVISION_ZERO', 'Division by zero is not admitted.')
            if op == '+': return left + right
            if op == '-': return left - right
            if op == '*': return left * right
            return Decimal(left) / Decimal(right)
        if kind == 'call':
            target = e['value']['target']
            arguments = [ev(x) for x in operands]
            if target in self.functions:
                return self.call(target, operands, arguments)
            return self.builtin(target, arguments, t)
        raise BangelDiagnostic('IR_VALUE_SERIALIZATION', f'Unregistered admitted value {kind!r}.')

    def index(self, value, key):
        if isinstance(value, dict):
            if key not in value:
                return Result('Err', Failure('KEY_NOT_FOUND','Map key is absent.'))
        elif key < 0 or key >= len(value):
            return Result('Err', Failure('INDEX_OUT_OF_BOUNDS','Vector index is outside its bounds.'))
        return Result('Ok', value[key])

    def call(self, target, operands, arguments):
        if self.depth >= self.limits.function_depth:
            raise BangelDiagnostic('FUNCTION_DEPTH', 'Function call depth budget exceeded.')
        instruction, owner_scope = self.functions[target]
        details = instruction['details']
        self.allocate(len(details['captures']) + len(arguments) + 1)
        local = Scope(values={c['name']:owner_scope.get(c['name']) for c in details['captures']})
        # Named argument order is source order in JP-IR, never parameter order.
        for index, (operand,value) in enumerate(zip(operands, arguments, strict=True)):
            local.values[operand['value']['name'] or details['params'][index]] = value
        self.depth += 1
        self.function_depth_used = max(self.function_depth_used,self.depth)
        try:
            self.block(details['body'],local)
            if self.status == 'HOLD':
                raise _Held()
            return self.evaluate(instruction['expression'],local)
        finally:
            self.depth -= 1

    def builtin(self, target, values, t):
        name = target.rsplit('.',1)[-1]
        if target == 'core.is_known':
            return not isinstance(values[0],Unknown)
        if any(isinstance(v,Unknown) for v in values):
            return self.propagate(t,values)
        if target == 'std.topology.dampen':
            value = values[0]
            return value.multiply(Quantity.known(Decimal(3)),divide=True) if isinstance(value,Quantity) else Decimal(value) / Decimal(3)
        if target in {'std.math.min','std.math.max'}:
            key = lambda value: value.magnitude_si if isinstance(value,Quantity) else value
            return (min if name == 'min' else max)(values,key=key)
        if target.startswith('std.map.'):
            mapping = values[0]
            if name == 'length': return len(mapping)
            if name == 'at': return self.index(mapping,values[1])
            keys = tuple(sorted(mapping, key=lambda x:x.encode('utf-8')))
            return keys if name == 'keys' else tuple(mapping[key] for key in keys)
        if target.startswith('std.vector.'):
            xs = values[0]
            if name == 'length': return len(xs)
            if name == 'at': return self.index(xs,values[1])
            if name == 'moving_mean':
                window = values[1]
                if window <= 0 or window > len(xs):
                    raise BangelDiagnostic('WINDOW_BOUNDS','Moving mean window is outside vector bounds.')
                self.allocate((len(xs)-window+1)*window)
                return tuple(self.aggregate(xs[i:i+window],t['arguments'][0],mean=True) for i in range(len(xs)-window+1))
            if name in {'sum','mean'}:
                return self.aggregate(xs,t,mean=name=='mean')
            if name in {'dot','slope'}:
                ys = values[1]
                if len(xs) != len(ys) or len(xs) < (2 if name == 'slope' else 1):
                    raise BangelDiagnostic('VECTOR_LENGTH','Vector lengths are outside the operation contract.')
            self.allocate(sum(len(v) for v in values if isinstance(v,tuple)))
            flat = [item for vector in values if isinstance(vector,tuple) for item in vector]
            if any(isinstance(item,Unknown) for item in flat):
                return self.propagate(t,flat)
            if name == 'dot':
                products = []
                for left,right in zip(xs,ys,strict=True):
                    self.poll()
                    if isinstance(left,Quantity) or isinstance(right,Quantity):
                        left = left if isinstance(left,Quantity) else Quantity.known(Decimal(left))
                        right = right if isinstance(right,Quantity) else Quantity.known(Decimal(right))
                        product = left.multiply(right)
                    else:
                        product = left * right
                    products.append(self.checked(product,t))
                return self.aggregate(products,t)
            if name == 'slope' and isinstance(xs[0],Quantity) and isinstance(ys[0],Quantity):
                denominator = xs[-1].magnitude_si-xs[0].magnitude_si
                if denominator == 0:
                    raise BangelDiagnostic('DIVISION_ZERO','Slope endpoints have equal independent values.')
                unit = _underlying(t)['unit']
                return Quantity((ys[-1].magnitude_si-ys[0].magnitude_si)/denominator,tuple(unit['dimension']),unit['text'] if unit['text'] in UNITS else '1',signed_delta=_underlying(t)['kind']=='MassDelta')
        if name == 'node_variance': name = 'variance'
        result = call_builtin(name, values)
        if isinstance(result, tuple) and t['kind'] == 'Vector':
            return tuple(self.checked(item,t['arguments'][0]) for item in result)
        return result

    def equal_values(self, left, right):
        """Structural equality uses physical values, never display-unit labels.

        Reserve each visited pair so nested/shared aggregates cannot bypass the
        work budget. Direct Unknown comparison is handled by the caller; nested
        sentinel equality retains the frozen structured Bool result contract.
        """
        self.allocate()
        if isinstance(left,Quantity) and isinstance(right,Quantity):
            return (left.dimension,left.magnitude_si,left.uncertainty_si,left.signed_delta) == (right.dimension,right.magnitude_si,right.uncertainty_si,right.signed_delta)
        if isinstance(left,Nominal) and isinstance(right,Nominal):
            return (left.kind,left.identity,left.variant) == (right.kind,right.identity,right.variant) and self.equal_values(left.fields,right.fields)
        if isinstance(left,Result) and isinstance(right,Result):
            return left.variant == right.variant and self.equal_values(left.value,right.value)
        if isinstance(left,tuple) and isinstance(right,tuple):
            return len(left) == len(right) and all(self.equal_values(a,b) for a,b in zip(left,right,strict=True))
        if isinstance(left,dict) and isinstance(right,dict):
            return left.keys() == right.keys() and all(self.equal_values(left[key],right[key]) for key in sorted(left))
        return left == right

    def aggregate(self, values, t, *, mean=False):
        if mean and not values:
            raise BangelDiagnostic('VECTOR_LENGTH','Mean requires a non-empty vector.')
        if any(isinstance(v,Unknown) for v in values):
            return self.propagate(t,values)
        base = _underlying(t)
        total = Decimal(0) if base['kind'] != 'Int' else 0
        for value in values:
            self.poll(); self.allocate()
            total += value.magnitude_si if isinstance(value,Quantity) else value
            if base['kind'] == 'Int': self.checked(total,t)
        if mean: total = Decimal(total) / len(values)
        if base['kind'] in {'Int','Real'}: return self.checked(total,t)
        unit = base['unit']
        return Quantity(Decimal(total),tuple(unit['dimension']),unit['text'] if unit['text'] in UNITS else '1',signed_delta=base['kind']=='MassDelta')

    def block(self, instructions, scope, *, owner=None):
        for instruction in instructions:
            if instruction['kind'] == 'function':
                self.allocate()
                self.functions[instruction['details']['target']] = (instruction,scope)
        for instruction in instructions:
            self.poll()
            if self.status == 'HOLD': return
            if self.instructions_used >= self.limits.instruction_limit:
                raise BangelDiagnostic('INSTRUCTION_LIMIT','Executed instruction budget exceeded.')
            self.instructions_used += 1
            requested = Stage(instruction['stage'])
            if CANONICAL_PATH.index(requested) > CANONICAL_PATH.index(self.stage):
                self.stage = requested
            stage = self.stage.value
            kind, details, name = instruction['kind'], instruction['details'], instruction.get('name')
            self.pending_indices.append(instruction['index'])
            ev = lambda: self.evaluate(instruction['expression'],scope)
            if kind == 'function':
                self.allocate(len(details['captures'])+1)
                self.event({'event':kind,'name':name,'params':details['params'],'pure':True,'stage':stage})
            elif kind in {'let','var','derive','measure','evidence','set'}:
                value = ev()
                if kind == 'measure':
                    value = value.with_uncertainty(self.evaluate(details['uncertainty'],scope))
                if kind == 'set': scope.set(name,value)
                else:
                    self.allocate()
                    value = self.checked(value,instruction['type'])
                    scope.values[name] = value
                    if kind == 'var': scope.mutable.add(name)
                    if owner is not None: self.globals[f'{owner}.{name}'] = value
                event = {'event':kind,'name':name,'value':self.encode(value),'stage':stage}
                if kind == 'evidence':
                    classification = details['class']
                    trust = 'DERIVED' if classification in {'MODEL','SIMULATED'} else 'UNATTESTED'
                    self.evidence.append({'name':name,'class':classification,'trust':trust,'value':event['value']})
                    event.update({'class':classification,'trust':trust,'authority_effect':'NONE'})
                self.event(event)
            elif kind == 'emit':
                value = self.encode(ev())
                # Include braces, escaped keys and separators in the exact output budget.
                candidate = {**self.outputs,name:value}
                size = len(canonical_bytes(candidate))
                if size > self.limits.output_limit:
                    raise BangelDiagnostic('OUTPUT_LIMIT','Runtime output byte budget exceeded.')
                self.output_bytes = size
                self.outputs = candidate
                self.event({'event':kind,'name':name,'stage':stage})
            elif kind == 'require':
                value = ev()
                if isinstance(value,Unknown) or value is False:
                    self.status = 'HOLD'
                    self.hold_code = 'REQUIREMENT_UNKNOWN' if isinstance(value,Unknown) else details['code']
                    event = {'event':kind,'result':None if isinstance(value,Unknown) else False,'hold_code':self.hold_code,'stage':stage}
                    if isinstance(value,Unknown): event['requested_code'] = details['code']
                    self.event(event)
                else:
                    self.event({'event':kind,'result':True,'stage':stage})
            elif kind == 'if':
                condition = ev()
                if isinstance(condition,Unknown):
                    raise BangelDiagnostic('UNKNOWN_CONDITION','Unknown if condition cannot select a branch.',SourceSpan(**instruction['span']))
                self.event({'event':kind,'result':condition,'stage':stage})
                self.allocate()
                self.block(details['then' if condition else 'else'],Scope(scope))
            elif kind == 'for':
                values = ev()
                if len(values) > details['limit']:
                    raise BangelDiagnostic('LOOP_LIMIT_EXCEEDED','Vector exceeds the declared loop limit.')
                self.event({'event':kind,'count':len(values),'stage':stage})
                for value in values:
                    self.poll(); self.allocate(2)
                    self.block(details['body'],Scope(scope, {name:value}))
                    if self.status == 'HOLD': break
            elif kind == 'match':
                value = ev()
                tag = value.variant
                case = next(case for case in details['cases'] if case['tag'][-1] == tag)
                bindings = [value.value] if isinstance(value,Result) else list(value.fields.values())
                self.allocate(len(bindings)+1)
                local = Scope(scope, dict(zip(case['bindings'],bindings,strict=True)))
                self.event({'event':kind,'tag':case['tag'],'stage':stage})
                self.block(case['body'],local)
            else:
                raise BangelDiagnostic('IR_INSTRUCTION_SERIALIZATION',f'Unregistered admitted instruction {kind!r}.')

    def execute(self):
        try:
            for module in self.ir['modules']:
                self.allocate()
                self.block(module['instructions'],Scope(),owner=module['name'])
            self.allocate()
            self.block(self.ir['instructions'],Scope(),owner=self.ir['program'])
        except _Held:
            pass
        self.traversal.enter(Stage.R2,None,'receipt_binding_living_static')
        self.traversal.complete()
        self.output_bytes = len(canonical_bytes(self.outputs))
        resource = {name:getattr(self.limits,name) for name in ('instruction_limit','event_limit','function_depth','evaluation_limit','allocation_limit','output_limit','receipt_limit')}
        resource.update(evaluations_used=self.evaluations_used,instructions_used=self.instructions_used,events_used=len(self.events),allocations_used=self.allocations_used,output_bytes=self.output_bytes,function_depth_used=self.function_depth_used)
        receipt = bind_receipt({'profile':'Joanna-Receipt/1','runtime':{'name':'Joanna','protocol':RUNTIME_PROTOCOL,'version':self.limits.version},'program':self.ir['program'],'program_root':self.ir['program_root'],'status':self.status,'hold_code':self.hold_code,'outputs':self.outputs,'roles':{},'evidence':self.evidence,'events':self.events,'traversal':self.traversal.events,'resource_limits':resource,'state_meanings':{'R1':'Unidentified transition','R2':'Living static','N1':'First prediction node'},'prediction_nodes':[s.value for s in PREDICTION_NODES]})
        if len(canonical_bytes(receipt)) > self.limits.receipt_limit:
            raise BangelDiagnostic('RECEIPT_LIMIT','Runtime receipt byte budget exceeded.')
        if self.output_bytes > self.limits.output_limit:
            raise BangelDiagnostic('OUTPUT_LIMIT','Runtime output byte budget exceeded.')
        verify_receipt(receipt)
        return receipt


class _Held(Exception):
    """Internal function-body requirement unwinding; never escapes execution."""


def execute_strict(compilation, limits, *, cancelled: Callable[[],bool] | None = None):
    with localcontext(DECIMAL128):
        try:
            return Machine(compilation,limits,cancelled).execute()
        except RecursionError as exc:
            raise BangelDiagnostic('FUNCTION_DEPTH','Host stack budget exceeded.') from exc
        except DecimalException as exc:
            raise BangelDiagnostic('DECIMAL_NONFINITE','Operation is outside finite decimal128.') from exc
