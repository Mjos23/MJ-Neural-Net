from __future__ import annotations

import json
import re

from ..diagnostics import BangelDiagnostic, SourceSpan
from ..source import MAX_SOURCE_BYTES
from .tokens import Token, TokenKind


_IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_NUMBER = re.compile(
    r"(?:0|[1-9][0-9]*)(?:\.[0-9]+(?:[eE][+-]?[0-9]+)?|[eE][+-]?[0-9]+)?"
)
_OPEN_TO_CLOSE = {"(": ")", "[": "]", "{": "}"}
_CLOSE_TO_OPEN = {close: open_ for open_, close in _OPEN_TO_CLOSE.items()}
_PUNCTUATION = {
    "(": TokenKind.LPAREN,
    ")": TokenKind.RPAREN,
    "[": TokenKind.LBRACKET,
    "]": TokenKind.RBRACKET,
    "{": TokenKind.LBRACE,
    "}": TokenKind.RBRACE,
    ",": TokenKind.COMMA,
    ":": TokenKind.COLON,
    ".": TokenKind.DOT,
    ";": TokenKind.SEMICOLON,
    "=": TokenKind.EQUAL,
}


def _normalized_text(source: str) -> str:
    if not isinstance(source, str):
        raise BangelDiagnostic("SOURCE_TYPE", "Source must be UTF-8 text.")
    normalized = source.replace("\r\n", "\n").replace("\r", "\n")
    if normalized.startswith("\ufeff"):
        raise BangelDiagnostic("SOURCE_BOM", "Bangel source must not contain a UTF-8 BOM.")
    try:
        encoded = normalized.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise BangelDiagnostic("SOURCE_UTF8", "Source contains a non-scalar Unicode value.") from exc
    if len(encoded) > MAX_SOURCE_BYTES:
        raise BangelDiagnostic(
            "SOURCE_SIZE", f"Source exceeds the {MAX_SOURCE_BYTES}-byte profile."
        )
    if "\0" in normalized:
        raise BangelDiagnostic("SOURCE_NUL", "NUL bytes are not admitted.")
    return normalized


def _without_comment(line: str) -> str:
    in_string = False
    escaped = False
    for index, character in enumerate(line):
        if in_string:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == '"':
                in_string = False
        elif character == '"':
            in_string = True
        elif character == "#":
            return line[:index]
    return line


def _string_token(line: str, start: int, line_number: int) -> tuple[str, int]:
    index = start + 1
    escaped = False
    while index < len(line):
        character = line[index]
        if ord(character) < 0x20:
            raise BangelDiagnostic(
                "STRING_CONTROL",
                "Text literals cannot contain unescaped control characters.",
                SourceSpan(line_number, index + 1),
            )
        if escaped:
            escaped = False
        elif character == "\\":
            escaped = True
        elif character == '"':
            text = line[start : index + 1]
            try:
                value = json.loads(text)
            except json.JSONDecodeError as exc:
                raise BangelDiagnostic(
                    "STRING_INVALID",
                    "Text literals use RFC 8259 JSON string syntax.",
                    SourceSpan(line_number, start + 1),
                ) from exc
            if any(0xD800 <= ord(scalar) <= 0xDFFF for scalar in value):
                raise BangelDiagnostic(
                    "STRING_UNICODE",
                    "Text literals must contain Unicode scalar values.",
                    SourceSpan(line_number, start + 1),
                )
            return text, index + 1
        index += 1
    raise BangelDiagnostic(
        "STRING_UNTERMINATED",
        "Text literal is missing its closing quote.",
        SourceSpan(line_number, start + 1),
    )


def lex(source: str) -> tuple[Token, ...]:
    """Tokenize the frozen Bangel 1.0 surface after its lexical preprocessing."""

    normalized = _normalized_text(source)
    tokens: list[Token] = []
    delimiters: list[tuple[str, SourceSpan]] = []
    logical_has_tokens = False

    for line_number, physical_line in enumerate(normalized.split("\n"), 1):
        if "\t" in physical_line:
            raise BangelDiagnostic(
                "SOURCE_TAB", "Tabs are not admitted anywhere in source.", SourceSpan(line_number)
            )
        line = _without_comment(physical_line.rstrip(" "))
        index = 0
        continuation = bool(delimiters and logical_has_tokens)
        saw_space = continuation
        line_added_token = False

        while index < len(line):
            character = line[index]
            if character == " ":
                saw_space = True
                index += 1
                continue
            if ord(character) < 0x20:
                raise BangelDiagnostic(
                    "LEX_CONTROL",
                    "Unexpected control character outside a Text literal.",
                    SourceSpan(line_number, index + 1),
                )

            start = index
            span = SourceSpan(line_number, start + 1)
            leading_space = saw_space
            saw_space = False

            if character == '"':
                text, index = _string_token(line, start, line_number)
                token = Token(
                    TokenKind.STRING,
                    text,
                    SourceSpan(line_number, start + 1, index + 1),
                    leading_space,
                )
            elif character.isascii() and (character.isalpha() or character == "_"):
                match = _IDENTIFIER.match(line, index)
                assert match is not None
                index = match.end()
                token = Token(
                    TokenKind.IDENT,
                    match.group(),
                    SourceSpan(line_number, start + 1, index + 1),
                    leading_space,
                )
            elif character.isdigit():
                match = _NUMBER.match(line, index)
                assert match is not None
                index = match.end()
                if index < len(line) and (line[index].isdigit() or line[index] in ".eE"):
                    raise BangelDiagnostic(
                        "NUMBER_INVALID",
                        "Numeric literal is not a Bangel Int or Real token.",
                        span,
                    )
                token = Token(
                    TokenKind.NUMBER,
                    match.group(),
                    SourceSpan(line_number, start + 1, index + 1),
                    leading_space,
                )
            elif line.startswith("+/-", index):
                index += 3
                token = Token(
                    TokenKind.PLUS_MINUS,
                    "+/-",
                    SourceSpan(line_number, start + 1, index + 1),
                    leading_space,
                )
            elif line.startswith("->", index):
                index += 2
                token = Token(
                    TokenKind.ARROW,
                    "->",
                    SourceSpan(line_number, start + 1, index + 1),
                    leading_space,
                )
            elif line.startswith(("==", "!=", "<=", ">="), index):
                text = line[index : index + 2]
                index += 2
                token = Token(
                    TokenKind.OPERATOR,
                    text,
                    SourceSpan(line_number, start + 1, index + 1),
                    leading_space,
                )
            elif character in "+-*/<>^":
                index += 1
                token = Token(
                    TokenKind.OPERATOR,
                    character,
                    SourceSpan(line_number, start + 1, index + 1),
                    leading_space,
                )
            elif character in _PUNCTUATION:
                index += 1
                token = Token(
                    _PUNCTUATION[character],
                    character,
                    SourceSpan(line_number, start + 1, index + 1),
                    leading_space,
                )
            elif not character.isascii() and (character.isalpha() or character.isidentifier()):
                raise BangelDiagnostic(
                    "IDENTIFIER_ASCII",
                    "Bangel 1.0 identifiers are ASCII only.",
                    span,
                )
            else:
                raise BangelDiagnostic(
                    "LEX_CHARACTER", f"Unexpected character {character!r}.", span
                )

            if token.kind in {TokenKind.LPAREN, TokenKind.LBRACKET, TokenKind.LBRACE}:
                delimiters.append((token.text, token.span))
            elif token.kind in {TokenKind.RPAREN, TokenKind.RBRACKET, TokenKind.RBRACE}:
                expected_open = _CLOSE_TO_OPEN[token.text]
                if not delimiters or delimiters[-1][0] != expected_open:
                    raise BangelDiagnostic(
                        "DELIMITER_MISMATCH",
                        f"Closing delimiter {token.text!r} does not match the open delimiter.",
                        token.span,
                    )
                delimiters.pop()

            tokens.append(token)
            logical_has_tokens = True
            line_added_token = True

        if not delimiters and logical_has_tokens and line_added_token:
            tokens.append(
                Token(
                    TokenKind.NEWLINE,
                    "\n",
                    SourceSpan(line_number, len(physical_line.rstrip(" ")) + 1),
                )
            )
            logical_has_tokens = False

    if delimiters:
        opening, span = delimiters[-1]
        raise BangelDiagnostic(
            "DELIMITER_UNCLOSED",
            f"Opening delimiter {opening!r} is not closed.",
            span,
        )
    if not tokens:
        raise BangelDiagnostic("SOURCE_EMPTY", "Bangel source cannot be empty.")
    if tokens[-1].kind is not TokenKind.NEWLINE:
        last = tokens[-1].span
        tokens.append(Token(TokenKind.NEWLINE, "\n", last))
    eof_span = tokens[-1].span
    tokens.append(Token(TokenKind.EOF, "", eof_span))
    return tuple(tokens)
