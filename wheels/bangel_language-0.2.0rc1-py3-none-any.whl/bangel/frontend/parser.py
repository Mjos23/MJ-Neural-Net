from __future__ import annotations

import json
import re
from decimal import Decimal, InvalidOperation

from ..diagnostics import BangelDiagnostic, SourceSpan
from .ast import (
    Argument,
    BinaryExpression,
    BooleanLiteral,
    CallExpression,
    CaseArm,
    DeriveStatement,
    EmitStatement,
    EnumDeclaration,
    EvidenceStatement,
    FailureConstructor,
    FailureType,
    FieldDeclaration,
    FieldExpression,
    ForStatement,
    FunctionDeclaration,
    IfStatement,
    ImportDeclaration,
    IndexExpression,
    IntegerLiteral,
    LetStatement,
    MapEntry,
    MapLiteral,
    MapType,
    MassDeltaExpression,
    MassDeltaType,
    MatchStatement,
    MeasurementType,
    MeasureStatement,
    ModuleSource,
    NameExpression,
    NamedType,
    Parameter,
    ProgramSource,
    QuantityLiteral,
    QuantityType,
    RealLiteral,
    RecordDeclaration,
    RequireStatement,
    ResultConstructor,
    ResultType,
    ScalarType,
    SetStatement,
    StatementSyntax,
    TextLiteral,
    TypeSyntax,
    UnaryExpression,
    UnitExpression,
    UnitTerm,
    UnknownExpression,
    UnknownType,
    VarStatement,
    VariantDeclaration,
    VectorLiteral,
    VectorType,
)
from .lexer import lex
from .tokens import Token, TokenKind


LANGUAGE_IDENTITY = "Bangel/1.0"
SOURCE_HEADER = "bangel 1.0"
MAX_VECTOR_LENGTH = 65_536

RESERVED_WORDS = frozenset(
    {
        "bangel",
        "program",
        "module",
        "effects",
        "pure",
        "evidence",
        "model",
        "simulated",
        "observed",
        "external",
        "import",
        "as",
        "export",
        "record",
        "enum",
        "function",
        "capture",
        "return",
        "let",
        "derive",
        "var",
        "set",
        "measure",
        "require",
        "else",
        "emit",
        "if",
        "end",
        "for",
        "in",
        "limit",
        "match",
        "case",
        "true",
        "false",
        "and",
        "or",
        "not",
        "unknown",
        "mass_delta",
        "Bool",
        "Text",
        "Int",
        "Real",
        "Quantity",
        "MassDelta",
        "Measurement",
        "Unknown",
        "Vector",
        "Map",
        "Result",
        "Failure",
    }
)
EXCLUDED_CORE_WORDS = frozenset({"node", "mirror", "collect", "role"})
SCALAR_TYPES = frozenset({"Bool", "Text", "Int", "Real"})
EVIDENCE_CLASSES = frozenset({"model", "simulated", "observed", "external"})
_DIAGNOSTIC_CODE = re.compile(r"[A-Z][A-Z0-9_]*\Z")


class Parser:
    def __init__(self, tokens: tuple[Token, ...], source_name: str | None):
        self.tokens = tokens
        self.source_name = source_name
        self.index = 0

    def parse(self) -> ProgramSource | ModuleSource:
        header_span = self._parse_header()
        if self._at_word("program"):
            self._take()
            name = self._identifier("PROGRAM_NAME")
            self._line_end("PROGRAM_DECLARATION")
            effects = self._effects(module=False)
            imports = self._imports()
            items = []
            while not self._at(TokenKind.EOF):
                if self._at_word("export"):
                    raise self._error(
                        "PROGRAM_EXPORT",
                        "export is admitted only in a Bangel module.",
                    )
                items.append(self._top_level_item())
            if not items:
                raise BangelDiagnostic(
                    "PROGRAM_EMPTY", "A Bangel program requires at least one top-level item."
                )
            return ProgramSource(
                LANGUAGE_IDENTITY,
                self.source_name,
                name,
                effects,
                tuple(imports),
                tuple(items),
                header_span,
            )

        if self._at_word("module"):
            self._take()
            name = self._qualified_name("MODULE_NAME")
            self._line_end("MODULE_DECLARATION")
            effects = self._effects(module=True)
            imports = self._imports()
            items = []
            while not self._at(TokenKind.EOF):
                items.append(self._module_item())
            if not items:
                raise BangelDiagnostic(
                    "MODULE_EMPTY", "A Bangel module requires at least one module item."
                )
            if not any(getattr(item, "exported", False) for item in items):
                raise BangelDiagnostic(
                    "MODULE_EXPORT_REQUIRED",
                    "A Bangel 1.0 module requires at least one exported declaration.",
                    header_span,
                )
            return ModuleSource(
                LANGUAGE_IDENTITY,
                self.source_name,
                name,
                effects,
                tuple(imports),
                tuple(items),
                header_span,
            )

        raise self._error(
            "SOURCE_DECLARATION",
            "The second meaningful line must declare exactly one program or module.",
        )

    def _parse_header(self) -> SourceSpan:
        first = self._peek()
        if not self._at_word("bangel"):
            raise self._error(
                "LANGUAGE_HEADER_REQUIRED",
                "Source must begin on its first meaningful line with 'bangel 1.0'.",
            )
        self._take()
        header_tokens: list[Token] = []
        while not self._at(TokenKind.NEWLINE) and not self._at(TokenKind.EOF):
            header_tokens.append(self._take())
        spelling = tuple(token.text for token in header_tokens)
        if spelling in {("1.1",), ("0.1",), ("physics", "0.1")}:
            raise BangelDiagnostic(
                "PROFILE_REQUIRES_COMPAT",
                "Historical Bangel syntax requires an explicit compatibility profile.",
                first.span,
            )
        if spelling != ("1.0",):
            raise BangelDiagnostic(
                "LANGUAGE_VERSION_UNSUPPORTED",
                "Elsa/1 accepts exactly the Bangel/1.0 core source header.",
                first.span,
            )
        if not header_tokens[0].leading_space:
            raise BangelDiagnostic(
                "LANGUAGE_HEADER_REQUIRED",
                "The header tokens 'bangel' and '1.0' must be separated by SPACE.",
                header_tokens[0].span,
            )
        self._expect(TokenKind.NEWLINE, "LANGUAGE_HEADER_REQUIRED")
        return first.span

    def _effects(self, *, module: bool) -> tuple[str, ...]:
        if not self._at_word("effects"):
            raise self._error(
                "EFFECTS_DECLARATION",
                "The third meaningful line must declare effects.",
            )
        self._take()
        self._expect_word("pure", "EFFECTS_DECLARATION")
        effects = ["pure"]
        if self._match(TokenKind.COMMA):
            self._expect_word("evidence", "EFFECTS_DECLARATION")
            effects.append("evidence")
        if module and len(effects) != 1:
            raise self._error(
                "MODULE_EFFECT", "Bangel 1.0 modules must declare exactly 'effects pure'."
            )
        self._line_end("EFFECTS_DECLARATION")
        return tuple(effects)

    def _imports(self) -> list[ImportDeclaration]:
        imports: list[ImportDeclaration] = []
        while self._at_word("import"):
            start = self._take().span
            module = self._qualified_name("IMPORT_NAME")
            alias: str | None = None
            selection: tuple[str, ...] = ()
            if self._at_word("as"):
                self._take()
                alias = self._identifier("IMPORT_ALIAS")
            elif self._match(TokenKind.LBRACE):
                names = [self._identifier("IMPORT_SELECTION")]
                while self._match(TokenKind.COMMA):
                    names.append(self._identifier("IMPORT_SELECTION"))
                self._expect(TokenKind.RBRACE, "IMPORT_SELECTION")
                selection = tuple(names)
            self._line_end("IMPORT_DECLARATION")
            imports.append(ImportDeclaration(module, alias, selection, start))
        return imports

    def _top_level_item(self):
        if self._at_word("record"):
            return self._record(exported=False)
        if self._at_word("enum"):
            return self._enum(exported=False)
        if self._at_word("function"):
            return self._function(exported=False)
        return self._statement()

    def _module_item(self):
        if self._at_word("export"):
            export = self._take()
            if self._at_word("record"):
                return self._record(exported=True, span=export.span)
            if self._at_word("enum"):
                return self._enum(exported=True, span=export.span)
            if self._at_word("function"):
                return self._function(exported=True, span=export.span)
            if self._at_word("let"):
                return self._binding("let", exported=True, span=export.span)
            if self._at_word("derive"):
                return self._binding("derive", exported=True, span=export.span)
            raise self._error(
                "EXPORT_DECLARATION",
                "A module may export a record, enum, function, let, or derive declaration.",
            )
        if self._at_word("record"):
            return self._record(exported=False)
        if self._at_word("enum"):
            return self._enum(exported=False)
        if self._at_word("function"):
            return self._function(exported=False)
        if self._at_word("let"):
            return self._binding("let")
        if self._at_word("derive"):
            return self._binding("derive")
        raise self._error(
            "MODULE_EXECUTABLE_STATEMENT",
            "Modules admit declarations and immutable bindings only.",
        )

    def _record(self, *, exported: bool, span: SourceSpan | None = None) -> RecordDeclaration:
        start = span or self._peek().span
        self._expect_word("record", "RECORD_DECLARATION")
        name = self._identifier("RECORD_NAME")
        self._line_end("RECORD_DECLARATION")
        fields: list[FieldDeclaration] = []
        while not self._at_word("end"):
            if self._at(TokenKind.EOF):
                raise self._error("RECORD_END", "record requires a closing end.")
            field_span = self._peek().span
            field_name = self._identifier("FIELD_NAME")
            field_type = self._type_annotation(required_code="TYPE_ANNOTATION_REQUIRED")
            self._line_end("FIELD_DECLARATION")
            fields.append(FieldDeclaration(field_name, field_type, field_span))
        if not fields:
            raise self._error("RECORD_FIELD_REQUIRED", "A record requires at least one field.")
        self._take()
        self._line_end("RECORD_END")
        return RecordDeclaration(name, tuple(fields), exported, start)

    def _enum(self, *, exported: bool, span: SourceSpan | None = None) -> EnumDeclaration:
        start = span or self._peek().span
        self._expect_word("enum", "ENUM_DECLARATION")
        name = self._identifier("ENUM_NAME")
        self._line_end("ENUM_DECLARATION")
        variants: list[VariantDeclaration] = []
        while not self._at_word("end"):
            if self._at(TokenKind.EOF):
                raise self._error("ENUM_END", "enum requires a closing end.")
            variant_span = self._peek().span
            variant_name = self._identifier("VARIANT_NAME")
            payload: list[FieldDeclaration] = []
            if self._match(TokenKind.LPAREN):
                payload.append(self._payload_field())
                while self._match(TokenKind.COMMA):
                    payload.append(self._payload_field())
                self._expect(TokenKind.RPAREN, "VARIANT_PAYLOAD")
            self._line_end("VARIANT_DECLARATION")
            variants.append(VariantDeclaration(variant_name, tuple(payload), variant_span))
        if not variants:
            raise self._error("ENUM_VARIANT_REQUIRED", "An enum requires at least one variant.")
        self._take()
        self._line_end("ENUM_END")
        return EnumDeclaration(name, tuple(variants), exported, start)

    def _payload_field(self) -> FieldDeclaration:
        span = self._peek().span
        name = self._identifier("PAYLOAD_FIELD")
        value_type = self._type_annotation(required_code="TYPE_ANNOTATION_REQUIRED")
        return FieldDeclaration(name, value_type, span)

    def _function(
        self, *, exported: bool, span: SourceSpan | None = None
    ) -> FunctionDeclaration:
        start = span or self._peek().span
        self._expect_word("function", "FUNCTION_DECLARATION")
        name = self._identifier("FUNCTION_NAME")
        self._expect(TokenKind.LPAREN, "FUNCTION_PARAMETERS")
        parameters: list[Parameter] = []
        if not self._at(TokenKind.RPAREN):
            parameters.append(self._parameter())
            while self._match(TokenKind.COMMA):
                parameters.append(self._parameter())
        self._expect(TokenKind.RPAREN, "FUNCTION_PARAMETERS")
        self._expect(TokenKind.ARROW, "FUNCTION_RETURN_TYPE")
        return_type = self._type()
        captures: list[str] = []
        if self._at_word("capture"):
            self._take()
            captures.append(self._identifier("FUNCTION_CAPTURE"))
            while self._match(TokenKind.COMMA):
                captures.append(self._identifier("FUNCTION_CAPTURE"))
        self._line_end("FUNCTION_DECLARATION")

        body: list[StatementSyntax] = []
        while not self._at_word("return"):
            if self._at_word("end") or self._at(TokenKind.EOF):
                raise self._error(
                    "FUNCTION_RETURN_REQUIRED",
                    "A function requires exactly one final return expression.",
                )
            body.append(self._statement())
        self._take()
        return_expression = self._expression()
        self._line_end("FUNCTION_RETURN")
        self._expect_word("end", "FUNCTION_END")
        self._line_end("FUNCTION_END")
        return FunctionDeclaration(
            name,
            tuple(parameters),
            return_type,
            tuple(captures),
            tuple(body),
            return_expression,
            exported,
            start,
        )

    def _parameter(self) -> Parameter:
        span = self._peek().span
        name = self._identifier("FUNCTION_PARAMETER")
        value_type = self._type_annotation(required_code="TYPE_ANNOTATION_REQUIRED")
        return Parameter(name, value_type, span)

    def _statement(self) -> StatementSyntax:
        if self._at_word("let"):
            return self._binding("let")
        if self._at_word("derive"):
            return self._binding("derive")
        if self._at_word("var"):
            return self._var()
        if self._at_word("set"):
            return self._set()
        if self._at_word("measure"):
            return self._measure()
        if self._at_word("evidence"):
            return self._evidence()
        if self._at_word("require"):
            return self._require()
        if self._at_word("emit"):
            return self._emit()
        if self._at_word("if"):
            return self._if()
        if self._at_word("for"):
            return self._for()
        if self._at_word("match"):
            return self._match_statement()
        if self._peek().kind is TokenKind.IDENT and self._peek().text in EXCLUDED_CORE_WORDS:
            raise self._error(
                "CORE_SYNTAX_EXCLUDED",
                "node, mirror, collect, and role are not Bangel 1.0 core statements.",
            )
        raise self._error(
            "STATEMENT_UNKNOWN", f"Unknown Bangel 1.0 statement {self._peek().text!r}."
        )

    def _binding(
        self,
        kind: str,
        *,
        exported: bool = False,
        span: SourceSpan | None = None,
    ) -> LetStatement | DeriveStatement:
        start = span or self._peek().span
        self._expect_word(kind, "BINDING_DECLARATION")
        name = self._identifier("BINDING_NAME")
        annotation = self._optional_type_annotation()
        if exported and annotation is None:
            raise self._error(
                "EXPORT_TYPE_REQUIRED", "Exported let and derive bindings require a type."
            )
        self._expect(TokenKind.EQUAL, "BINDING_INITIALIZER")
        expression = self._expression()
        self._line_end("BINDING_DECLARATION")
        if kind == "let":
            return LetStatement(name, annotation, expression, exported, start)
        return DeriveStatement(name, annotation, expression, exported, start)

    def _var(self) -> VarStatement:
        start = self._take().span
        name = self._identifier("BINDING_NAME")
        if not self._at(TokenKind.COLON):
            raise self._error(
                "TYPE_ANNOTATION_REQUIRED", "var bindings require an explicit type."
            )
        annotation = self._type_annotation(required_code="TYPE_ANNOTATION_REQUIRED")
        self._expect(TokenKind.EQUAL, "BINDING_INITIALIZER")
        expression = self._expression()
        self._line_end("BINDING_DECLARATION")
        return VarStatement(name, annotation, expression, start)

    def _set(self) -> SetStatement:
        start = self._take().span
        name = self._identifier("SET_NAME")
        self._expect(TokenKind.EQUAL, "SET_ASSIGNMENT")
        expression = self._expression()
        self._line_end("SET_ASSIGNMENT")
        return SetStatement(name, expression, start)

    def _measure(self) -> MeasureStatement:
        start = self._take().span
        name = self._identifier("MEASURE_NAME")
        annotation = self._type_annotation(required_code="TYPE_ANNOTATION_REQUIRED")
        if not isinstance(annotation, MeasurementType):
            raise BangelDiagnostic(
                "MEASUREMENT_TYPE",
                "measure requires Measurement[Quantity[U]] or Measurement[MassDelta[U]].",
                annotation.span,
            )
        self._expect(TokenKind.EQUAL, "MEASURE_INITIALIZER")
        nominal = self._expression()
        self._expect(TokenKind.PLUS_MINUS, "MEASURE_UNCERTAINTY")
        uncertainty = self._expression()
        self._line_end("MEASURE_DECLARATION")
        return MeasureStatement(name, annotation, nominal, uncertainty, start)

    def _evidence(self) -> EvidenceStatement:
        start = self._take().span
        evidence_class = self._peek()
        if evidence_class.kind is not TokenKind.IDENT or evidence_class.text not in EVIDENCE_CLASSES:
            raise self._error(
                "EVIDENCE_CLASS",
                "Evidence class must be model, simulated, observed, or external.",
            )
        self._take()
        name = self._identifier("EVIDENCE_NAME")
        annotation = self._optional_type_annotation()
        self._expect(TokenKind.EQUAL, "EVIDENCE_INITIALIZER")
        expression = self._expression()
        self._line_end("EVIDENCE_DECLARATION")
        return EvidenceStatement(evidence_class.text, name, annotation, expression, start)

    def _require(self) -> RequireStatement:
        start = self._take().span
        condition = self._expression()
        self._expect_word("else", "REQUIRE_ELSE")
        code = self._take()
        if code.kind is not TokenKind.IDENT or _DIAGNOSTIC_CODE.fullmatch(code.text) is None:
            raise BangelDiagnostic(
                "DIAGNOSTIC_CODE",
                "require failure codes use [A-Z][A-Z0-9_]*.",
                code.span,
            )
        self._line_end("REQUIRE_DECLARATION")
        return RequireStatement(condition, code.text, start)

    def _emit(self) -> EmitStatement:
        start = self._take().span
        if self._peek().kind is not TokenKind.IDENT or self._peek().text in RESERVED_WORDS:
            raise self._error(
                "EMIT_NAME_REQUIRED", "Bangel 1.0 emit requires 'emit name = expression'."
            )
        name = self._identifier("EMIT_NAME_REQUIRED")
        if not self._at(TokenKind.EQUAL):
            raise self._error(
                "EMIT_NAME_REQUIRED", "Bangel 1.0 emit requires 'emit name = expression'."
            )
        self._take()
        expression = self._expression()
        self._line_end("EMIT_DECLARATION")
        return EmitStatement(name, expression, start)

    def _if(self) -> IfStatement:
        start = self._take().span
        condition = self._expression()
        self._line_end("IF_DECLARATION")
        then_body = self._statement_block({"else", "end"})
        else_body: tuple[StatementSyntax, ...] = ()
        if self._at_word("else"):
            self._take()
            self._line_end("IF_ELSE")
            else_body = tuple(self._statement_block({"end"}))
        self._expect_word("end", "IF_END")
        self._line_end("IF_END")
        return IfStatement(condition, tuple(then_body), else_body, start)

    def _for(self) -> ForStatement:
        start = self._take().span
        name = self._identifier("LOOP_BINDING")
        self._expect_word("in", "LOOP_IN")
        iterable = self._expression()
        if not self._at_word("limit"):
            raise self._error(
                "LOOP_LIMIT_REQUIRED", "Every Bangel 1.0 for loop requires a literal limit."
            )
        self._take()
        limit = self._positive_integer(maximum=MAX_VECTOR_LENGTH)
        self._line_end("LOOP_DECLARATION")
        body = self._statement_block({"end"})
        self._expect_word("end", "LOOP_END")
        self._line_end("LOOP_END")
        return ForStatement(name, iterable, limit, tuple(body), start)

    def _match_statement(self) -> MatchStatement:
        start = self._take().span
        expression = self._expression()
        self._line_end("MATCH_DECLARATION")
        cases: list[CaseArm] = []
        while self._at_word("case"):
            case_span = self._take().span
            tag = self._case_tag()
            bindings: list[str] = []
            if self._match(TokenKind.LPAREN):
                if not self._at(TokenKind.RPAREN):
                    bindings.append(self._identifier("PATTERN_BINDING"))
                    while self._match(TokenKind.COMMA):
                        bindings.append(self._identifier("PATTERN_BINDING"))
                self._expect(TokenKind.RPAREN, "CASE_PATTERN")
            self._line_end("CASE_DECLARATION")
            body = self._statement_block({"case", "end"})
            cases.append(CaseArm(tag, tuple(bindings), tuple(body), case_span))
        if not cases:
            raise self._error("MATCH_CASE_REQUIRED", "match requires at least one case arm.")
        self._expect_word("end", "MATCH_END")
        self._line_end("MATCH_END")
        return MatchStatement(expression, tuple(cases), start)

    def _case_tag(self) -> tuple[str, ...]:
        if self._at_word("Result"):
            self._take()
            self._expect(TokenKind.DOT, "CASE_TAG")
            variant = self._peek()
            if variant.kind is not TokenKind.IDENT or variant.text not in {"Ok", "Err"}:
                raise self._error("CASE_TAG", "Result case tag must be Result.Ok or Result.Err.")
            self._take()
            return ("Result", variant.text)
        return self._qualified_name("CASE_TAG")

    def _statement_block(self, stop_words: set[str]) -> list[StatementSyntax]:
        statements: list[StatementSyntax] = []
        while not self._at(TokenKind.EOF) and not any(
            self._at_word(word) for word in stop_words
        ):
            statements.append(self._statement())
        return statements

    def _optional_type_annotation(self) -> TypeSyntax | None:
        if not self._match(TokenKind.COLON):
            return None
        return self._type()

    def _type_annotation(self, *, required_code: str) -> TypeSyntax:
        self._expect(TokenKind.COLON, required_code)
        return self._type()

    def _type(self) -> TypeSyntax:
        token = self._peek()
        if token.kind is not TokenKind.IDENT:
            raise self._error("TYPE_EXPECTED", "Expected a Bangel 1.0 type.")
        self._take()
        if token.text in SCALAR_TYPES:
            return ScalarType(token.text, token.span)
        if token.text == "Failure":
            return FailureType(token.span)
        if token.text in {"Quantity", "MassDelta"}:
            self._expect(TokenKind.LBRACKET, "TYPE_ARGUMENT")
            unit = self._unit_expression()
            self._expect(TokenKind.RBRACKET, "TYPE_ARGUMENT")
            if token.text == "Quantity":
                return QuantityType(unit, token.span)
            return MassDeltaType(unit, token.span)
        if token.text == "Measurement":
            self._expect(TokenKind.LBRACKET, "TYPE_ARGUMENT")
            value_type = self._type()
            if not isinstance(value_type, (QuantityType, MassDeltaType)):
                raise BangelDiagnostic(
                    "MEASUREMENT_TYPE",
                    "Measurement type argument must be Quantity or MassDelta.",
                    value_type.span,
                )
            self._expect(TokenKind.RBRACKET, "TYPE_ARGUMENT")
            return MeasurementType(value_type, token.span)
        if token.text == "Unknown":
            self._expect(TokenKind.LBRACKET, "TYPE_ARGUMENT")
            value_type = self._type()
            self._expect(TokenKind.RBRACKET, "TYPE_ARGUMENT")
            return UnknownType(value_type, token.span)
        if token.text == "Vector":
            self._expect(TokenKind.LBRACKET, "TYPE_ARGUMENT")
            item_type = self._type()
            size: int | None = None
            if self._match(TokenKind.SEMICOLON):
                size = self._positive_integer(maximum=MAX_VECTOR_LENGTH)
            self._expect(TokenKind.RBRACKET, "TYPE_ARGUMENT")
            return VectorType(item_type, size, token.span)
        if token.text == "Map":
            self._expect(TokenKind.LBRACKET, "TYPE_ARGUMENT")
            self._expect_word("Text", "MAP_KEY_TYPE")
            self._expect(TokenKind.COMMA, "TYPE_ARGUMENT")
            value_type = self._type()
            self._expect(TokenKind.RBRACKET, "TYPE_ARGUMENT")
            return MapType(value_type, token.span)
        if token.text == "Result":
            self._expect(TokenKind.LBRACKET, "TYPE_ARGUMENT")
            value_type = self._type()
            self._expect(TokenKind.RBRACKET, "TYPE_ARGUMENT")
            return ResultType(value_type, token.span)
        if token.text in RESERVED_WORDS:
            raise BangelDiagnostic("TYPE_EXPECTED", "Expected a Bangel 1.0 type.", token.span)
        parts = [token.text]
        while self._match(TokenKind.DOT):
            parts.append(self._identifier("TYPE_NAME"))
        return NamedType(tuple(parts), token.span)

    def _unit_expression(self) -> UnitExpression:
        first_span = self._peek().span
        terms = [self._unit_term()]
        operators: list[str] = []
        while (
            self._peek().kind is TokenKind.OPERATOR
            and self._peek().text in {"*", "/"}
            and not self._peek().leading_space
        ):
            operator = self._take()
            if self._peek().leading_space:
                raise BangelDiagnostic(
                    "UNIT_EXPRESSION_SPACE",
                    "Compound unit operators and terms are adjacent in Bangel 1.0.",
                    self._peek().span,
                )
            operators.append(operator.text)
            terms.append(self._unit_term())
        return UnitExpression(tuple(terms), tuple(operators), first_span)

    def _unit_term(self) -> UnitTerm:
        token = self._take()
        if token.kind is TokenKind.NUMBER and token.text == "1":
            symbol = "1"
        elif token.kind is TokenKind.IDENT and token.text not in RESERVED_WORDS:
            symbol = token.text
        else:
            raise BangelDiagnostic(
                "UNIT_EXPECTED", "Expected a Bangel unit symbol.", token.span
            )
        exponent = 1
        if (
            self._peek().kind is TokenKind.OPERATOR
            and self._peek().text == "^"
            and not self._peek().leading_space
        ):
            self._take()
            sign = 1
            if self._peek().kind is TokenKind.OPERATOR and self._peek().text == "-":
                self._take()
                sign = -1
            exponent = sign * self._positive_integer()
        return UnitTerm(symbol, exponent, token.span)

    def _expression(self):
        return self._or_expression()

    def _or_expression(self):
        left = self._and_expression()
        while self._at_word("or"):
            operator = self._take()
            right = self._and_expression()
            left = BinaryExpression(operator.text, left, right, operator.span)
        return left

    def _and_expression(self):
        left = self._equality_expression()
        while self._at_word("and"):
            operator = self._take()
            right = self._equality_expression()
            left = BinaryExpression(operator.text, left, right, operator.span)
        return left

    def _equality_expression(self):
        left = self._comparison_expression()
        if self._at_operator({"==", "!="}):
            operator = self._take()
            right = self._comparison_expression()
            left = BinaryExpression(operator.text, left, right, operator.span)
            if self._at_operator({"==", "!="}):
                raise self._error(
                    "EQUALITY_CHAINED", "Equality operators cannot be chained in Bangel 1.0."
                )
        return left

    def _comparison_expression(self):
        left = self._additive_expression()
        if self._at_operator({"<", "<=", ">", ">="}):
            operator = self._take()
            right = self._additive_expression()
            left = BinaryExpression(operator.text, left, right, operator.span)
            if self._at_operator({"<", "<=", ">", ">="}):
                raise self._error(
                    "COMPARISON_CHAINED",
                    "Comparison operators cannot be chained in Bangel 1.0.",
                )
        return left

    def _additive_expression(self):
        left = self._multiplicative_expression()
        while self._at_operator({"+", "-"}):
            operator = self._take()
            right = self._multiplicative_expression()
            left = BinaryExpression(operator.text, left, right, operator.span)
        return left

    def _multiplicative_expression(self):
        left = self._unary_expression()
        while self._at_operator({"*", "/"}):
            operator = self._take()
            right = self._unary_expression()
            left = BinaryExpression(operator.text, left, right, operator.span)
        return left

    def _unary_expression(self):
        if self._at_operator({"+", "-"}) or self._at_word("not"):
            operator = self._take()
            return UnaryExpression(operator.text, self._postfix_expression(), operator.span)
        return self._postfix_expression()

    def _postfix_expression(self):
        expression = self._primary_expression()
        while True:
            token = self._peek()
            if token.leading_space:
                return expression
            if token.kind is TokenKind.LPAREN:
                arguments = self._arguments()
                expression = CallExpression(expression, arguments, token.span)
            elif token.kind is TokenKind.LBRACKET:
                self._take()
                index = self._expression()
                self._expect(TokenKind.RBRACKET, "INDEX_CLOSE")
                expression = IndexExpression(expression, index, token.span)
            elif token.kind is TokenKind.DOT:
                self._take()
                field = self._identifier("FIELD_ACCESS")
                expression = FieldExpression(expression, field, token.span)
            else:
                return expression

    def _primary_expression(self):
        token = self._peek()
        if token.kind is TokenKind.NUMBER:
            self._take()
            numeric = self._numeric_literal(token)
            next_token = self._peek()
            is_unit_start = (
                next_token.leading_space
                and (
                    (next_token.kind is TokenKind.NUMBER and next_token.text == "1")
                    or (
                        next_token.kind is TokenKind.IDENT
                        and next_token.text not in RESERVED_WORDS
                    )
                )
            )
            if is_unit_start:
                unit = self._unit_expression()
                return QuantityLiteral(numeric, unit, token.span)
            return numeric
        if token.kind is TokenKind.STRING:
            self._take()
            return TextLiteral(json.loads(token.text), token.text, token.span)
        if self._at_word("true") or self._at_word("false"):
            self._take()
            return BooleanLiteral(token.text == "true", token.span)
        if self._at_word("unknown"):
            self._take()
            self._expect(TokenKind.LBRACKET, "UNKNOWN_TYPE")
            value_type = self._type()
            self._expect(TokenKind.RBRACKET, "UNKNOWN_TYPE")
            self._expect(TokenKind.LPAREN, "UNKNOWN_REASON")
            reason: TextLiteral | None = None
            if not self._at(TokenKind.RPAREN):
                reason = self._text_literal("UNKNOWN_REASON")
            self._expect(TokenKind.RPAREN, "UNKNOWN_REASON")
            return UnknownExpression(value_type, reason, token.span)
        if self._at_word("mass_delta"):
            self._take()
            self._expect(TokenKind.LBRACKET, "MASS_DELTA_UNIT")
            unit = self._unit_expression()
            self._expect(TokenKind.RBRACKET, "MASS_DELTA_UNIT")
            self._expect(TokenKind.LPAREN, "MASS_DELTA_VALUE")
            magnitude = self._expression()
            self._expect(TokenKind.RPAREN, "MASS_DELTA_VALUE")
            return MassDeltaExpression(unit, magnitude, token.span)
        if self._at_word("Result"):
            self._take()
            self._expect(TokenKind.DOT, "RESULT_CONSTRUCTOR")
            variant = self._peek()
            if variant.kind is not TokenKind.IDENT or variant.text not in {"Ok", "Err"}:
                raise self._error(
                    "RESULT_CONSTRUCTOR", "Result constructor must be Result.Ok or Result.Err."
                )
            self._take()
            arguments = self._arguments()
            return ResultConstructor(variant.text, arguments, token.span)
        if self._at_word("Failure"):
            self._take()
            return FailureConstructor(self._arguments(), token.span)
        if token.kind is TokenKind.IDENT:
            if token.text in RESERVED_WORDS:
                raise BangelDiagnostic(
                    "EXPRESSION_PRIMARY",
                    f"Reserved word {token.text!r} cannot begin this expression.",
                    token.span,
                )
            self._take()
            return NameExpression(token.text, token.span)
        if self._match(TokenKind.LPAREN):
            expression = self._expression()
            self._expect(TokenKind.RPAREN, "GROUP_CLOSE")
            return expression
        if self._match(TokenKind.LBRACKET):
            items = []
            if not self._at(TokenKind.RBRACKET):
                items.append(self._expression())
                while self._match(TokenKind.COMMA):
                    items.append(self._expression())
            self._expect(TokenKind.RBRACKET, "VECTOR_CLOSE")
            return VectorLiteral(tuple(items), token.span)
        if self._match(TokenKind.LBRACE):
            entries = []
            if not self._at(TokenKind.RBRACE):
                entries.append(self._map_entry())
                while self._match(TokenKind.COMMA):
                    entries.append(self._map_entry())
            self._expect(TokenKind.RBRACE, "MAP_CLOSE")
            return MapLiteral(tuple(entries), token.span)
        raise self._error("EXPRESSION_PRIMARY", "Expected a Bangel 1.0 expression.")

    def _arguments(self) -> tuple[Argument, ...]:
        self._expect(TokenKind.LPAREN, "CALL_OPEN")
        arguments: list[Argument] = []
        if not self._at(TokenKind.RPAREN):
            arguments.append(self._argument())
            while self._match(TokenKind.COMMA):
                arguments.append(self._argument())
        self._expect(TokenKind.RPAREN, "CALL_CLOSE")
        return tuple(arguments)

    def _argument(self) -> Argument:
        span = self._peek().span
        name: str | None = None
        if (
            self._peek().kind is TokenKind.IDENT
            and self._peek().text not in RESERVED_WORDS
            and self._peek(1).kind is TokenKind.EQUAL
        ):
            name = self._take().text
            self._take()
        return Argument(name, self._expression(), span)

    def _map_entry(self) -> MapEntry:
        span = self._peek().span
        key = self._text_literal("MAP_KEY")
        self._expect(TokenKind.COLON, "MAP_ENTRY")
        return MapEntry(key, self._expression(), span)

    def _text_literal(self, code: str) -> TextLiteral:
        token = self._expect(TokenKind.STRING, code)
        return TextLiteral(json.loads(token.text), token.text, token.span)

    @staticmethod
    def _numeric_literal(token: Token) -> IntegerLiteral | RealLiteral:
        if "." not in token.text and "e" not in token.text.lower():
            return IntegerLiteral(int(token.text), token.text, token.span)
        try:
            value = Decimal(token.text)
        except InvalidOperation as exc:
            raise BangelDiagnostic("NUMBER_INVALID", "Invalid Real literal.", token.span) from exc
        return RealLiteral(format(value, "f"), token.text, token.span)

    def _positive_integer(self, *, maximum: int | None = None) -> int:
        token = self._take()
        if (
            token.kind is not TokenKind.NUMBER
            or not token.text.isdigit()
            or token.text.startswith("0")
        ):
            raise BangelDiagnostic(
                "POSITIVE_INTEGER", "Expected a positive decimal integer literal.", token.span
            )
        value = int(token.text)
        if maximum is not None and value > maximum:
            raise BangelDiagnostic(
                "POSITIVE_INTEGER_LIMIT",
                f"Literal exceeds the Bangel 1.0 limit of {maximum}.",
                token.span,
            )
        return value

    def _qualified_name(self, code: str) -> tuple[str, ...]:
        parts = [self._identifier(code)]
        while self._match(TokenKind.DOT):
            parts.append(self._identifier(code))
        return tuple(parts)

    def _identifier(self, code: str) -> str:
        token = self._take()
        if token.kind is not TokenKind.IDENT or token.text in RESERVED_WORDS:
            raise BangelDiagnostic(code, "Expected a non-reserved ASCII identifier.", token.span)
        return token.text

    def _line_end(self, code: str) -> None:
        if self._at(TokenKind.SEMICOLON):
            raise self._error(
                "SEMICOLON_NOT_STATEMENT",
                "Semicolon is not a Bangel 1.0 statement separator.",
            )
        self._expect(TokenKind.NEWLINE, code)

    def _at_operator(self, values: set[str]) -> bool:
        token = self._peek()
        return token.kind is TokenKind.OPERATOR and token.text in values

    def _at_word(self, word: str) -> bool:
        token = self._peek()
        return token.kind is TokenKind.IDENT and token.text == word

    def _at(self, kind: TokenKind) -> bool:
        return self._peek().kind is kind

    def _match(self, kind: TokenKind) -> Token | None:
        if self._at(kind):
            return self._take()
        return None

    def _expect_word(self, word: str, code: str) -> Token:
        if not self._at_word(word):
            raise self._error(code, f"Expected {word!r}.")
        return self._take()

    def _expect(self, kind: TokenKind, code: str) -> Token:
        token = self._take()
        if token.kind is not kind:
            raise BangelDiagnostic(code, f"Expected {kind.value}.", token.span)
        return token

    def _peek(self, offset: int = 0) -> Token:
        return self.tokens[min(self.index + offset, len(self.tokens) - 1)]

    def _take(self) -> Token:
        token = self._peek()
        if self.index < len(self.tokens) - 1:
            self.index += 1
        return token

    def _error(self, code: str, message: str) -> BangelDiagnostic:
        return BangelDiagnostic(code, message, self._peek().span)


def parse_source(source: str, *, source_name: str | None = None) -> ProgramSource | ModuleSource:
    if isinstance(source, str):
        normalized = source.replace("\r\n", "\n").replace("\r", "\n")
        for line_number, physical_line in enumerate(normalized.split("\n"), 1):
            meaningful = physical_line.split("#", 1)[0].strip(" ")
            if not meaningful:
                continue
            if meaningful in {"bangel 1.1", "bangel 0.1", "bangel physics 0.1"}:
                raise BangelDiagnostic(
                    "PROFILE_REQUIRES_COMPAT",
                    "Historical Bangel syntax requires an explicit compatibility profile.",
                    SourceSpan(line_number),
                )
            break
    parser = Parser(lex(source), source_name)
    try:
        return parser.parse()
    except RecursionError as exc:
        raise BangelDiagnostic(
            "SYNTAX_INVALID",
            "Source nesting exceeds Elsa's safe parser depth.",
            parser._peek().span,
        ) from exc
