from __future__ import annotations

from dataclasses import fields, is_dataclass
from dataclasses import dataclass
from typing import Any, TypeAlias

from ..diagnostics import SourceSpan


def _encode(value: Any) -> Any:
    if isinstance(value, ASTNode):
        return value.to_dict()
    if isinstance(value, SourceSpan):
        return value.to_dict()
    if isinstance(value, tuple):
        return [_encode(item) for item in value]
    if isinstance(value, list):
        return [_encode(item) for item in value]
    if isinstance(value, dict):
        return {key: _encode(item) for key, item in value.items()}
    return value


class ASTNode:
    """Base for immutable, source-spanned Bangel 1.0 syntax nodes."""

    def to_dict(self) -> dict[str, Any]:
        if not is_dataclass(self):
            raise TypeError("AST nodes must be dataclasses")
        return {
            "kind": type(self).__name__,
            **{field.name: _encode(getattr(self, field.name)) for field in fields(self)},
        }


@dataclass(frozen=True, slots=True)
class UnitTerm(ASTNode):
    symbol: str
    exponent: int
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class UnitExpression(ASTNode):
    terms: tuple[UnitTerm, ...]
    operators: tuple[str, ...]
    span: SourceSpan

    def text(self) -> str:
        rendered: list[str] = []
        for index, term in enumerate(self.terms):
            if index:
                rendered.append(self.operators[index - 1])
            rendered.append(term.symbol)
            if term.exponent != 1:
                rendered.extend(("^", str(term.exponent)))
        return "".join(rendered)


class TypeSyntax(ASTNode):
    pass


@dataclass(frozen=True, slots=True)
class ScalarType(TypeSyntax):
    name: str
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class NamedType(TypeSyntax):
    name: tuple[str, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class QuantityType(TypeSyntax):
    unit: UnitExpression
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class MassDeltaType(TypeSyntax):
    unit: UnitExpression
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class MeasurementType(TypeSyntax):
    value_type: QuantityType | MassDeltaType
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class UnknownType(TypeSyntax):
    value_type: TypeSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class VectorType(TypeSyntax):
    item_type: TypeSyntax
    size: int | None
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class MapType(TypeSyntax):
    value_type: TypeSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class ResultType(TypeSyntax):
    value_type: TypeSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class FailureType(TypeSyntax):
    span: SourceSpan


TypeNode: TypeAlias = (
    ScalarType
    | NamedType
    | QuantityType
    | MassDeltaType
    | MeasurementType
    | UnknownType
    | VectorType
    | MapType
    | ResultType
    | FailureType
)


class ExpressionSyntax(ASTNode):
    pass


@dataclass(frozen=True, slots=True)
class BooleanLiteral(ExpressionSyntax):
    value: bool
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class TextLiteral(ExpressionSyntax):
    value: str
    source_text: str
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class IntegerLiteral(ExpressionSyntax):
    value: int
    source_text: str
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class RealLiteral(ExpressionSyntax):
    value: str
    source_text: str
    span: SourceSpan


NumericLiteral: TypeAlias = IntegerLiteral | RealLiteral


@dataclass(frozen=True, slots=True)
class QuantityLiteral(ExpressionSyntax):
    magnitude: NumericLiteral
    unit: UnitExpression
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class NameExpression(ExpressionSyntax):
    name: str
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class VectorLiteral(ExpressionSyntax):
    items: tuple[ExpressionSyntax, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class MapEntry(ASTNode):
    key: TextLiteral
    value: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class MapLiteral(ExpressionSyntax):
    entries: tuple[MapEntry, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class UnknownExpression(ExpressionSyntax):
    value_type: TypeSyntax
    reason: TextLiteral | None
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class MassDeltaExpression(ExpressionSyntax):
    unit: UnitExpression
    magnitude: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class UnaryExpression(ExpressionSyntax):
    operator: str
    operand: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class BinaryExpression(ExpressionSyntax):
    operator: str
    left: ExpressionSyntax
    right: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class Argument(ASTNode):
    name: str | None
    value: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class CallExpression(ExpressionSyntax):
    callee: ExpressionSyntax
    arguments: tuple[Argument, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class IndexExpression(ExpressionSyntax):
    target: ExpressionSyntax
    index: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class FieldExpression(ExpressionSyntax):
    target: ExpressionSyntax
    field: str
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class ResultConstructor(ExpressionSyntax):
    variant: str
    arguments: tuple[Argument, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class FailureConstructor(ExpressionSyntax):
    arguments: tuple[Argument, ...]
    span: SourceSpan


ExpressionNode: TypeAlias = ExpressionSyntax


@dataclass(frozen=True, slots=True)
class ImportDeclaration(ASTNode):
    module: tuple[str, ...]
    alias: str | None
    selection: tuple[str, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class FieldDeclaration(ASTNode):
    name: str
    value_type: TypeSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class VariantDeclaration(ASTNode):
    name: str
    fields: tuple[FieldDeclaration, ...]
    span: SourceSpan


class StatementSyntax(ASTNode):
    pass


@dataclass(frozen=True, slots=True)
class LetStatement(StatementSyntax):
    name: str
    annotation: TypeSyntax | None
    expression: ExpressionSyntax
    exported: bool
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class DeriveStatement(StatementSyntax):
    name: str
    annotation: TypeSyntax | None
    expression: ExpressionSyntax
    exported: bool
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class VarStatement(StatementSyntax):
    name: str
    annotation: TypeSyntax
    expression: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class SetStatement(StatementSyntax):
    name: str
    expression: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class MeasureStatement(StatementSyntax):
    name: str
    annotation: MeasurementType
    nominal: ExpressionSyntax
    uncertainty: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class EvidenceStatement(StatementSyntax):
    evidence_class: str
    name: str
    annotation: TypeSyntax | None
    expression: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class RequireStatement(StatementSyntax):
    condition: ExpressionSyntax
    diagnostic_code: str
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class EmitStatement(StatementSyntax):
    name: str
    expression: ExpressionSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class IfStatement(StatementSyntax):
    condition: ExpressionSyntax
    then_body: tuple[StatementSyntax, ...]
    else_body: tuple[StatementSyntax, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class ForStatement(StatementSyntax):
    name: str
    iterable: ExpressionSyntax
    limit: int
    body: tuple[StatementSyntax, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class CaseArm(ASTNode):
    tag: tuple[str, ...]
    bindings: tuple[str, ...]
    body: tuple[StatementSyntax, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class MatchStatement(StatementSyntax):
    expression: ExpressionSyntax
    cases: tuple[CaseArm, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class RecordDeclaration(ASTNode):
    name: str
    fields: tuple[FieldDeclaration, ...]
    exported: bool
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class EnumDeclaration(ASTNode):
    name: str
    variants: tuple[VariantDeclaration, ...]
    exported: bool
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class Parameter(ASTNode):
    name: str
    value_type: TypeSyntax
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class FunctionDeclaration(ASTNode):
    name: str
    parameters: tuple[Parameter, ...]
    return_type: TypeSyntax
    captures: tuple[str, ...]
    body: tuple[StatementSyntax, ...]
    return_expression: ExpressionSyntax
    exported: bool
    span: SourceSpan


TopLevelItem: TypeAlias = (
    StatementSyntax | RecordDeclaration | EnumDeclaration | FunctionDeclaration
)


class SourceFile(ASTNode):
    language_identity: str
    source_name: str | None
    name: str | tuple[str, ...]
    effects: tuple[str, ...]
    imports: tuple[ImportDeclaration, ...]
    items: tuple[TopLevelItem, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class ProgramSource(SourceFile):
    language_identity: str
    source_name: str | None
    name: str
    effects: tuple[str, ...]
    imports: tuple[ImportDeclaration, ...]
    items: tuple[TopLevelItem, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class ModuleSource(SourceFile):
    language_identity: str
    source_name: str | None
    name: tuple[str, ...]
    effects: tuple[str, ...]
    imports: tuple[ImportDeclaration, ...]
    items: tuple[TopLevelItem, ...]
    span: SourceSpan
