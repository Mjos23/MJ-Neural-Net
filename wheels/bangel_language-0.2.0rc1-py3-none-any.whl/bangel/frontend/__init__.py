"""Frozen Bangel/1.0 lexer, parser, and typed syntax tree."""

from .ast import ModuleSource, ProgramSource, SourceFile
from .lexer import lex
from .parser import LANGUAGE_IDENTITY, SOURCE_HEADER, parse_source
from .semantics import (
    ModuleInterface,
    ProjectSemanticModel,
    Scope,
    SemanticModel,
    SemanticType,
    Symbol,
    analyze_project,
    analyze_source,
)
from .tokens import Token, TokenKind

__all__ = [
    "LANGUAGE_IDENTITY",
    "SOURCE_HEADER",
    "ModuleInterface",
    "ModuleSource",
    "ProjectSemanticModel",
    "ProgramSource",
    "Scope",
    "SemanticModel",
    "SemanticType",
    "SourceFile",
    "Symbol",
    "Token",
    "TokenKind",
    "analyze_project",
    "analyze_source",
    "lex",
    "parse_source",
]
