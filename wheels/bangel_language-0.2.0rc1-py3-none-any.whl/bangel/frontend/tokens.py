from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from ..diagnostics import SourceSpan


class TokenKind(StrEnum):
    IDENT = "IDENT"
    NUMBER = "NUMBER"
    STRING = "STRING"
    NEWLINE = "NEWLINE"
    LPAREN = "LPAREN"
    RPAREN = "RPAREN"
    LBRACKET = "LBRACKET"
    RBRACKET = "RBRACKET"
    LBRACE = "LBRACE"
    RBRACE = "RBRACE"
    COMMA = "COMMA"
    COLON = "COLON"
    DOT = "DOT"
    SEMICOLON = "SEMICOLON"
    EQUAL = "EQUAL"
    ARROW = "ARROW"
    PLUS_MINUS = "PLUS_MINUS"
    OPERATOR = "OPERATOR"
    EOF = "EOF"


@dataclass(frozen=True, slots=True)
class Token:
    kind: TokenKind
    text: str
    span: SourceSpan
    leading_space: bool = False

    def to_dict(self) -> dict[str, object]:
        return {
            "kind": self.kind.value,
            "text": self.text,
            "span": self.span.to_dict(),
            "leading_space": self.leading_space,
        }
