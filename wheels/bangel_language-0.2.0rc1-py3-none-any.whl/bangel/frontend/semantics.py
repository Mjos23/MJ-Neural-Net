from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Context, Decimal, DecimalException, ROUND_HALF_EVEN, localcontext
from typing import Iterable, Mapping

from ..diagnostics import BangelDiagnostic, SourceSpan
from ..units import DIMENSIONLESS, MASS, Dimension, UNITS, combine_dimensions
from .ast import (
    Argument,
    BinaryExpression,
    BooleanLiteral,
    CallExpression,
    CaseArm,
    DeriveStatement,
    EmitStatement,
    EnumDeclaration,
    EvidenceStatement,
    ExpressionSyntax,
    FailureConstructor,
    FailureType,
    FieldExpression,
    ForStatement,
    FunctionDeclaration,
    IfStatement,
    ImportDeclaration,
    IndexExpression,
    IntegerLiteral,
    LetStatement,
    MapLiteral,
    MapType,
    MassDeltaExpression,
    MassDeltaType,
    MatchStatement,
    MeasurementType,
    MeasureStatement,
    ModuleSource,
    NameExpression,
    NamedType,
    ProgramSource,
    QuantityLiteral,
    QuantityType,
    RealLiteral,
    RecordDeclaration,
    RequireStatement,
    ResultConstructor,
    ResultType,
    ScalarType,
    SetStatement,
    SourceFile,
    StatementSyntax,
    TextLiteral,
    TypeSyntax,
    UnaryExpression,
    UnknownExpression,
    UnknownType,
    VarStatement,
    VectorLiteral,
    VectorType,
)


INT64_MIN = -(2**63)
INT64_MAX = 2**63 - 1
MAX_CALL_DEPTH = 64
DECIMAL128 = Context(
    prec=34,
    Emin=-6143,
    Emax=6144,
    rounding=ROUND_HALF_EVEN,
)

SCALAR_KINDS = frozenset({"Bool", "Text", "Int", "Real"})
NUMERIC_KINDS = frozenset({"Int", "Real"})
PHYSICAL_KINDS = frozenset({"Quantity", "MassDelta"})
UNKNOWN_BASE_KINDS = frozenset(
    {"Bool", "Int", "Real", "Quantity", "MassDelta", "Measurement"}
)
CORE_INTRINSICS = frozenset({"is_known", "nominal", "uncertainty", "convert"})


def _diag(
    code: str,
    message: str,
    span: SourceSpan | None,
    **details: object,
) -> BangelDiagnostic:
    return BangelDiagnostic(code, message, span, details)


@dataclass(frozen=True, slots=True)
class ResolvedUnit:
    text: str
    dimension: Dimension
    scale: Decimal

    def to_dict(self) -> dict[str, object]:
        return {
            "text": self.text,
            "dimension": list(self.dimension),
            "scale": _decimal_text(self.scale),
        }


@dataclass(frozen=True, slots=True)
class SemanticType:
    kind: str
    arguments: tuple["SemanticType", ...] = ()
    unit: ResolvedUnit | None = None
    size: int | None = None
    name: tuple[str, ...] = ()

    def render(self) -> str:
        if self.kind in SCALAR_KINDS or self.kind == "Failure":
            return self.kind
        if self.kind in PHYSICAL_KINDS:
            assert self.unit is not None
            return f"{self.kind}[{self.unit.text}]"
        if self.kind in {"Measurement", "Unknown", "Result"}:
            return f"{self.kind}[{self.arguments[0].render()}]"
        if self.kind == "Vector":
            suffix = "" if self.size is None else f"; {self.size}"
            return f"Vector[{self.arguments[0].render()}{suffix}]"
        if self.kind == "Map":
            return f"Map[Text, {self.arguments[0].render()}]"
        if self.kind in {"Record", "Enum"}:
            return self.name[-1]
        return self.kind

    def to_dict(self) -> dict[str, object]:
        value: dict[str, object] = {"kind": self.kind, "display": self.render()}
        if self.arguments:
            value["arguments"] = [item.to_dict() for item in self.arguments]
        if self.unit is not None:
            value["unit"] = self.unit.to_dict()
        if self.size is not None:
            value["size"] = self.size
        if self.name:
            value["identity"] = ".".join(self.name)
        return value


BOOL = SemanticType("Bool")
TEXT = SemanticType("Text")
INT = SemanticType("Int")
REAL = SemanticType("Real")
FAILURE = SemanticType("Failure")


@dataclass(frozen=True, slots=True)
class Symbol:
    name: str
    kind: str
    value_type: SemanticType | None
    mutable: bool
    exported: bool
    span: SourceSpan
    target: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "kind": self.kind,
            "type": None if self.value_type is None else self.value_type.to_dict(),
            "mutable": self.mutable,
            "exported": self.exported,
            "span": self.span.to_dict(),
            "target": self.target,
        }


@dataclass(frozen=True, slots=True)
class Scope:
    """Persistent lexical scope. Adding a symbol returns a new scope value."""

    parent: "Scope | None" = None
    symbols: tuple[Symbol, ...] = ()

    def lookup_local(self, name: str) -> Symbol | None:
        for symbol in reversed(self.symbols):
            if symbol.name == name:
                return symbol
        return None

    def lookup(self, name: str) -> Symbol | None:
        local = self.lookup_local(name)
        if local is not None:
            return local
        return None if self.parent is None else self.parent.lookup(name)

    def add(self, symbol: Symbol) -> "Scope":
        return Scope(self.parent, (*self.symbols, symbol))

    def child(self) -> "Scope":
        return Scope(self)

    def refine(self, name: str, value_type: SemanticType) -> "Scope":
        original = self.lookup(name)
        if original is None:
            return self
        refined = replace(original, value_type=value_type, kind="refinement")
        return Scope(self, (refined,))


@dataclass(frozen=True, slots=True)
class FieldSpec:
    name: str
    value_type: SemanticType
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class RecordSpec:
    key: str
    value_type: SemanticType
    fields: tuple[FieldSpec, ...]
    exported: bool
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class VariantSpec:
    name: str
    fields: tuple[FieldSpec, ...]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class EnumSpec:
    key: str
    value_type: SemanticType
    variants: tuple[VariantSpec, ...]
    exported: bool
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class ParameterSpec:
    name: str
    value_type: SemanticType
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class FunctionSpec:
    key: str
    name: str
    parameters: tuple[ParameterSpec, ...]
    return_type: SemanticType
    captures: tuple[str, ...]
    exported: bool
    span: SourceSpan
    intrinsic: str | None = None
    call_depth: int = 1


@dataclass(frozen=True, slots=True)
class ConversionFact:
    span: SourceSpan
    source_unit: str
    target_unit: str
    context: str

    def to_dict(self) -> dict[str, object]:
        return {
            "span": self.span.to_dict(),
            "source_unit": self.source_unit,
            "target_unit": self.target_unit,
            "context": self.context,
        }


@dataclass(frozen=True, slots=True)
class ReferenceFact:
    span: SourceSpan
    source_name: str
    symbol_kind: str
    target: str

    def to_dict(self) -> dict[str, object]:
        return {
            "span": self.span.to_dict(),
            "source_name": self.source_name,
            "symbol_kind": self.symbol_kind,
            "target": self.target,
        }


@dataclass(frozen=True, slots=True)
class _QuantityConstant:
    magnitude_si: Decimal
    dimension: Dimension
    signed_delta: bool = False


_NO_CONSTANT = object()


@dataclass(frozen=True, slots=True)
class TypedExpression:
    expression: ExpressionSyntax
    value_type: SemanticType
    constant: object = _NO_CONSTANT

    def to_dict(self) -> dict[str, object]:
        value: dict[str, object] = {
            "syntax": type(self.expression).__name__,
            "span": self.expression.span.to_dict(),
            "type": self.value_type.to_dict(),
        }
        if self.constant is not _NO_CONSTANT:
            value["constant"] = _constant_to_dict(self.constant)
        return value


@dataclass(frozen=True, slots=True)
class ModuleInterface:
    name: tuple[str, ...]
    exports: tuple[Symbol, ...]
    records: tuple[RecordSpec, ...] = ()
    enums: tuple[EnumSpec, ...] = ()
    functions: tuple[FunctionSpec, ...] = ()

    def export(self, name: str) -> Symbol | None:
        for symbol in self.exports:
            if symbol.name == name:
                return symbol
        return None


@dataclass(frozen=True, slots=True)
class SemanticModel:
    source: SourceFile
    symbols: tuple[Symbol, ...]
    expressions: tuple[TypedExpression, ...]
    references: tuple[ReferenceFact, ...]
    conversions: tuple[ConversionFact, ...]
    inferred_effects: tuple[str, ...]
    maximum_call_depth: int
    interface: ModuleInterface | None = None
    records: tuple[RecordSpec, ...] = ()
    enums: tuple[EnumSpec, ...] = ()
    functions: tuple[FunctionSpec, ...] = ()
    call_depths: tuple[tuple[str, int], ...] = ()

    @property
    def language_identity(self) -> str:
        return self.source.language_identity

    @property
    def source_name(self) -> str | None:
        return self.source.source_name

    def to_dict(self) -> dict[str, object]:
        return {
            "language": self.language_identity,
            "source": self.source_name,
            "source_kind": type(self.source).__name__,
            "declared_effects": list(self.source.effects),
            "inferred_effects": list(self.inferred_effects),
            "maximum_call_depth": self.maximum_call_depth,
            "call_depths": {key: depth for key, depth in self.call_depths},
            "symbols": [symbol.to_dict() for symbol in self.symbols],
            "expressions": [item.to_dict() for item in self.expressions],
            "references": [item.to_dict() for item in self.references],
            "conversions": [item.to_dict() for item in self.conversions],
        }


@dataclass(frozen=True, slots=True)
class ProjectSemanticModel:
    modules: tuple[SemanticModel, ...]
    programs: tuple[SemanticModel, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "modules": [model.to_dict() for model in self.modules],
            "programs": [model.to_dict() for model in self.programs],
        }


def _decimal_text(value: Decimal) -> str:
    if value.is_zero():
        return "0"
    text = format(value.normalize(), "f")
    return text.rstrip("0").rstrip(".") if "." in text else text


def _constant_to_dict(value: object) -> object:
    if isinstance(value, Decimal):
        return _decimal_text(value)
    if isinstance(value, _QuantityConstant):
        return {
            "magnitude_si": _decimal_text(value.magnitude_si),
            "dimension": list(value.dimension),
            "signed_delta": value.signed_delta,
        }
    return value


def _semantic_key(owner: tuple[str, ...], name: str) -> str:
    return ".".join((*owner, name))


def _unit_from_syntax(unit) -> ResolvedUnit:
    dimension = DIMENSIONLESS
    scale = Decimal(1)
    for index, term in enumerate(unit.terms):
        registered = UNITS.get(term.symbol)
        if registered is None:
            raise _diag(
                "UNIT_UNKNOWN",
                f"Unknown Bangel-Units/1 symbol {term.symbol!r}.",
                term.span,
                unit=term.symbol,
            )
        direction = 1 if index == 0 or unit.operators[index - 1] == "*" else -1
        exponent = direction * term.exponent
        dimension = tuple(
            left + exponent * right
            for left, right in zip(dimension, registered.dimension, strict=True)
        )
        scale *= registered.scale**exponent
    return ResolvedUnit(unit.text(), dimension, scale)


def _canonical_unit(dimension: Dimension, scale: Decimal = Decimal(1)) -> ResolvedUnit:
    if dimension == DIMENSIONLESS:
        return ResolvedUnit("1", dimension, scale)
    names = ("kg", "m", "s", "A", "K")
    numerator: list[str] = []
    denominator: list[str] = []
    for name, exponent in zip(names, dimension, strict=True):
        if exponent > 0:
            numerator.append(name if exponent == 1 else f"{name}^{exponent}")
        elif exponent < 0:
            power = -exponent
            denominator.append(name if power == 1 else f"{name}^{power}")
    left = "*".join(numerator) or "1"
    text = left if not denominator else f"{left}/{'*'.join(denominator)}"
    return ResolvedUnit(text, dimension, scale)


def _combined_unit(
    left: ResolvedUnit,
    right: ResolvedUnit,
    *,
    divide: bool,
) -> ResolvedUnit:
    dimension = combine_dimensions(left.dimension, right.dimension, -1 if divide else 1)
    scale = left.scale / right.scale if divide else left.scale * right.scale
    if divide:
        if right.text == "1":
            text = left.text
        elif left.text == "1":
            text = f"1/{right.text}"
        else:
            text = f"{left.text}/{right.text}"
    elif left.text == "1":
        text = right.text
    elif right.text == "1":
        text = left.text
    else:
        text = f"{left.text}*{right.text}"
    return ResolvedUnit(text, dimension, scale)


def _unwrap_unknown(value_type: SemanticType) -> tuple[SemanticType, bool]:
    if value_type.kind == "Unknown":
        return value_type.arguments[0], True
    return value_type, False


def _unknown(value_type: SemanticType) -> SemanticType:
    return SemanticType("Unknown", (value_type,))


def _measurement(value_type: SemanticType) -> SemanticType:
    return SemanticType("Measurement", (value_type,))


def _result(value_type: SemanticType) -> SemanticType:
    return SemanticType("Result", (value_type,))


def _vector(value_type: SemanticType, size: int | None = None) -> SemanticType:
    return SemanticType("Vector", (value_type,), size=size)


def _map(value_type: SemanticType) -> SemanticType:
    return SemanticType("Map", (value_type,))


def _physical(kind: str, unit: ResolvedUnit) -> SemanticType:
    return SemanticType(kind, unit=unit)


def _path(expression: ExpressionSyntax) -> tuple[str, ...] | None:
    if isinstance(expression, NameExpression):
        return (expression.name,)
    if isinstance(expression, FieldExpression):
        prefix = _path(expression.target)
        if prefix is not None:
            return (*prefix, expression.field)
    return None


def _negative_numeric_literal(expression: ExpressionSyntax) -> bool:
    if not isinstance(expression, UnaryExpression) or expression.operator != "-":
        return False
    operand = expression.operand
    if isinstance(operand, IntegerLiteral):
        return operand.value > 0
    if isinstance(operand, RealLiteral):
        return Decimal(operand.value) > 0
    if isinstance(operand, QuantityLiteral):
        return Decimal(operand.magnitude.value) > 0
    return False


class Analyzer:
    def __init__(
        self,
        source: SourceFile,
        module_catalog: Mapping[tuple[str, ...], ModuleInterface] | None = None,
    ):
        self.source = source
        self.owner = (
            source.name
            if isinstance(source, ModuleSource)
            else ("program", str(source.name))
        )
        assert isinstance(self.owner, tuple)
        self.module_catalog = dict(module_catalog or {})
        self.scope = Scope()
        self.import_symbols: list[Symbol] = []
        self.type_symbols: list[Symbol] = []
        self.function_symbols: list[Symbol] = []
        self.records: dict[str, RecordSpec] = {}
        self.enums: dict[str, EnumSpec] = {}
        self.functions: dict[str, FunctionSpec] = {}
        self.interfaces: dict[str, ModuleInterface] = {}
        self.expressions: list[TypedExpression] = []
        self.references: list[ReferenceFact] = []
        self.conversions: list[ConversionFact] = []
        self.call_edges: dict[str, set[str]] = {}
        self.inferred_evidence = False

    def analyze(self) -> SemanticModel:
        self._install_core_intrinsics()
        self._install_imports()
        self._predeclare_types()
        self._resolve_structures()
        self._reject_recursive_types()
        self._predeclare_functions()

        scope = self.scope
        earlier_immutable: dict[str, Symbol] = {}
        executable_seen = False
        for item in self.source.items:
            is_prelude = isinstance(
                item,
                (
                    RecordDeclaration,
                    EnumDeclaration,
                    FunctionDeclaration,
                    LetStatement,
                    DeriveStatement,
                ),
            )
            if executable_seen and is_prelude:
                raise _diag(
                    "SYNTAX_INVALID",
                    "Top-level declarations must precede executable statements.",
                    item.span,
                    rule="declaration_prelude",
                )
            if not is_prelude:
                executable_seen = True

            if isinstance(item, (RecordDeclaration, EnumDeclaration)):
                continue
            if isinstance(item, FunctionDeclaration):
                self._analyze_function(item, earlier_immutable)
                continue
            scope = self._analyze_statement(item, scope, current_function=None)
            if isinstance(item, (LetStatement, DeriveStatement)):
                symbol = scope.lookup_local(item.name)
                assert symbol is not None
                earlier_immutable[item.name] = symbol

        self.scope = scope
        maximum_call_depth, call_depths = self._validate_call_graph()
        for key, call_depth in call_depths.items():
            self.functions[key] = replace(
                self.functions[key], call_depth=call_depth
            )
        inferred_effects = ("pure", "evidence") if self.inferred_evidence else ("pure",)
        if self.source.effects != inferred_effects:
            raise _diag(
                "EFFECT_MISMATCH",
                "Declared effects do not match Elsa's inferred effects.",
                self.source.span,
                declared=list(self.source.effects),
                inferred=list(inferred_effects),
            )

        public_symbols = tuple(
            symbol
            for symbol in scope.symbols
            if symbol.kind not in {"intrinsic", "namespace", "type", "function"}
        )
        declaration_symbols = tuple(
            sorted(
                (*self.type_symbols, *self.function_symbols, *public_symbols),
                key=lambda item: (item.span.line, item.span.column, item.name),
            )
        )
        interface = self._module_interface(scope) if isinstance(self.source, ModuleSource) else None
        return SemanticModel(
            self.source,
            declaration_symbols,
            tuple(self.expressions),
            tuple(self.references),
            tuple(self.conversions),
            inferred_effects,
            maximum_call_depth,
            interface,
            tuple(self.records[key] for key in sorted(self.records)),
            tuple(self.enums[key] for key in sorted(self.enums)),
            tuple(self.functions[key] for key in sorted(self.functions) if self.functions[key].intrinsic is None),
            tuple(sorted(call_depths.items())),
        )

    def _install_core_intrinsics(self) -> None:
        for name in sorted(CORE_INTRINSICS):
            symbol = Symbol(
                name,
                "intrinsic",
                None,
                False,
                False,
                SourceSpan(0, 0, 0),
                f"core.{name}",
            )
            self.scope = self.scope.add(symbol)

    def _install_imports(self) -> None:
        for declaration in self.source.imports:
            module_name = declaration.module
            interface = _standard_interface(module_name) or self.module_catalog.get(module_name)
            if interface is None:
                raise _diag(
                    "NAME_UNRESOLVED",
                    f"Imported module {'.'.join(module_name)!r} is not resolved.",
                    declaration.span,
                    name=".".join(module_name),
                    context="module",
                )
            module_key = ".".join(module_name)
            self.interfaces[module_key] = interface
            for record in interface.records:
                self.records[record.key] = record
            for enum in interface.enums:
                self.enums[enum.key] = enum
            for function in interface.functions:
                self.functions[function.key] = function

            if declaration.selection:
                for selected in declaration.selection:
                    exported = interface.export(selected)
                    if exported is None:
                        raise _diag(
                            "NAME_UNRESOLVED",
                            f"Module {module_key!r} does not export {selected!r}.",
                            declaration.span,
                            name=selected,
                            context="import_selection",
                            module=module_key,
                        )
                    imported = replace(
                        exported,
                        span=declaration.span,
                        exported=False,
                    )
                    self.scope = self._define(self.scope, imported)
                    self.import_symbols.append(imported)
            else:
                binding = declaration.alias or declaration.module[-1]
                namespace = Symbol(
                    binding,
                    "namespace",
                    None,
                    False,
                    False,
                    declaration.span,
                    module_key,
                )
                self.scope = self._define(self.scope, namespace)
                self.import_symbols.append(namespace)

    def _predeclare_types(self) -> None:
        for item in self.source.items:
            if not isinstance(item, (RecordDeclaration, EnumDeclaration)):
                continue
            key = _semantic_key(self.owner, item.name)
            kind = "Record" if isinstance(item, RecordDeclaration) else "Enum"
            value_type = SemanticType(kind, name=(*self.owner, item.name))
            symbol = Symbol(
                item.name,
                "type",
                value_type,
                False,
                item.exported,
                item.span,
                key,
            )
            self.scope = self._define(self.scope, symbol)
            self.type_symbols.append(symbol)

    def _resolve_structures(self) -> None:
        for item in self.source.items:
            if isinstance(item, RecordDeclaration):
                symbol = self.scope.lookup_local(item.name)
                assert symbol is not None and symbol.value_type is not None and symbol.target
                fields = self._resolve_fields(item.fields, owner=item.name)
                self.records[symbol.target] = RecordSpec(
                    symbol.target,
                    symbol.value_type,
                    fields,
                    item.exported,
                    item.span,
                )
            elif isinstance(item, EnumDeclaration):
                symbol = self.scope.lookup_local(item.name)
                assert symbol is not None and symbol.value_type is not None and symbol.target
                seen: dict[str, SourceSpan] = {}
                variants: list[VariantSpec] = []
                for variant in item.variants:
                    if variant.name in seen:
                        raise self._duplicate(variant.name, variant.span, seen[variant.name])
                    seen[variant.name] = variant.span
                    variants.append(
                        VariantSpec(
                            variant.name,
                            self._resolve_fields(
                                variant.fields,
                                owner=f"{item.name}.{variant.name}",
                            ),
                            variant.span,
                        )
                    )
                self.enums[symbol.target] = EnumSpec(
                    symbol.target,
                    symbol.value_type,
                    tuple(variants),
                    item.exported,
                    item.span,
                )

    def _resolve_fields(self, fields, *, owner: str) -> tuple[FieldSpec, ...]:
        seen: dict[str, SourceSpan] = {}
        result: list[FieldSpec] = []
        for field in fields:
            if field.name in seen:
                raise self._duplicate(field.name, field.span, seen[field.name])
            seen[field.name] = field.span
            result.append(FieldSpec(field.name, self._resolve_type(field.value_type), field.span))
        return tuple(result)

    def _reject_recursive_types(self) -> None:
        local_keys = {
            symbol.target
            for symbol in self.type_symbols
            if symbol.target is not None
        }
        graph: dict[str, set[str]] = {key: set() for key in local_keys}
        spans: dict[str, SourceSpan] = {}
        for key in local_keys:
            if key in self.records:
                spec = self.records[key]
                spans[key] = spec.span
                types = (field.value_type for field in spec.fields)
            else:
                spec = self.enums[key]
                spans[key] = spec.span
                types = (
                    field.value_type
                    for variant in spec.variants
                    for field in variant.fields
                )
            for value_type in types:
                graph[key].update(_type_dependencies(value_type) & local_keys)

        visiting: list[str] = []
        visited: set[str] = set()

        def visit(key: str) -> None:
            if key in visiting:
                start = visiting.index(key)
                cycle = (*visiting[start:], key)
                raise _diag(
                    "TYPE_RECURSION_UNSUPPORTED",
                    "Recursive record and enum types are outside Bangel 1.0.",
                    spans[key],
                    cycle=list(cycle),
                )
            if key in visited:
                return
            visiting.append(key)
            for dependency in sorted(graph[key]):
                visit(dependency)
            visiting.pop()
            visited.add(key)

        for key in sorted(graph):
            visit(key)

    def _predeclare_functions(self) -> None:
        for item in self.source.items:
            if not isinstance(item, FunctionDeclaration):
                continue
            key = _semantic_key(self.owner, item.name)
            parameters: list[ParameterSpec] = []
            seen: dict[str, SourceSpan] = {}
            for parameter in item.parameters:
                if parameter.name in seen:
                    raise self._duplicate(parameter.name, parameter.span, seen[parameter.name])
                seen[parameter.name] = parameter.span
                parameters.append(
                    ParameterSpec(
                        parameter.name,
                        self._resolve_type(parameter.value_type),
                        parameter.span,
                    )
                )
            spec = FunctionSpec(
                key,
                item.name,
                tuple(parameters),
                self._resolve_type(item.return_type),
                item.captures,
                item.exported,
                item.span,
            )
            symbol = Symbol(
                item.name,
                "function",
                None,
                False,
                item.exported,
                item.span,
                key,
            )
            self.scope = self._define(self.scope, symbol)
            self.function_symbols.append(symbol)
            self.functions[key] = spec
            self.call_edges[key] = set()

    def _resolve_type(self, syntax: TypeSyntax) -> SemanticType:
        if isinstance(syntax, ScalarType):
            return {"Bool": BOOL, "Text": TEXT, "Int": INT, "Real": REAL}[syntax.name]
        if isinstance(syntax, FailureType):
            return FAILURE
        if isinstance(syntax, QuantityType):
            return _physical("Quantity", _unit_from_syntax(syntax.unit))
        if isinstance(syntax, MassDeltaType):
            unit = _unit_from_syntax(syntax.unit)
            if unit.dimension != MASS:
                raise _diag(
                    "TYPE_MISMATCH",
                    "MassDelta requires a pure mass unit.",
                    syntax.span,
                    expected="mass dimension",
                    actual=list(unit.dimension),
                    context="mass_delta_unit",
                )
            return _physical("MassDelta", unit)
        if isinstance(syntax, MeasurementType):
            return _measurement(self._resolve_type(syntax.value_type))
        if isinstance(syntax, UnknownType):
            base = self._resolve_type(syntax.value_type)
            if base.kind not in UNKNOWN_BASE_KINDS:
                raise _diag(
                    "UNKNOWN_TYPE_UNSUPPORTED",
                    f"Unknown[{base.render()}] is outside the frozen scalar/physical set.",
                    syntax.span,
                    actual=base.render(),
                )
            return _unknown(base)
        if isinstance(syntax, VectorType):
            return _vector(self._resolve_type(syntax.item_type), syntax.size)
        if isinstance(syntax, MapType):
            return _map(self._resolve_type(syntax.value_type))
        if isinstance(syntax, ResultType):
            return _result(self._resolve_type(syntax.value_type))
        if isinstance(syntax, NamedType):
            symbol = self._resolve_symbol_path(syntax.name, self.scope, syntax.span, "type")
            if symbol.kind != "type" or symbol.value_type is None:
                raise self._type_mismatch("type name", symbol.kind, syntax.span, "type")
            return symbol.value_type
        raise AssertionError(f"Unhandled type syntax: {type(syntax).__name__}")

    def _analyze_function(
        self,
        declaration: FunctionDeclaration,
        earlier_immutable: Mapping[str, Symbol],
    ) -> None:
        function_symbol = self.scope.lookup_local(declaration.name)
        assert function_symbol is not None and function_symbol.target is not None
        spec = self.functions[function_symbol.target]

        accessible = Scope()
        for symbol in self.scope.symbols:
            imported_value = (
                symbol in self.import_symbols
                and symbol.value_type is not None
                and not symbol.mutable
            )
            if symbol.kind in {"intrinsic", "namespace", "type", "function"} or imported_value:
                accessible = accessible.add(symbol)
        seen_captures: dict[str, SourceSpan] = {}
        for capture in declaration.captures:
            if capture in seen_captures:
                raise self._duplicate(capture, declaration.span, seen_captures[capture])
            seen_captures[capture] = declaration.span
            target = earlier_immutable.get(capture)
            if target is None:
                visible = self.scope.lookup(capture)
                if visible is not None and visible.mutable:
                    raise self._type_mismatch(
                        "earlier immutable binding",
                        "mutable binding",
                        declaration.span,
                        "capture",
                    )
                raise _diag(
                    "NAME_UNRESOLVED",
                    f"Capture target {capture!r} is not an earlier immutable binding.",
                    declaration.span,
                    name=capture,
                    context="capture",
                )
            accessible = self._define(accessible, replace(target, kind="capture"))

        function_scope = accessible.child()
        for parameter in spec.parameters:
            function_scope = self._define(
                function_scope,
                Symbol(
                    parameter.name,
                    "parameter",
                    parameter.value_type,
                    False,
                    False,
                    parameter.span,
                ),
            )

        for statement in declaration.body:
            function_scope = self._analyze_statement(
                statement,
                function_scope,
                current_function=spec.key,
                in_function=True,
            )
        returned = self._infer(
            declaration.return_expression,
            function_scope,
            expected=spec.return_type,
            current_function=spec.key,
        )
        self._require_assignable(
            spec.return_type,
            returned.value_type,
            declaration.return_expression.span,
            "function_return",
        )

    def _analyze_statement(
        self,
        statement: StatementSyntax,
        scope: Scope,
        *,
        current_function: str | None,
        in_function: bool = False,
    ) -> Scope:
        if isinstance(statement, (LetStatement, DeriveStatement, VarStatement)):
            annotation = None if statement.annotation is None else self._resolve_type(statement.annotation)
            result = self._infer(
                statement.expression,
                scope,
                expected=annotation,
                current_function=current_function,
            )
            value_type = result.value_type if annotation is None else annotation
            if annotation is not None:
                self._require_assignable(
                    annotation,
                    result.value_type,
                    statement.expression.span,
                    "binding_initializer",
                )
            symbol = Symbol(
                statement.name,
                "var" if isinstance(statement, VarStatement) else (
                    "derive" if isinstance(statement, DeriveStatement) else "let"
                ),
                value_type,
                isinstance(statement, VarStatement),
                getattr(statement, "exported", False),
                statement.span,
                (
                    _semantic_key(self.owner, statement.name)
                    if current_function is None
                    else None
                ),
            )
            return self._define(scope, symbol)

        if isinstance(statement, SetStatement):
            target = scope.lookup(statement.name)
            if target is None:
                raise _diag(
                    "NAME_UNRESOLVED",
                    f"Set target {statement.name!r} is not visible.",
                    statement.span,
                    name=statement.name,
                    context="set_target",
                )
            if not target.mutable or target.value_type is None:
                raise self._type_mismatch(
                    "mutable var binding",
                    target.kind,
                    statement.span,
                    "set_target",
                )
            value = self._infer(
                statement.expression,
                scope,
                expected=target.value_type,
                current_function=current_function,
            )
            self._require_assignable(
                target.value_type,
                value.value_type,
                statement.expression.span,
                "set_assignment",
            )
            return scope

        if isinstance(statement, MeasureStatement):
            if in_function:
                raise self._effect_in_function(statement.span, "measure")
            declared = self._resolve_type(statement.annotation)
            underlying = declared.arguments[0]
            nominal = self._infer(
                statement.nominal,
                scope,
                expected=underlying,
                current_function=current_function,
            )
            if nominal.value_type.kind == "Unknown":
                raise _diag(
                    "UNCERTAINTY_UNKNOWN",
                    "A measurement nominal cannot be UNKNOWN.",
                    statement.nominal.span,
                    operand="nominal",
                )
            self._require_assignable(
                underlying,
                nominal.value_type,
                statement.nominal.span,
                "measurement_nominal",
            )
            assert underlying.unit is not None
            uncertainty_type = _physical("Quantity", underlying.unit)
            if _negative_numeric_literal(statement.uncertainty):
                raise _diag(
                    "UNCERTAINTY_NEGATIVE",
                    "Measurement uncertainty cannot be negative.",
                    statement.uncertainty.span,
                    value="negative_literal",
                )
            uncertainty = self._infer(
                statement.uncertainty,
                scope,
                expected=uncertainty_type,
                current_function=current_function,
            )
            if uncertainty.value_type.kind == "Unknown":
                raise _diag(
                    "UNCERTAINTY_UNKNOWN",
                    "A measurement uncertainty cannot be UNKNOWN.",
                    statement.uncertainty.span,
                    operand="uncertainty",
                )
            actual_uncertainty, _ = _unwrap_unknown(uncertainty.value_type)
            if (
                actual_uncertainty.kind != "Quantity"
                or actual_uncertainty.unit is None
                or actual_uncertainty.unit.dimension != underlying.unit.dimension
            ):
                raise _diag(
                    "UNCERTAINTY_DIMENSION",
                    "Measurement uncertainty must be an absolute Quantity of the nominal dimension.",
                    statement.uncertainty.span,
                    nominal=underlying.render(),
                    uncertainty=actual_uncertainty.render(),
                )
            if (
                isinstance(uncertainty.constant, _QuantityConstant)
                and uncertainty.constant.magnitude_si < 0
            ):
                raise _diag(
                    "UNCERTAINTY_NEGATIVE",
                    "Measurement uncertainty cannot be negative.",
                    statement.uncertainty.span,
                    value=_decimal_text(uncertainty.constant.magnitude_si),
                )
            self._record_physical_conversion(
                actual_uncertainty,
                uncertainty_type,
                statement.uncertainty.span,
                "measurement_uncertainty",
            )
            self.inferred_evidence = True
            return self._define(
                scope,
                Symbol(statement.name, "measure", declared, False, False, statement.span),
            )

        if isinstance(statement, EvidenceStatement):
            if in_function:
                raise self._effect_in_function(statement.span, "evidence")
            annotation = None if statement.annotation is None else self._resolve_type(statement.annotation)
            value = self._infer(
                statement.expression,
                scope,
                expected=annotation,
                current_function=current_function,
            )
            if annotation is not None:
                self._require_assignable(
                    annotation,
                    value.value_type,
                    statement.expression.span,
                    "evidence_initializer",
                )
            self.inferred_evidence = True
            return self._define(
                scope,
                Symbol(
                    statement.name,
                    "evidence",
                    value.value_type if annotation is None else annotation,
                    False,
                    False,
                    statement.span,
                ),
            )

        if isinstance(statement, RequireStatement):
            if in_function:
                raise self._effect_in_function(statement.span, "require")
            condition = self._infer(
                statement.condition,
                scope,
                current_function=current_function,
            )
            self._require_boolean(condition.value_type, statement.condition.span, "require")
            return scope

        if isinstance(statement, EmitStatement):
            if in_function:
                raise self._effect_in_function(statement.span, "emit")
            value = self._infer(statement.expression, scope, current_function=current_function)
            if value.value_type.kind in {"Namespace", "Function", "Type"}:
                raise self._type_mismatch(
                    "serializable value",
                    value.value_type.render(),
                    statement.expression.span,
                    "emit",
                )
            return scope

        if isinstance(statement, IfStatement):
            condition = self._infer(statement.condition, scope, current_function=current_function)
            self._require_boolean(condition.value_type, statement.condition.span, "if")
            then_scope = scope.child()
            refinement = self._knownness_refinement(statement.condition, scope)
            if refinement is not None:
                then_scope = then_scope.refine(*refinement)
            for nested in statement.then_body:
                then_scope = self._analyze_statement(
                    nested,
                    then_scope,
                    current_function=current_function,
                    in_function=in_function,
                )
            else_scope = scope.child()
            for nested in statement.else_body:
                else_scope = self._analyze_statement(
                    nested,
                    else_scope,
                    current_function=current_function,
                    in_function=in_function,
                )
            return scope

        if isinstance(statement, ForStatement):
            iterable = self._infer(statement.iterable, scope, current_function=current_function)
            base, unknown = _unwrap_unknown(iterable.value_type)
            if unknown or base.kind != "Vector":
                raise self._type_mismatch(
                    "Vector[T]",
                    iterable.value_type.render(),
                    statement.iterable.span,
                    "for_iterable",
                )
            if base.size is not None and base.size > statement.limit:
                raise _diag(
                    "LOOP_LIMIT_EXCEEDED",
                    "Fixed Vector length exceeds the declared for-loop limit.",
                    statement.span,
                    length=base.size,
                    limit=statement.limit,
                )
            loop_scope = scope.child()
            loop_scope = self._define(
                loop_scope,
                Symbol(
                    statement.name,
                    "loop",
                    base.arguments[0],
                    False,
                    False,
                    statement.span,
                ),
            )
            for nested in statement.body:
                loop_scope = self._analyze_statement(
                    nested,
                    loop_scope,
                    current_function=current_function,
                    in_function=in_function,
                )
            return scope

        if isinstance(statement, MatchStatement):
            matched = self._infer(statement.expression, scope, current_function=current_function)
            self._analyze_match(
                statement,
                matched.value_type,
                scope,
                current_function=current_function,
                in_function=in_function,
            )
            return scope

        raise AssertionError(f"Unhandled statement: {type(statement).__name__}")

    def _infer(
        self,
        expression: ExpressionSyntax,
        scope: Scope,
        *,
        expected: SemanticType | None = None,
        current_function: str | None = None,
    ) -> TypedExpression:
        if isinstance(expression, BooleanLiteral):
            result = TypedExpression(expression, BOOL, expression.value)
        elif isinstance(expression, TextLiteral):
            result = TypedExpression(expression, TEXT, expression.value)
        elif isinstance(expression, IntegerLiteral):
            self._check_int(expression.value, expression.span)
            result = TypedExpression(expression, INT, expression.value)
        elif isinstance(expression, RealLiteral):
            result = TypedExpression(
                expression,
                REAL,
                self._decimal128(expression.value, expression.span),
            )
        elif isinstance(expression, QuantityLiteral):
            unit = _unit_from_syntax(expression.unit)
            if isinstance(expression.magnitude, IntegerLiteral):
                self._check_int(expression.magnitude.value, expression.magnitude.span)
                magnitude = Decimal(expression.magnitude.value)
            else:
                magnitude = self._decimal128(
                    expression.magnitude.value,
                    expression.magnitude.span,
                )
            result = TypedExpression(
                expression,
                _physical("Quantity", unit),
                _QuantityConstant(
                    self._physical_decimal(
                        "*",
                        magnitude,
                        unit.scale,
                        expression.span,
                    ),
                    unit.dimension,
                ),
            )
        elif isinstance(expression, NameExpression):
            symbol = self._resolve_value(expression.name, scope, expression.span)
            assert symbol.value_type is not None
            result = TypedExpression(expression, symbol.value_type)
        elif isinstance(expression, VectorLiteral):
            result = self._infer_vector(expression, scope, expected, current_function)
        elif isinstance(expression, MapLiteral):
            result = self._infer_map(expression, scope, expected, current_function)
        elif isinstance(expression, UnknownExpression):
            value_type = self._resolve_type(expression.value_type)
            if value_type.kind not in UNKNOWN_BASE_KINDS:
                raise _diag(
                    "UNKNOWN_TYPE_UNSUPPORTED",
                    f"Unknown[{value_type.render()}] is not admitted.",
                    expression.span,
                    actual=value_type.render(),
                )
            result = TypedExpression(expression, _unknown(value_type))
        elif isinstance(expression, MassDeltaExpression):
            unit = _unit_from_syntax(expression.unit)
            if unit.dimension != MASS:
                raise _diag(
                    "TYPE_MISMATCH",
                    "mass_delta requires a registered pure mass unit.",
                    expression.span,
                    expected="mass dimension",
                    actual=list(unit.dimension),
                    context="mass_delta_constructor",
                )
            magnitude = self._infer(
                expression.magnitude,
                scope,
                current_function=current_function,
            )
            base, unknown = _unwrap_unknown(magnitude.value_type)
            if unknown or base.kind not in NUMERIC_KINDS:
                raise self._type_mismatch(
                    "Int or Real",
                    magnitude.value_type.render(),
                    expression.magnitude.span,
                    "mass_delta_constructor",
                )
            constant = _NO_CONSTANT
            if isinstance(magnitude.constant, (int, Decimal)):
                constant = _QuantityConstant(
                    self._physical_decimal(
                        "*",
                        Decimal(magnitude.constant),
                        unit.scale,
                        expression.span,
                    ),
                    unit.dimension,
                    True,
                )
            result = TypedExpression(expression, _physical("MassDelta", unit), constant)
        elif isinstance(expression, UnaryExpression):
            result = self._infer_unary(expression, scope, current_function)
        elif isinstance(expression, BinaryExpression):
            result = self._infer_binary(expression, scope, current_function)
        elif isinstance(expression, CallExpression):
            result = self._infer_call(expression, scope, expected, current_function)
        elif isinstance(expression, IndexExpression):
            result = self._infer_index(expression, scope, current_function)
        elif isinstance(expression, FieldExpression):
            result = self._infer_field(expression, scope, current_function)
        elif isinstance(expression, ResultConstructor):
            result = self._infer_result(expression, scope, expected, current_function)
        elif isinstance(expression, FailureConstructor):
            result = self._infer_failure(expression, scope, current_function)
        else:
            raise AssertionError(f"Unhandled expression: {type(expression).__name__}")

        self.expressions.append(result)
        return result

    def _infer_vector(
        self,
        expression: VectorLiteral,
        scope: Scope,
        expected: SemanticType | None,
        current_function: str | None,
    ) -> TypedExpression:
        expected_base, _ = _unwrap_unknown(expected) if expected is not None else (None, False)
        expected_vector = expected_base if expected_base is not None and expected_base.kind == "Vector" else None
        if not expression.items:
            if expected_vector is None:
                raise self._type_mismatch(
                    "annotated Vector[T]",
                    "untyped empty Vector",
                    expression.span,
                    "empty_vector",
                )
            return TypedExpression(expression, _vector(expected_vector.arguments[0], 0))
        items = [
            self._infer(
                item,
                scope,
                expected=None if expected_vector is None else expected_vector.arguments[0],
                current_function=current_function,
            )
            for item in expression.items
        ]
        item_type = items[0].value_type
        for item in items[1:]:
            if not self._is_assignable(item_type, item.value_type) or not self._is_assignable(
                item.value_type, item_type
            ):
                raise self._type_mismatch(
                    item_type.render(),
                    item.value_type.render(),
                    item.expression.span,
                    "vector_element",
                )
        if expected_vector is not None:
            for item in items:
                self._require_assignable(
                    expected_vector.arguments[0],
                    item.value_type,
                    item.expression.span,
                    "vector_element",
                )
            item_type = expected_vector.arguments[0]
        return TypedExpression(expression, _vector(item_type, len(items)))

    def _infer_map(
        self,
        expression: MapLiteral,
        scope: Scope,
        expected: SemanticType | None,
        current_function: str | None,
    ) -> TypedExpression:
        expected_base, _ = _unwrap_unknown(expected) if expected is not None else (None, False)
        expected_map = expected_base if expected_base is not None and expected_base.kind == "Map" else None
        if not expression.entries:
            if expected_map is None:
                raise self._type_mismatch(
                    "annotated Map[Text, T]",
                    "untyped empty Map",
                    expression.span,
                    "empty_map",
                )
            return TypedExpression(expression, expected_map)
        keys: set[str] = set()
        values: list[TypedExpression] = []
        for entry in expression.entries:
            if entry.key.value in keys:
                raise _diag(
                    "CLOSED_SCHEMA_VIOLATION",
                    f"Duplicate Map key {entry.key.value!r}.",
                    entry.key.span,
                    structure="Map",
                    field=entry.key.value,
                    violation="duplicate",
                )
            keys.add(entry.key.value)
            values.append(
                self._infer(
                    entry.value,
                    scope,
                    expected=None if expected_map is None else expected_map.arguments[0],
                    current_function=current_function,
                )
            )
        value_type = values[0].value_type
        if expected_map is not None:
            value_type = expected_map.arguments[0]
        for value in values:
            self._require_assignable(
                value_type,
                value.value_type,
                value.expression.span,
                "map_value",
            )
        return TypedExpression(expression, _map(value_type))

    def _infer_unary(
        self,
        expression: UnaryExpression,
        scope: Scope,
        current_function: str | None,
    ) -> TypedExpression:
        if (
            expression.operator == "-"
            and isinstance(expression.operand, IntegerLiteral)
            and expression.operand.value == 2**63
        ):
            return TypedExpression(expression, INT, INT64_MIN)
        operand = self._infer(expression.operand, scope, current_function=current_function)
        base, unknown = _unwrap_unknown(operand.value_type)
        if expression.operator == "not":
            if base != BOOL:
                raise self._type_mismatch("Bool", operand.value_type.render(), expression.span, "unary_not")
            return TypedExpression(expression, _unknown(BOOL) if unknown else BOOL)
        if base.kind not in {*NUMERIC_KINDS, *PHYSICAL_KINDS, "Measurement"}:
            raise self._type_mismatch(
                "numeric or physical value",
                operand.value_type.render(),
                expression.span,
                "unary_sign",
            )
        if expression.operator == "-":
            underlying = base.arguments[0] if base.kind == "Measurement" else base
            if (
                underlying.kind == "Quantity"
                and underlying.unit is not None
                and underlying.unit.dimension == MASS
            ):
                raise _diag(
                    "NEGATIVE_MASS",
                    "Unary minus cannot construct a negative absolute mass.",
                    expression.span,
                    operation="unary_minus",
                )
        constant = operand.constant
        if expression.operator == "-" and isinstance(constant, (int, Decimal)):
            constant = -constant
            if isinstance(constant, int):
                self._check_int(constant, expression.span)
        elif expression.operator == "-" and isinstance(constant, _QuantityConstant):
            constant = replace(constant, magnitude_si=-constant.magnitude_si)
        return TypedExpression(expression, operand.value_type, constant)

    def _infer_binary(
        self,
        expression: BinaryExpression,
        scope: Scope,
        current_function: str | None,
    ) -> TypedExpression:
        left = self._infer(expression.left, scope, current_function=current_function)
        right = self._infer(expression.right, scope, current_function=current_function)
        result_type, constant = self._binary_result(
            expression.operator,
            left,
            right,
            expression.span,
        )
        return TypedExpression(expression, result_type, constant)

    def _binary_result(
        self,
        operator: str,
        left: TypedExpression,
        right: TypedExpression,
        span: SourceSpan,
    ) -> tuple[SemanticType, object]:
        left_type, left_unknown = _unwrap_unknown(left.value_type)
        right_type, right_unknown = _unwrap_unknown(right.value_type)
        unknown = left_unknown or right_unknown

        if left_type.kind == "Measurement" or right_type.kind == "Measurement":
            if operator in {"*", "/"}:
                raise _diag(
                    "UNCERTAINTY_PROPAGATION_POLICY",
                    "Measurement multiplication and division are unsupported in Bangel 1.0.",
                    span,
                    operator=operator,
                )
            if operator in {"==", "!=", "<", "<=", ">", ">="}:
                raise _diag(
                    "MEASUREMENT_COMPARISON_POLICY",
                    "Measurement comparison requires an explicit nominal projection.",
                    span,
                    operator=operator,
                )
            if operator not in {"+", "-"}:
                raise self._type_mismatch(
                    "Measurement addition or subtraction",
                    operator,
                    span,
                    "measurement_operator",
                )
            left_value = left_type.arguments[0] if left_type.kind == "Measurement" else left_type
            right_value = right_type.arguments[0] if right_type.kind == "Measurement" else right_type
            synthetic_left = TypedExpression(left.expression, left_value)
            synthetic_right = TypedExpression(right.expression, right_value)
            value_type, _ = self._binary_result(operator, synthetic_left, synthetic_right, span)
            result = _measurement(value_type)
            return (_unknown(result) if unknown else result), _NO_CONSTANT

        if operator in {"and", "or"}:
            if left_type != BOOL or right_type != BOOL:
                raise self._type_mismatch(
                    "Bool operands",
                    f"{left.value_type.render()} {operator} {right.value_type.render()}",
                    span,
                    "boolean_operator",
                )
            decisive = (
                False
                if operator == "and"
                and (left.constant is False or right.constant is False)
                else True
                if operator == "or"
                and (left.constant is True or right.constant is True)
                else _NO_CONSTANT
            )
            if decisive is not _NO_CONSTANT:
                return BOOL, decisive
            if unknown:
                return _unknown(BOOL), _NO_CONSTANT
            if isinstance(left.constant, bool) and isinstance(right.constant, bool):
                value = (
                    left.constant and right.constant
                    if operator == "and"
                    else left.constant or right.constant
                )
                return BOOL, value
            return BOOL, _NO_CONSTANT

        if operator in {"==", "!=", "<", "<=", ">", ">="}:
            self._comparison_types(left_type, right_type, span, operator)
            self._record_physical_conversion(
                right_type,
                left_type,
                right.expression.span,
                "comparison_operand",
            )
            return (_unknown(BOOL) if unknown else BOOL), _NO_CONSTANT

        result, constant = self._arithmetic_types(operator, left_type, right_type, left, right, span)
        return (_unknown(result) if unknown else result), constant

    def _comparison_types(
        self,
        left: SemanticType,
        right: SemanticType,
        span: SourceSpan,
        operator: str,
    ) -> None:
        if left.kind in NUMERIC_KINDS and right.kind in NUMERIC_KINDS:
            return
        if left.kind in PHYSICAL_KINDS and right.kind == left.kind:
            assert left.unit is not None and right.unit is not None
            if left.unit.dimension != right.unit.dimension:
                raise self._dimension_mismatch(left, right, span, operator)
            return
        if left == right and (
            operator in {"==", "!="} or left.kind in {"Text", "Int", "Real", "Quantity", "MassDelta"}
        ):
            return
        raise self._type_mismatch(left.render(), right.render(), span, "comparison")

    def _arithmetic_types(
        self,
        operator: str,
        left_type: SemanticType,
        right_type: SemanticType,
        left: TypedExpression,
        right: TypedExpression,
        span: SourceSpan,
    ) -> tuple[SemanticType, object]:
        if left_type.kind in NUMERIC_KINDS and right_type.kind in NUMERIC_KINDS:
            result_type = REAL if operator == "/" or "Real" in {left_type.kind, right_type.kind} else INT
            constant = self._scalar_constant(operator, left.constant, right.constant, result_type, span)
            return result_type, constant

        if operator in {"+", "-"}:
            return self._physical_additive(operator, left_type, right_type, left, right, span)
        return self._physical_multiplicative(operator, left_type, right_type, left, right, span)

    def _physical_additive(
        self,
        operator: str,
        left_type: SemanticType,
        right_type: SemanticType,
        left: TypedExpression,
        right: TypedExpression,
        span: SourceSpan,
    ) -> tuple[SemanticType, object]:
        if left_type.kind not in PHYSICAL_KINDS or right_type.kind not in PHYSICAL_KINDS:
            raise self._type_mismatch(
                left_type.render(), right_type.render(), span, "additive_operator"
            )
        assert left_type.unit is not None and right_type.unit is not None
        if left_type.unit.dimension != right_type.unit.dimension:
            raise self._dimension_mismatch(left_type, right_type, span, operator)

        if left_type.kind == "Quantity" and right_type.kind == "Quantity":
            result_kind = (
                "MassDelta"
                if operator == "-" and left_type.unit.dimension == MASS
                else "Quantity"
            )
            unit = left_type.unit
        elif left_type.kind == "Quantity" and right_type.kind == "MassDelta":
            if left_type.unit.dimension != MASS:
                raise self._mass_delta_unsupported(operator, left_type, right_type, span)
            result_kind = "Quantity"
            unit = left_type.unit
        elif left_type.kind == "MassDelta" and right_type.kind == "Quantity":
            if operator != "+":
                raise self._mass_delta_unsupported(operator, left_type, right_type, span)
            result_kind = "Quantity"
            unit = right_type.unit
            conversion_source = left_type
            conversion_target = _physical("MassDelta", unit)
            conversion_span = left.expression.span
        else:
            result_kind = "MassDelta"
            unit = left_type.unit
        if not (
            left_type.kind == "MassDelta"
            and right_type.kind == "Quantity"
            and operator == "+"
        ):
            conversion_source = right_type
            conversion_target = _physical(right_type.kind, unit)
            conversion_span = right.expression.span

        self._record_physical_conversion(
            conversion_source,
            conversion_target,
            conversion_span,
            "binary_operand",
        )
        constant = _NO_CONSTANT
        if isinstance(left.constant, _QuantityConstant) and isinstance(right.constant, _QuantityConstant):
            magnitude = self._physical_decimal(
                operator,
                left.constant.magnitude_si,
                right.constant.magnitude_si,
                span,
            )
            if result_kind == "Quantity" and unit.dimension == MASS and magnitude < 0:
                raise _diag(
                    "NEGATIVE_MASS",
                    "Mass arithmetic constructs a negative absolute mass.",
                    span,
                    operation=operator,
                    value_si=_decimal_text(magnitude),
                )
            constant = _QuantityConstant(magnitude, unit.dimension, result_kind == "MassDelta")
        return _physical(result_kind, unit), constant

    def _physical_multiplicative(
        self,
        operator: str,
        left_type: SemanticType,
        right_type: SemanticType,
        left: TypedExpression,
        right: TypedExpression,
        span: SourceSpan,
    ) -> tuple[SemanticType, object]:
        left_scalar = left_type.kind in NUMERIC_KINDS
        right_scalar = right_type.kind in NUMERIC_KINDS
        if "MassDelta" in {left_type.kind, right_type.kind}:
            allowed = (
                operator == "*" and (left_scalar or right_scalar)
            ) or (operator == "/" and left_type.kind == "MassDelta" and right_scalar)
            if not allowed:
                raise self._mass_delta_unsupported(operator, left_type, right_type, span)
            delta = right_type if right_type.kind == "MassDelta" else left_type
            assert delta.unit is not None
            return delta, self._quantity_scalar_constant(operator, left, right, span, signed_delta=True)

        if left_type.kind == "Quantity" and right_scalar:
            assert left_type.unit is not None
            return left_type, self._quantity_scalar_constant(operator, left, right, span)
        if left_scalar and right_type.kind == "Quantity":
            assert right_type.unit is not None
            if operator == "*":
                return right_type, self._quantity_scalar_constant(operator, left, right, span)
            unit = _combined_unit(
                ResolvedUnit("1", DIMENSIONLESS, Decimal(1)),
                right_type.unit,
                divide=True,
            )
            return _physical("Quantity", unit), self._quantity_scalar_constant(operator, left, right, span)
        if left_type.kind == "Quantity" and right_type.kind == "Quantity":
            assert left_type.unit is not None and right_type.unit is not None
            unit = _combined_unit(
                left_type.unit,
                right_type.unit,
                divide=operator == "/",
            )
            dimension = unit.dimension
            constant = _NO_CONSTANT
            if isinstance(left.constant, _QuantityConstant) and isinstance(right.constant, _QuantityConstant):
                if operator == "/" and right.constant.magnitude_si == 0:
                    raise _diag("DIVISION_ZERO", "Division by zero is not admitted.", span, context="quantity")
                magnitude = self._physical_decimal(
                    operator,
                    left.constant.magnitude_si,
                    right.constant.magnitude_si,
                    span,
                )
                constant = _QuantityConstant(magnitude, dimension)
            return _physical("Quantity", unit), constant
        raise self._type_mismatch(
            "numeric or physical operands",
            f"{left_type.render()} {operator} {right_type.render()}",
            span,
            "multiplicative_operator",
        )

    def _infer_call(
        self,
        expression: CallExpression,
        scope: Scope,
        expected: SemanticType | None,
        current_function: str | None,
    ) -> TypedExpression:
        path = _path(expression.callee)
        if path is None:
            raise self._type_mismatch(
                "named callable",
                type(expression.callee).__name__,
                expression.callee.span,
                "call_target",
            )
        if path == ("variance",):
            raise _diag(
                "VARIANCE_NAME_AMBIGUOUS",
                "Bare variance is not allocated in Bangel core 1.0.",
                expression.callee.span,
                name="variance",
            )

        resolved = self._resolve_callable_path(path, scope, expression.callee.span)
        kind, target = resolved
        self.references.append(
            ReferenceFact(expression.callee.span, ".".join(path), kind, target)
        )
        if kind == "record":
            return self._infer_record_constructor(
                expression, self.records[target], scope, current_function
            )
        if kind == "enum_variant":
            enum_key, variant_name = target.rsplit("#", 1)
            return self._infer_enum_constructor(
                expression,
                self.enums[enum_key],
                variant_name,
                scope,
                current_function,
            )
        if kind == "function":
            spec = self.functions[target]
            if current_function is not None:
                self.call_edges[current_function].add(target)
            arguments = self._bind_arguments(
                expression.arguments,
                spec.parameters,
                scope,
                current_function,
                context="function_call",
                fallback_span=expression.span,
            )
            del arguments
            return TypedExpression(expression, spec.return_type)
        if kind == "intrinsic":
            return self._infer_intrinsic(
                target,
                expression,
                scope,
                expected,
                current_function,
            )
        raise AssertionError(kind)

    def _infer_record_constructor(
        self,
        expression: CallExpression,
        spec: RecordSpec,
        scope: Scope,
        current_function: str | None,
    ) -> TypedExpression:
        self._bind_closed_fields(
            expression.arguments,
            spec.fields,
            scope,
            current_function,
            spec.value_type.render(),
            expression.span,
        )
        return TypedExpression(expression, spec.value_type)

    def _infer_enum_constructor(
        self,
        expression: CallExpression,
        spec: EnumSpec,
        variant_name: str,
        scope: Scope,
        current_function: str | None,
    ) -> TypedExpression:
        variant = next(item for item in spec.variants if item.name == variant_name)
        if any(argument.name is not None for argument in expression.arguments):
            self._bind_closed_fields(
                expression.arguments,
                variant.fields,
                scope,
                current_function,
                f"{spec.value_type.render()}.{variant.name}",
                expression.span,
            )
        else:
            parameters = tuple(
                ParameterSpec(field.name, field.value_type, field.span)
                for field in variant.fields
            )
            self._bind_arguments(
                expression.arguments,
                parameters,
                scope,
                current_function,
                context="enum_constructor",
                fallback_span=expression.span,
            )
        return TypedExpression(expression, spec.value_type)

    def _infer_intrinsic(
        self,
        target: str,
        expression: CallExpression,
        scope: Scope,
        expected: SemanticType | None,
        current_function: str | None,
    ) -> TypedExpression:
        name = target.split(".")[-1]
        if target.startswith("core."):
            return self._infer_core_intrinsic(name, expression, scope, current_function)
        arguments = [
            self._infer(argument.value, scope, current_function=current_function)
            for argument in expression.arguments
        ]
        if any(argument.name is not None for argument in expression.arguments):
            raise self._type_mismatch("positional intrinsic arguments", "named arguments", expression.span, "intrinsic_call")
        return self._infer_standard_intrinsic(target, expression, arguments, expected)

    def _infer_core_intrinsic(
        self,
        name: str,
        expression: CallExpression,
        scope: Scope,
        current_function: str | None,
    ) -> TypedExpression:
        if any(argument.name is not None for argument in expression.arguments):
            raise self._type_mismatch("positional intrinsic arguments", "named arguments", expression.span, "intrinsic_call")
        if name == "is_known":
            self._require_argument_count(expression, 1)
            self._infer(expression.arguments[0].value, scope, current_function=current_function)
            return TypedExpression(expression, BOOL)
        if name in {"nominal", "uncertainty"}:
            self._require_argument_count(expression, 1)
            value = self._infer(expression.arguments[0].value, scope, current_function=current_function)
            base, unknown = _unwrap_unknown(value.value_type)
            if base.kind != "Measurement":
                raise self._type_mismatch("Measurement[T]", value.value_type.render(), expression.span, name)
            underlying = base.arguments[0]
            result = underlying
            if name == "uncertainty":
                assert underlying.unit is not None
                result = _physical("Quantity", underlying.unit)
            return TypedExpression(expression, _unknown(result) if unknown else result)
        if name == "convert":
            self._require_argument_count(expression, 2)
            value = self._infer(expression.arguments[0].value, scope, current_function=current_function)
            unit_argument = expression.arguments[1].value
            if not isinstance(unit_argument, TextLiteral):
                raise self._type_mismatch("Text unit literal", type(unit_argument).__name__, unit_argument.span, "convert")
            # The unit literal is a typed child in the frozen JP-IR call.
            self._infer(unit_argument, scope, current_function=current_function)
            registered = UNITS.get(unit_argument.value)
            if registered is None:
                raise _diag("UNIT_UNKNOWN", f"Unknown Bangel-Units/1 symbol {unit_argument.value!r}.", unit_argument.span, unit=unit_argument.value)
            base, unknown = _unwrap_unknown(value.value_type)
            container = None
            physical = base
            if base.kind == "Measurement":
                container = "Measurement"
                physical = base.arguments[0]
            if physical.kind not in PHYSICAL_KINDS or physical.unit is None:
                raise self._type_mismatch("Quantity, MassDelta, or Measurement", value.value_type.render(), expression.span, "convert")
            if physical.unit.dimension != registered.dimension:
                target_type = _physical(physical.kind, ResolvedUnit(unit_argument.value, registered.dimension, registered.scale))
                raise self._dimension_mismatch(physical, target_type, expression.span, "convert")
            converted = _physical(
                physical.kind,
                ResolvedUnit(unit_argument.value, registered.dimension, registered.scale),
            )
            self._record_physical_conversion(physical, converted, expression.span, "convert")
            result = _measurement(converted) if container else converted
            return TypedExpression(expression, _unknown(result) if unknown else result)
        raise AssertionError(name)

    def _infer_standard_intrinsic(
        self,
        target: str,
        expression: CallExpression,
        arguments: list[TypedExpression],
        expected: SemanticType | None,
    ) -> TypedExpression:
        name = target.split(".")[-1]
        module = target.rsplit(".", 1)[0]
        if module == "std.math":
            if name == "abs":
                self._count(arguments, 1, expression.span)
                base, unknown = _unwrap_unknown(arguments[0].value_type)
                if base.kind not in {*NUMERIC_KINDS, *PHYSICAL_KINDS}:
                    raise self._type_mismatch("numeric or physical value", arguments[0].value_type.render(), expression.span, "std.math.abs")
                return TypedExpression(expression, _unknown(base) if unknown else base)
            if name in {"min", "max"}:
                self._count(arguments, 2, expression.span)
                left, left_unknown = _unwrap_unknown(arguments[0].value_type)
                right, right_unknown = _unwrap_unknown(arguments[1].value_type)
                self._comparison_types(left, right, expression.span, name)
                self._record_physical_conversion(
                    right,
                    left,
                    arguments[1].expression.span,
                    f"std.math.{name}",
                )
                result = REAL if left.kind in NUMERIC_KINDS and right.kind in NUMERIC_KINDS and "Real" in {left.kind, right.kind} else left
                return TypedExpression(
                    expression,
                    _unknown(result) if left_unknown or right_unknown else result,
                )
            if name == "sqrt":
                self._count(arguments, 1, expression.span)
                base, unknown = _unwrap_unknown(arguments[0].value_type)
                if base.kind in NUMERIC_KINDS:
                    result = REAL
                elif base.kind == "Quantity" and base.unit is not None and all(power % 2 == 0 for power in base.unit.dimension):
                    dimension = tuple(power // 2 for power in base.unit.dimension)
                    result = _physical("Quantity", _canonical_unit(dimension))
                else:
                    raise self._type_mismatch("Real or even-dimension Quantity", base.render(), expression.span, "std.math.sqrt")
                return TypedExpression(expression, _unknown(result) if unknown else result)

        if module == "std.vector":
            return self._infer_vector_intrinsic(name, expression, arguments)
        if module == "std.map":
            return self._infer_map_intrinsic(name, expression, arguments)
        if module == "std.topology":
            return self._infer_topology_intrinsic(name, expression, arguments)
        raise _diag("NAME_UNRESOLVED", f"Unknown intrinsic {target!r}.", expression.span, name=target, context="intrinsic")

    def _infer_vector_intrinsic(self, name: str, expression: CallExpression, arguments: list[TypedExpression]) -> TypedExpression:
        if name == "length":
            self._count(arguments, 1, expression.span)
            vector_type = self._require_container(arguments[0], "Vector", expression.span, name)
            del vector_type
            return TypedExpression(expression, INT)
        if name == "at":
            self._count(arguments, 2, expression.span)
            vector_type = self._require_container(arguments[0], "Vector", expression.span, name)
            self._require_exact_type(INT, arguments[1].value_type, arguments[1].expression.span, "vector_index")
            return TypedExpression(expression, _result(vector_type.arguments[0]))
        if name in {"sum", "mean", "norm"}:
            self._count(arguments, 1, expression.span)
            vector_type = self._require_container(arguments[0], "Vector", expression.span, name)
            item, unknown = _unwrap_unknown(vector_type.arguments[0])
            if item.kind not in {*NUMERIC_KINDS, *PHYSICAL_KINDS}:
                raise self._type_mismatch("numeric Vector", vector_type.render(), expression.span, name)
            result = REAL if name == "mean" and item.kind == "Int" else item
            return TypedExpression(expression, _unknown(result) if unknown else result)
        if name == "dot":
            self._count(arguments, 2, expression.span)
            left = self._require_container(arguments[0], "Vector", expression.span, name)
            right = self._require_container(arguments[1], "Vector", expression.span, name)
            left_item, left_unknown = _unwrap_unknown(left.arguments[0])
            right_item, right_unknown = _unwrap_unknown(right.arguments[0])
            product, _ = self._arithmetic_types(
                "*",
                left_item,
                right_item,
                arguments[0],
                arguments[1],
                expression.span,
            )
            return TypedExpression(
                expression,
                _unknown(product) if left_unknown or right_unknown else product,
            )
        if name == "moving_mean":
            self._count(arguments, 2, expression.span)
            vector_type = self._require_container(arguments[0], "Vector", expression.span, name)
            self._require_exact_type(INT, arguments[1].value_type, arguments[1].expression.span, "moving_mean_window")
            item, unknown = _unwrap_unknown(vector_type.arguments[0])
            if item.kind not in {*NUMERIC_KINDS, *PHYSICAL_KINDS}:
                raise self._type_mismatch("numeric Vector", vector_type.render(), expression.span, name)
            item = REAL if item.kind == "Int" else item
            result = _unknown(item) if unknown else item
            return TypedExpression(expression, _vector(result))
        if name == "slope":
            self._count(arguments, 2, expression.span)
            x = self._require_container(arguments[0], "Vector", expression.span, name)
            y = self._require_container(arguments[1], "Vector", expression.span, name)
            x_item, x_unknown = _unwrap_unknown(x.arguments[0])
            y_item, y_unknown = _unwrap_unknown(y.arguments[0])
            slope, _ = self._arithmetic_types(
                "/",
                y_item,
                x_item,
                arguments[1],
                arguments[0],
                expression.span,
            )
            return TypedExpression(
                expression,
                _unknown(slope) if x_unknown or y_unknown else slope,
            )
        raise AssertionError(name)

    def _infer_map_intrinsic(self, name: str, expression: CallExpression, arguments: list[TypedExpression]) -> TypedExpression:
        if name == "length":
            self._count(arguments, 1, expression.span)
            self._require_container(arguments[0], "Map", expression.span, name)
            return TypedExpression(expression, INT)
        if name == "at":
            self._count(arguments, 2, expression.span)
            map_type = self._require_container(arguments[0], "Map", expression.span, name)
            self._require_exact_type(TEXT, arguments[1].value_type, arguments[1].expression.span, "map_index")
            return TypedExpression(expression, _result(map_type.arguments[0]))
        if name in {"keys", "values"}:
            self._count(arguments, 1, expression.span)
            map_type = self._require_container(arguments[0], "Map", expression.span, name)
            return TypedExpression(expression, _vector(TEXT if name == "keys" else map_type.arguments[0]))
        raise AssertionError(name)

    def _infer_topology_intrinsic(self, name: str, expression: CallExpression, arguments: list[TypedExpression]) -> TypedExpression:
        if name in {"node_variance", "shadow_speed"}:
            self._count(arguments, 2, expression.span)
            left, left_unknown = _unwrap_unknown(arguments[0].value_type)
            right, right_unknown = _unwrap_unknown(arguments[1].value_type)
            if (
                left_unknown
                or right_unknown
                or left.kind != "Quantity"
                or right.kind != "Quantity"
                or left.unit is None
                or right.unit is None
            ):
                raise self._type_mismatch("two exact Quantity values", f"{left.render()}, {right.render()}", expression.span, name)
            if left.unit.dimension != right.unit.dimension:
                raise self._dimension_mismatch(left, right, expression.span, name)
            self._record_physical_conversion(
                right,
                left,
                arguments[1].expression.span,
                f"std.topology.{name}",
            )
            return TypedExpression(expression, left)
        if name == "dampen":
            self._count(arguments, 1, expression.span)
            base, unknown = _unwrap_unknown(arguments[0].value_type)
            if base.kind == "Measurement":
                raise _diag("UNCERTAINTY_PROPAGATION_POLICY", "dampen does not admit Measurement in Bangel 1.0.", expression.span, operator="dampen")
            if base.kind not in {"Real", "Quantity", "MassDelta"}:
                raise self._type_mismatch("Real, Quantity, or MassDelta", base.render(), expression.span, name)
            return TypedExpression(expression, _unknown(base) if unknown else base)
        if name in {"step_cap", "bound"}:
            self._count(arguments, 1, expression.span)
            base, unknown = _unwrap_unknown(arguments[0].value_type)
            if base != REAL:
                raise self._type_mismatch("Real", base.render(), expression.span, name)
            return TypedExpression(expression, _unknown(REAL) if unknown else REAL)
        if name == "floor_challenge":
            self._count(arguments, 1, expression.span)
            base, unknown = _unwrap_unknown(arguments[0].value_type)
            if base.kind != "Quantity" or base.unit is None or base.unit.dimension != MASS:
                raise self._type_mismatch("absolute mass Quantity", base.render(), expression.span, name)
            return TypedExpression(expression, _unknown(BOOL) if unknown else BOOL)
        raise AssertionError(name)

    def _infer_index(self, expression: IndexExpression, scope: Scope, current_function: str | None) -> TypedExpression:
        target = self._infer(expression.target, scope, current_function=current_function)
        index = self._infer(expression.index, scope, current_function=current_function)
        base, unknown = _unwrap_unknown(target.value_type)
        if unknown:
            raise self._type_mismatch("known Vector or Map", target.value_type.render(), expression.target.span, "index_target")
        if base.kind == "Vector":
            self._require_exact_type(INT, index.value_type, expression.index.span, "vector_index")
            return TypedExpression(expression, _result(base.arguments[0]))
        if base.kind == "Map":
            self._require_exact_type(TEXT, index.value_type, expression.index.span, "map_index")
            return TypedExpression(expression, _result(base.arguments[0]))
        raise self._type_mismatch("Vector or Map", target.value_type.render(), expression.target.span, "index_target")

    def _infer_field(self, expression: FieldExpression, scope: Scope, current_function: str | None) -> TypedExpression:
        path = _path(expression)
        if path is not None:
            symbolic = self._resolve_symbolic_value_path(path, scope, expression.span)
            if symbolic is not None:
                return TypedExpression(expression, symbolic)
        target = self._infer(expression.target, scope, current_function=current_function)
        base, unknown = _unwrap_unknown(target.value_type)
        if base.kind == "Record":
            spec = self.records[_type_key(base)]
            field = next((item for item in spec.fields if item.name == expression.field), None)
            if field is None:
                raise _diag("CLOSED_SCHEMA_VIOLATION", f"Record {base.render()} has no field {expression.field!r}.", expression.span, structure=base.render(), field=expression.field, violation="unknown")
            result = field.value_type
        elif base.kind == "Failure":
            if expression.field not in {"code", "message"}:
                raise _diag("CLOSED_SCHEMA_VIOLATION", f"Failure has no field {expression.field!r}.", expression.span, structure="Failure", field=expression.field, violation="unknown")
            result = TEXT
        else:
            raise self._type_mismatch("record value", target.value_type.render(), expression.span, "field_access")
        return TypedExpression(expression, _unknown(result) if unknown else result)

    def _infer_result(self, expression: ResultConstructor, scope: Scope, expected: SemanticType | None, current_function: str | None) -> TypedExpression:
        self._require_argument_count(expression, 1)
        argument = expression.arguments[0]
        expected_name = "value" if expression.variant == "Ok" else "error"
        if argument.name not in {None, expected_name}:
            raise _diag(
                "CLOSED_SCHEMA_VIOLATION",
                f"Result.{expression.variant} requires the field {expected_name!r}.",
                argument.span,
                structure=f"Result.{expression.variant}",
                missing=[expected_name],
                unknown=[argument.name],
                violation="fields",
            )
        if expression.variant == "Ok":
            expected_value = expected.arguments[0] if expected is not None and expected.kind == "Result" else None
            value = self._infer(argument.value, scope, expected=expected_value, current_function=current_function)
            if expected_value is not None:
                self._require_assignable(expected_value, value.value_type, value.expression.span, "Result.Ok")
            return TypedExpression(expression, _result(value.value_type if expected_value is None else expected_value))
        failure = self._infer(
            argument.value,
            scope,
            expected=FAILURE,
            current_function=current_function,
        )
        self._require_assignable(
            FAILURE,
            failure.value_type,
            argument.value.span,
            "Result.Err",
        )
        if expected is None or expected.kind != "Result":
            raise self._type_mismatch("annotated Result[T] context", "Result.Err without T", expression.span, "Result.Err")
        return TypedExpression(expression, expected)

    def _infer_failure(self, expression: FailureConstructor, scope: Scope, current_function: str | None) -> TypedExpression:
        fields = (
            FieldSpec("code", TEXT, expression.span),
            FieldSpec("message", TEXT, expression.span),
        )
        self._bind_closed_fields(
            expression.arguments,
            fields,
            scope,
            current_function,
            "Failure",
            expression.span,
        )
        return TypedExpression(expression, FAILURE)

    def _analyze_match(
        self,
        statement: MatchStatement,
        matched_type: SemanticType,
        scope: Scope,
        *,
        current_function: str | None,
        in_function: bool,
    ) -> None:
        base, unknown = _unwrap_unknown(matched_type)
        if unknown:
            raise self._type_mismatch("known enum or Result", matched_type.render(), statement.expression.span, "match")
        if base.kind == "Result":
            variants = {
                "Ok": (FieldSpec("value", base.arguments[0], statement.span),),
                "Err": (FieldSpec("error", FAILURE, statement.span),),
            }
            expected_tags = {("Result", name) for name in variants}
            enum_name = "Result"
        elif base.kind == "Enum":
            enum = self.enums[_type_key(base)]
            variants = {variant.name: variant.fields for variant in enum.variants}
            expected_tags = {(base.render(), name) for name in variants}
            enum_name = base.render()
        else:
            raise self._type_mismatch("enum or Result", matched_type.render(), statement.expression.span, "match")

        seen: set[tuple[str, ...]] = set()
        actual: set[tuple[str, ...]] = set()
        for case in statement.cases:
            normalized = case.tag
            if base.kind == "Enum":
                if len(case.tag) < 2 or case.tag[-2] != enum_name:
                    raise self._type_mismatch(f"{enum_name}.Variant", ".".join(case.tag), case.span, "match_case")
                normalized = (enum_name, case.tag[-1])
            if normalized in seen:
                raise _diag("CLOSED_SCHEMA_VIOLATION", f"Duplicate match case {'.'.join(normalized)!r}.", case.span, structure="match", field=".".join(normalized), violation="duplicate")
            seen.add(normalized)
            if normalized not in expected_tags:
                raise _diag("CLOSED_SCHEMA_VIOLATION", f"Unknown match case {'.'.join(normalized)!r}.", case.span, structure=enum_name, field=".".join(normalized), violation="unknown")
            actual.add(normalized)
            fields = variants[normalized[-1]]
            if len(case.bindings) != len(fields):
                raise self._type_mismatch(f"{len(fields)} pattern binding(s)", str(len(case.bindings)), case.span, "match_pattern")
            case_scope = scope.child()
            for binding, field in zip(case.bindings, fields, strict=True):
                case_scope = self._define(case_scope, Symbol(binding, "pattern", field.value_type, False, False, case.span))
            for nested in case.body:
                case_scope = self._analyze_statement(nested, case_scope, current_function=current_function, in_function=in_function)
        if actual != expected_tags:
            missing = sorted(".".join(tag) for tag in expected_tags - actual)
            raise _diag("MATCH_NONEXHAUSTIVE", "match must cover every enum or Result variant.", statement.span, missing=missing)

    def _resolve_callable_path(self, path: tuple[str, ...], scope: Scope, span: SourceSpan) -> tuple[str, str]:
        first = scope.lookup(path[0])
        if first is None:
            raise _diag("NAME_UNRESOLVED", f"Callable name {'.'.join(path)!r} is not resolved.", span, name=".".join(path), context="callable")
        if len(path) == 1:
            if first.kind == "function" and first.target:
                return "function", first.target
            if first.kind == "intrinsic" and first.target:
                return "intrinsic", first.target
            if first.kind == "type" and first.target in self.records:
                return "record", first.target
            raise self._type_mismatch("callable", first.kind, span, "call_target")
        if first.kind == "namespace" and first.target:
            interface = self.interfaces[first.target]
            exported = interface.export(path[1])
            if exported is None:
                raise _diag("NAME_UNRESOLVED", f"Namespace {path[0]!r} does not export {path[1]!r}.", span, name=path[1], context="namespace", module=first.target)
            if len(path) == 2:
                if exported.kind == "function" and exported.target:
                    return "function", exported.target
                if exported.kind == "intrinsic" and exported.target:
                    return "intrinsic", exported.target
                if exported.kind == "type" and exported.target in self.records:
                    return "record", exported.target
            if len(path) == 3 and exported.kind == "type" and exported.target in self.enums:
                self._enum_variant(self.enums[exported.target], path[2], span)
                return "enum_variant", f"{exported.target}#{path[2]}"
            raise self._type_mismatch("callable export", ".".join(path), span, "call_target")
        if first.kind == "type" and first.target in self.enums and len(path) == 2:
            self._enum_variant(self.enums[first.target], path[1], span)
            return "enum_variant", f"{first.target}#{path[1]}"
        raise self._type_mismatch("callable", ".".join(path), span, "call_target")

    def _resolve_symbolic_value_path(self, path: tuple[str, ...], scope: Scope, span: SourceSpan) -> SemanticType | None:
        first = scope.lookup(path[0])
        if first is None:
            return None
        if first.kind == "namespace" and first.target and len(path) == 2:
            exported = self.interfaces[first.target].export(path[1])
            if exported is None:
                raise _diag("NAME_UNRESOLVED", f"Namespace {path[0]!r} does not export {path[1]!r}.", span, name=path[1], context="namespace", module=first.target)
            if exported.value_type is None or exported.kind in {"function", "intrinsic", "type"}:
                raise self._type_mismatch("value export", exported.kind, span, "namespace_value")
            self.references.append(ReferenceFact(span, ".".join(path), exported.kind, exported.target or exported.name))
            return exported.value_type
        if first.kind == "namespace" and first.target and len(path) == 3:
            exported = self.interfaces[first.target].export(path[1])
            if exported is None:
                raise _diag(
                    "NAME_UNRESOLVED",
                    f"Namespace {path[0]!r} does not export {path[1]!r}.",
                    span,
                    name=path[1],
                    context="namespace",
                    module=first.target,
                )
            if exported.kind == "type" and exported.target in self.enums:
                variant = self._enum_variant(self.enums[exported.target], path[2], span)
                if not variant.fields:
                    self.references.append(
                        ReferenceFact(
                            span,
                            ".".join(path),
                            "enum_variant",
                            f"{exported.target}#{path[2]}",
                        )
                    )
                    return self.enums[exported.target].value_type
        if first.kind == "type" and first.target in self.enums and len(path) == 2:
            variant = self._enum_variant(self.enums[first.target], path[1], span)
            if variant.fields:
                return None
            self.references.append(ReferenceFact(span, ".".join(path), "enum_variant", f"{first.target}#{path[1]}"))
            return self.enums[first.target].value_type
        return None

    def _resolve_symbol_path(self, path: tuple[str, ...], scope: Scope, span: SourceSpan, context: str) -> Symbol:
        first = scope.lookup(path[0])
        if first is None:
            raise _diag("NAME_UNRESOLVED", f"Name {'.'.join(path)!r} is not resolved.", span, name=".".join(path), context=context)
        if len(path) == 1:
            return first
        if first.kind == "namespace" and first.target and len(path) == 2:
            exported = self.interfaces[first.target].export(path[1])
            if exported is None:
                raise _diag("NAME_UNRESOLVED", f"Namespace {path[0]!r} does not export {path[1]!r}.", span, name=path[1], context=context, module=first.target)
            return exported
        raise _diag("NAME_UNRESOLVED", f"Qualified name {'.'.join(path)!r} is not resolved.", span, name=".".join(path), context=context)

    def _resolve_value(self, name: str, scope: Scope, span: SourceSpan) -> Symbol:
        symbol = scope.lookup(name)
        if symbol is None:
            raise _diag("NAME_UNRESOLVED", f"Value name {name!r} is not resolved.", span, name=name, context="value")
        if symbol.value_type is None or symbol.kind in {"function", "intrinsic", "namespace", "type"}:
            raise self._type_mismatch("value", symbol.kind, span, "value_reference")
        self.references.append(ReferenceFact(span, name, symbol.kind, symbol.target or symbol.name))
        return symbol

    def _define(self, scope: Scope, symbol: Symbol) -> Scope:
        local = scope.lookup_local(symbol.name)
        if local is not None:
            raise self._duplicate(symbol.name, symbol.span, local.span)
        visible = None if scope.parent is None else scope.parent.lookup(symbol.name)
        if visible is not None:
            raise _diag(
                "NAME_SHADOWING",
                f"Name {symbol.name!r} shadows a visible declaration.",
                symbol.span,
                name=symbol.name,
                original_span=visible.span.to_dict(),
            )
        return scope.add(symbol)

    def _duplicate(self, name: str, span: SourceSpan, original: SourceSpan) -> BangelDiagnostic:
        return _diag(
            "NAME_DUPLICATE",
            f"Name {name!r} is duplicated in the same scope.",
            span,
            name=name,
            original_span=original.to_dict(),
        )

    def _require_assignable(self, expected: SemanticType, actual: SemanticType, span: SourceSpan, context: str) -> None:
        expected_base, _ = _unwrap_unknown(expected)
        actual_base, _ = _unwrap_unknown(actual)
        if expected_base.kind == "Measurement" and actual_base.kind == "Measurement":
            expected_base = expected_base.arguments[0]
            actual_base = actual_base.arguments[0]
        if (
            expected_base.kind in PHYSICAL_KINDS
            and actual_base.kind == expected_base.kind
            and expected_base.unit is not None
            and actual_base.unit is not None
            and expected_base.unit.dimension != actual_base.unit.dimension
        ):
            raise self._dimension_mismatch(expected_base, actual_base, span, context)
        if not self._is_assignable(expected, actual):
            raise self._type_mismatch(expected.render(), actual.render(), span, context)
        self._record_physical_conversion(actual, expected, span, context)

    def _is_assignable(self, expected: SemanticType, actual: SemanticType) -> bool:
        if expected == actual:
            return True
        if actual.kind == "Unknown":
            return self._is_assignable(expected, actual.arguments[0]) or (
                expected.kind == "Unknown" and self._is_assignable(expected.arguments[0], actual.arguments[0])
            )
        if expected.kind == "Unknown":
            return False
        if expected == REAL and actual == INT:
            return True
        if expected.kind in PHYSICAL_KINDS and actual.kind == expected.kind:
            assert expected.unit is not None and actual.unit is not None
            return expected.unit.dimension == actual.unit.dimension
        if expected.kind == "Measurement" and actual.kind == "Measurement":
            return self._is_assignable(expected.arguments[0], actual.arguments[0])
        if expected.kind == "Vector" and actual.kind == "Vector":
            size_ok = expected.size is None or expected.size == actual.size
            return size_ok and self._is_assignable(expected.arguments[0], actual.arguments[0])
        if expected.kind in {"Map", "Result"} and actual.kind == expected.kind:
            return self._is_assignable(expected.arguments[0], actual.arguments[0])
        return False

    def _record_physical_conversion(self, actual: SemanticType, expected: SemanticType, span: SourceSpan, context: str) -> None:
        actual_base, _ = _unwrap_unknown(actual)
        expected_base, _ = _unwrap_unknown(expected)
        if actual_base.kind == "Measurement" and expected_base.kind == "Measurement":
            actual_base = actual_base.arguments[0]
            expected_base = expected_base.arguments[0]
        if (
            actual_base.kind in PHYSICAL_KINDS
            and expected_base.kind == actual_base.kind
            and actual_base.unit is not None
            and expected_base.unit is not None
            and actual_base.unit.dimension == expected_base.unit.dimension
            and (
                actual_base.unit.text != expected_base.unit.text
                or actual_base.unit.scale != expected_base.unit.scale
            )
        ):
            self.conversions.append(
                ConversionFact(span, actual_base.unit.text, expected_base.unit.text, context)
            )

    def _require_boolean(self, value_type: SemanticType, span: SourceSpan, context: str) -> None:
        base, _ = _unwrap_unknown(value_type)
        if base != BOOL:
            raise self._type_mismatch("Bool", value_type.render(), span, context)

    def _require_exact_type(self, expected: SemanticType, actual: SemanticType, span: SourceSpan, context: str) -> None:
        if actual.kind == "Unknown" or not self._is_assignable(expected, actual):
            raise self._type_mismatch(expected.render(), actual.render(), span, context)

    def _type_mismatch(self, expected: str, actual: str, span: SourceSpan, context: str) -> BangelDiagnostic:
        return _diag(
            "TYPE_MISMATCH",
            f"Expected {expected}; received {actual}.",
            span,
            expected=expected,
            actual=actual,
            context=context,
        )

    def _dimension_mismatch(self, left: SemanticType, right: SemanticType, span: SourceSpan, operator: str) -> BangelDiagnostic:
        assert left.unit is not None and right.unit is not None
        return _diag(
            "DIMENSION_MISMATCH",
            f"{left.render()} and {right.render()} have incompatible dimensions.",
            span,
            left=list(left.unit.dimension),
            right=list(right.unit.dimension),
            operator=operator,
        )

    def _mass_delta_unsupported(self, operator: str, left: SemanticType, right: SemanticType, span: SourceSpan) -> BangelDiagnostic:
        return _diag(
            "MASS_DELTA_OPERATION_UNSUPPORTED",
            "MassDelta is used outside the frozen operator matrix.",
            span,
            operator=operator,
            left=left.render(),
            right=right.render(),
        )

    def _effect_in_function(self, span: SourceSpan, statement: str) -> BangelDiagnostic:
        return _diag(
            "EFFECT_MISMATCH",
            f"Pure Bangel functions cannot contain {statement}.",
            span,
            declared=["pure"],
            inferred=["pure", "evidence"] if statement in {"measure", "evidence"} else [statement],
            context="function_body",
        )

    def _knownness_refinement(self, expression: ExpressionSyntax, scope: Scope) -> tuple[str, SemanticType] | None:
        if not isinstance(expression, CallExpression) or _path(expression.callee) != ("is_known",) or len(expression.arguments) != 1:
            return None
        argument = expression.arguments[0].value
        if not isinstance(argument, NameExpression):
            return None
        symbol = scope.lookup(argument.name)
        if symbol is None or symbol.value_type is None or symbol.value_type.kind != "Unknown":
            return None
        return argument.name, symbol.value_type.arguments[0]

    def _scalar_constant(self, operator: str, left: object, right: object, result_type: SemanticType, span: SourceSpan) -> object:
        if not isinstance(left, (int, Decimal)) or not isinstance(right, (int, Decimal)):
            return _NO_CONSTANT
        if operator == "/" and right == 0:
            raise _diag("DIVISION_ZERO", "Division by zero is not admitted.", span, context="scalar")
        try:
            if result_type == INT:
                value = left + right if operator == "+" else left - right if operator == "-" else left * right
                assert isinstance(value, int)
                self._check_int(value, span)
                return value
            with localcontext(DECIMAL128):
                lhs, rhs = Decimal(left), Decimal(right)
                value = lhs + rhs if operator == "+" else lhs - rhs if operator == "-" else lhs * rhs if operator == "*" else lhs / rhs
                value = +value
            if not value.is_finite():
                raise DecimalException
            return value
        except (DecimalException, OverflowError) as exc:
            raise _diag("DECIMAL_NONFINITE", "Real operation is outside finite decimal128.", span, operation=operator) from exc

    def _quantity_scalar_constant(self, operator: str, left: TypedExpression, right: TypedExpression, span: SourceSpan, signed_delta: bool = False) -> object:
        if isinstance(left.constant, _QuantityConstant) and isinstance(right.constant, (int, Decimal)):
            if operator == "/" and right.constant == 0:
                raise _diag("DIVISION_ZERO", "Division by zero is not admitted.", span, context="physical_scalar")
            magnitude = self._physical_decimal(
                operator,
                left.constant.magnitude_si,
                Decimal(right.constant),
                span,
            )
            if left.constant.dimension == MASS and not signed_delta and magnitude < 0:
                raise _diag("NEGATIVE_MASS", "Mass scaling constructs a negative absolute mass.", span, operation=operator, value_si=_decimal_text(magnitude))
            return _QuantityConstant(magnitude, left.constant.dimension, signed_delta)
        if isinstance(left.constant, (int, Decimal)) and isinstance(right.constant, _QuantityConstant):
            if operator == "/" and right.constant.magnitude_si == 0:
                raise _diag("DIVISION_ZERO", "Division by zero is not admitted.", span, context="scalar_physical")
            magnitude = self._physical_decimal(
                operator,
                Decimal(left.constant),
                right.constant.magnitude_si,
                span,
            )
            dimension = right.constant.dimension if operator == "*" else tuple(-value for value in right.constant.dimension)
            if dimension == MASS and not signed_delta and magnitude < 0:
                raise _diag("NEGATIVE_MASS", "Mass scaling constructs a negative absolute mass.", span, operation=operator, value_si=_decimal_text(magnitude))
            return _QuantityConstant(magnitude, dimension, signed_delta)
        return _NO_CONSTANT

    def _physical_decimal(
        self,
        operator: str,
        left: Decimal,
        right: Decimal,
        span: SourceSpan,
    ) -> Decimal:
        try:
            with localcontext(DECIMAL128):
                value = (
                    left + right
                    if operator == "+"
                    else left - right
                    if operator == "-"
                    else left * right
                    if operator == "*"
                    else left / right
                )
                value = +value
            if not value.is_finite():
                raise DecimalException
            return value
        except (DecimalException, OverflowError) as exc:
            raise _diag(
                "DECIMAL_NONFINITE",
                "Physical constant operation is outside finite decimal128.",
                span,
                operation=operator,
            ) from exc

    def _decimal128(self, value: str, span: SourceSpan) -> Decimal:
        try:
            with localcontext(DECIMAL128):
                result = +Decimal(value)
            if not result.is_finite():
                raise DecimalException
            return result
        except (DecimalException, ValueError) as exc:
            raise _diag("DECIMAL_NONFINITE", "Real literal is outside finite decimal128.", span, value=value) from exc

    def _check_int(self, value: int, span: SourceSpan) -> None:
        if value < INT64_MIN or value > INT64_MAX:
            raise _diag("INTEGER_OVERFLOW", "Int literal or constant operation exceeds Int64.", span, value=str(value))

    def _bind_closed_fields(
        self,
        arguments: tuple[Argument, ...],
        fields: tuple[FieldSpec, ...],
        scope: Scope,
        current_function: str | None,
        structure: str,
        fallback_span: SourceSpan,
    ) -> None:
        if any(argument.name is None for argument in arguments):
            raise _diag("CLOSED_SCHEMA_VIOLATION", f"{structure} construction requires named fields.", arguments[0].span if arguments else fallback_span, structure=structure, violation="unnamed")
        expected = {field.name: field for field in fields}
        seen: set[str] = set()
        for argument in arguments:
            assert argument.name is not None
            if argument.name in seen:
                raise _diag("CLOSED_SCHEMA_VIOLATION", f"Duplicate {structure} field {argument.name!r}.", argument.span, structure=structure, field=argument.name, violation="duplicate")
            seen.add(argument.name)
            field = expected.get(argument.name)
            if field is None:
                raise _diag("CLOSED_SCHEMA_VIOLATION", f"Unknown {structure} field {argument.name!r}.", argument.span, structure=structure, field=argument.name, violation="unknown")
            value = self._infer(argument.value, scope, expected=field.value_type, current_function=current_function)
            self._require_assignable(field.value_type, value.value_type, argument.value.span, f"{structure}.{field.name}")
        missing = sorted(set(expected) - seen)
        if missing:
            raise _diag("CLOSED_SCHEMA_VIOLATION", f"{structure} construction is missing required fields.", arguments[-1].span if arguments else fallback_span, structure=structure, missing=missing, violation="missing")

    def _bind_arguments(
        self,
        arguments: tuple[Argument, ...],
        parameters: tuple[ParameterSpec, ...],
        scope: Scope,
        current_function: str | None,
        *,
        context: str,
        fallback_span: SourceSpan,
    ) -> tuple[TypedExpression, ...]:
        if len(arguments) != len(parameters):
            raise self._type_mismatch(f"{len(parameters)} argument(s)", str(len(arguments)), arguments[0].span if arguments else fallback_span, context)
        named = [argument.name is not None for argument in arguments]
        if any(named) and not all(named):
            raise self._type_mismatch("all positional or all named arguments", "mixed arguments", arguments[0].span, context)
        ordered: list[tuple[Argument, ParameterSpec]] = []
        if all(named) and arguments:
            by_name: dict[str, Argument] = {}
            for argument in arguments:
                assert argument.name is not None
                if argument.name in by_name:
                    raise _diag("CLOSED_SCHEMA_VIOLATION", f"Duplicate argument {argument.name!r}.", argument.span, structure=context, field=argument.name, violation="duplicate")
                by_name[argument.name] = argument
            expected_names = {parameter.name for parameter in parameters}
            if set(by_name) != expected_names:
                raise _diag("CLOSED_SCHEMA_VIOLATION", "Named arguments do not match the callable signature.", arguments[0].span, structure=context, missing=sorted(expected_names - set(by_name)), unknown=sorted(set(by_name) - expected_names), violation="fields")
            ordered = [(by_name[parameter.name], parameter) for parameter in parameters]
        else:
            ordered = list(zip(arguments, parameters, strict=True))
        values: list[TypedExpression] = []
        for argument, parameter in ordered:
            value = self._infer(argument.value, scope, expected=parameter.value_type, current_function=current_function)
            self._require_assignable(parameter.value_type, value.value_type, argument.value.span, context)
            values.append(value)
        return tuple(values)

    def _require_argument_count(self, expression, count: int) -> None:
        self._count(list(expression.arguments), count, expression.span)

    def _count(self, arguments: list[object], count: int, span: SourceSpan) -> None:
        if len(arguments) != count:
            raise self._type_mismatch(f"{count} argument(s)", str(len(arguments)), span, "argument_count")

    def _require_container(self, argument: TypedExpression, kind: str, span: SourceSpan, context: str) -> SemanticType:
        base, unknown = _unwrap_unknown(argument.value_type)
        if unknown or base.kind != kind:
            raise self._type_mismatch(f"known {kind}", argument.value_type.render(), span, context)
        return base

    def _enum_variant(self, spec: EnumSpec, name: str, span: SourceSpan) -> VariantSpec:
        variant = next((item for item in spec.variants if item.name == name), None)
        if variant is None:
            raise _diag("CLOSED_SCHEMA_VIOLATION", f"Enum {spec.value_type.render()} has no variant {name!r}.", span, structure=spec.value_type.render(), field=name, violation="unknown")
        return variant

    def _validate_call_graph(self) -> tuple[int, dict[str, int]]:
        visiting: list[str] = []
        depths: dict[str, int] = {}

        def depth(key: str) -> int:
            if key in visiting:
                start = visiting.index(key)
                cycle = (*visiting[start:], key)
                raise _diag("RECURSION_UNSUPPORTED", "Recursive function calls are outside Bangel 1.0.", self.functions[key].span, cycle=list(cycle))
            if key in depths:
                return depths[key]
            visiting.append(key)
            value = 1
            for called in sorted(self.call_edges.get(key, ())):
                called_depth = (
                    depth(called)
                    if called in self.call_edges
                    else self.functions[called].call_depth
                )
                value = max(value, 1 + called_depth)
            visiting.pop()
            if value > MAX_CALL_DEPTH:
                raise _diag("RECURSION_UNSUPPORTED", "Function call chain exceeds the Bangel 1.0 depth ceiling.", self.functions[key].span, call_depth=value, limit=MAX_CALL_DEPTH)
            depths[key] = value
            return value

        maximum = max((depth(key) for key in sorted(self.call_edges)), default=0)
        return maximum, depths

    def _module_interface(self, scope: Scope) -> ModuleInterface:
        assert isinstance(self.source, ModuleSource)
        exports = tuple(symbol for symbol in scope.symbols if symbol.exported)
        targets = {symbol.target for symbol in exports if symbol.target}
        return ModuleInterface(
            self.source.name,
            exports,
            tuple(spec for key, spec in sorted(self.records.items()) if key in targets),
            tuple(spec for key, spec in sorted(self.enums.items()) if key in targets),
            tuple(spec for key, spec in sorted(self.functions.items()) if key in targets),
        )


def _type_key(value_type: SemanticType) -> str:
    return ".".join(value_type.name)


def _type_dependencies(value_type: SemanticType) -> set[str]:
    dependencies: set[str] = set()
    if value_type.kind in {"Record", "Enum"}:
        dependencies.add(_type_key(value_type))
    for argument in value_type.arguments:
        dependencies.update(_type_dependencies(argument))
    return dependencies


def _standard_interface(name: tuple[str, ...]) -> ModuleInterface | None:
    allocations = {
        ("std", "math"): ("abs", "min", "max", "sqrt"),
        ("std", "vector"): ("length", "at", "sum", "mean", "dot", "norm", "moving_mean", "slope"),
        ("std", "map"): ("length", "at", "keys", "values"),
        ("std", "topology"): ("node_variance", "dampen", "step_cap", "bound", "shadow_speed", "floor_challenge"),
    }
    names = allocations.get(name)
    if names is None:
        return None
    module_key = ".".join(name)
    exports = tuple(
        Symbol(
            item,
            "intrinsic",
            None,
            False,
            True,
            SourceSpan(0, 0, 0),
            f"{module_key}.{item}",
        )
        for item in names
    )
    return ModuleInterface(name, exports)


def analyze_source(
    source: SourceFile,
    *,
    module_catalog: Mapping[tuple[str, ...], ModuleInterface] | None = None,
) -> SemanticModel:
    """Resolve and type-check one frozen Bangel/1.0 syntax tree."""

    return Analyzer(source, module_catalog).analyze()


def analyze_project(sources: Iterable[SourceFile]) -> ProjectSemanticModel:
    """Resolve a closed, offline collection of Bangel modules and programs."""

    material = tuple(sources)
    modules: dict[tuple[str, ...], ModuleSource] = {}
    programs: list[ProgramSource] = []
    for source in material:
        if isinstance(source, ModuleSource):
            if source.name in modules:
                original = modules[source.name]
                raise _diag(
                    "NAME_DUPLICATE",
                    f"Project contains duplicate module {'.'.join(source.name)!r}.",
                    source.span,
                    name=".".join(source.name),
                    original_span=original.span.to_dict(),
                )
            modules[source.name] = source
        else:
            programs.append(source)

    dependencies: dict[tuple[str, ...], set[tuple[str, ...]]] = {}
    for name, source in modules.items():
        dependencies[name] = set()
        for declaration in source.imports:
            if _standard_interface(declaration.module) is not None:
                continue
            if declaration.module not in modules:
                raise _diag(
                    "NAME_UNRESOLVED",
                    f"Project module {'.'.join(declaration.module)!r} is not present.",
                    declaration.span,
                    name=".".join(declaration.module),
                    context="project_module",
                )
            dependencies[name].add(declaration.module)

    ordered: list[tuple[str, ...]] = []
    visiting: list[tuple[str, ...]] = []
    visited: set[tuple[str, ...]] = set()

    def visit(name: tuple[str, ...]) -> None:
        if name in visiting:
            start = visiting.index(name)
            cycle = (*visiting[start:], name)
            raise _diag(
                "MODULE_CYCLE",
                "Module imports form a cycle.",
                modules[name].span,
                cycle=[".".join(item) for item in cycle],
            )
        if name in visited:
            return
        visiting.append(name)
        for dependency in sorted(dependencies[name]):
            visit(dependency)
        visiting.pop()
        visited.add(name)
        ordered.append(name)

    for name in sorted(modules):
        visit(name)

    catalog: dict[tuple[str, ...], ModuleInterface] = {}
    module_models: list[SemanticModel] = []
    for name in ordered:
        model = analyze_source(modules[name], module_catalog=catalog)
        assert model.interface is not None
        catalog[name] = model.interface
        module_models.append(model)

    program_models = [analyze_source(program, module_catalog=catalog) for program in programs]
    return ProjectSemanticModel(tuple(module_models), tuple(program_models))
