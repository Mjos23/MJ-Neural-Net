from __future__ import annotations

from dataclasses import dataclass, replace

from ..ast import Expression, Program, Statement
from ..diagnostics import BangelDiagnostic
from ..identity import COMPILER_PROTOCOL, LANGUAGE_IDENTITY
from .ast import (
    Argument,
    BinaryExpression,
    BooleanLiteral,
    CallExpression,
    DeriveStatement,
    EmitStatement,
    EnumDeclaration,
    EvidenceStatement,
    FailureConstructor,
    FieldExpression,
    ForStatement,
    FunctionDeclaration,
    IfStatement,
    IndexExpression,
    IntegerLiteral,
    LetStatement,
    MapLiteral,
    MapEntry,
    MassDeltaExpression,
    MatchStatement,
    MeasureStatement,
    ModuleSource,
    NameExpression,
    ProgramSource,
    QuantityLiteral,
    QuantityType,
    RealLiteral,
    RecordDeclaration,
    RequireStatement,
    ResultConstructor,
    SetStatement,
    TextLiteral,
    UnaryExpression,
    UnknownExpression,
    VarStatement,
    VectorLiteral,
)
from .semantics import (
    ConversionFact,
    EnumSpec,
    FunctionSpec,
    RecordSpec,
    ReferenceFact,
    SemanticModel,
    SemanticType,
)


# B02.1 freezes one explicit lowering destination for every concrete A1 AST
# dataclass.  The mapping is deliberately keyed by the stable serialized AST
# class name so documentation and conformance tooling can compare it without
# importing implementation objects.
AST_TO_JPIR_KIND: dict[str, str] = {
    "Argument": "operand.argument",
    "BinaryExpression": "expression.binary",
    "BooleanLiteral": "value.bool",
    "CallExpression": "expression.call",
    "CaseArm": "control.case",
    "DeriveStatement": "instruction.derive",
    "EmitStatement": "instruction.emit",
    "EnumDeclaration": "definition.enum",
    "EvidenceStatement": "instruction.evidence",
    "FailureConstructor": "value.failure",
    "FailureType": "type.failure",
    "FieldDeclaration": "definition.field",
    "FieldExpression": "expression.field",
    "ForStatement": "instruction.for",
    "FunctionDeclaration": "instruction.function",
    "IfStatement": "instruction.if",
    "ImportDeclaration": "module.import",
    "IndexExpression": "expression.index",
    "IntegerLiteral": "value.int",
    "LetStatement": "instruction.let",
    "MapEntry": "value.map_entry",
    "MapLiteral": "value.map",
    "MapType": "type.map",
    "MassDeltaExpression": "value.mass_delta",
    "MassDeltaType": "type.mass_delta",
    "MatchStatement": "instruction.match",
    "MeasurementType": "type.measurement",
    "MeasureStatement": "instruction.measure",
    "ModuleSource": "module.definition",
    "NameExpression": "value.reference",
    "NamedType": "type.nominal",
    "Parameter": "definition.parameter",
    "ProgramSource": "program.definition",
    "QuantityLiteral": "value.quantity",
    "QuantityType": "type.quantity",
    "RealLiteral": "value.real",
    "RecordDeclaration": "definition.record",
    "RequireStatement": "instruction.require",
    "ResultConstructor": "value.result",
    "ResultType": "type.result",
    "ScalarType": "type.scalar",
    "SetStatement": "instruction.set",
    "TextLiteral": "value.text",
    "UnaryExpression": "expression.unary",
    "UnitExpression": "type.unit_expression",
    "UnitTerm": "type.unit_term",
    "UnknownExpression": "value.unknown",
    "UnknownType": "type.unknown",
    "VarStatement": "instruction.var",
    "VariantDeclaration": "definition.variant",
    "VectorLiteral": "value.vector",
    "VectorType": "type.vector",
}


def typed_ast_mapping() -> dict[str, str]:
    """Return a detached, deterministic copy of the frozen B02.1 mapping."""

    return dict(sorted(AST_TO_JPIR_KIND.items()))


def _span_key(span) -> tuple[int, int, int | None]:
    return (span.line, span.column, span.end_column)


def _semantic_key(owner: tuple[str, ...], name: str) -> str:
    return ".".join((*owner, name))


@dataclass(frozen=True, slots=True)
class LoweringContext:
    expression_types: dict[int, SemanticType]
    references: dict[tuple[int, int, int | None], ReferenceFact]
    conversions: dict[tuple[int, int, int | None], tuple[ConversionFact, ...]]
    source_name: str | None
    binding_types: dict[str, SemanticType]
    functions: dict[str, FunctionSpec]
    records: dict[str, RecordSpec]
    enums: dict[str, EnumSpec]
    call_depths: dict[str, int]
    maximum_call_depth: int
    declared_effects: tuple[str, ...]
    inferred_effects: tuple[str, ...]

    @classmethod
    def from_model(cls, model: SemanticModel) -> "LoweringContext":
        conversions: dict[
            tuple[int, int, int | None], list[ConversionFact]
        ] = {}
        for item in model.conversions:
            conversions.setdefault(_span_key(item.span), []).append(item)
        return cls(
            {id(item.expression): item.value_type for item in model.expressions},
            {_span_key(item.span): item for item in model.references},
            {key: tuple(value) for key, value in conversions.items()},
            model.source_name,
            {
                item.name: item.value_type
                for item in model.symbols
                if item.value_type is not None
            },
            {item.key: item for item in model.functions},
            {item.key: item for item in model.records},
            {item.key: item for item in model.enums},
            dict(model.call_depths),
            model.maximum_call_depth,
            model.source.effects,
            model.inferred_effects,
        )

    def type_of(self, node: object) -> dict[str, object] | None:
        value_type = self.expression_types.get(id(node))
        return None if value_type is None else value_type.to_dict()

    def reference_for(self, node: object) -> ReferenceFact | None:
        span = getattr(node, "span", None)
        return None if span is None else self.references.get(_span_key(span))

    def binding_type(self, name: str, fallback: dict[str, object] | None) -> dict[str, object] | None:
        value_type = self.binding_types.get(name)
        return fallback if value_type is None else value_type.to_dict()

    def function(self, key: str) -> FunctionSpec:
        return self.functions[key]

    def provenance(self, node: object) -> dict[str, object]:
        span = getattr(node, "span", None)
        result: dict[str, object] = {
            "language": LANGUAGE_IDENTITY,
            "compiler": COMPILER_PROTOCOL,
            "source": self.source_name,
            "span": None if span is None else span.to_dict(),
        }
        if span is not None:
            key = _span_key(span)
            reference = self.references.get(key)
            if reference is not None:
                result["reference"] = reference.to_dict()
            conversion_facts = self.conversions.get(key, ())
            if conversion_facts:
                result["conversions"] = [
                    item.to_dict() for item in conversion_facts
                ]
        return result


def _ordered_arguments(
    arguments: tuple[Argument, ...], names: tuple[str, ...]
) -> tuple[Argument, ...]:
    if not arguments or all(item.name is None for item in arguments):
        return arguments
    by_name = {item.name: item for item in arguments}
    return tuple(by_name[name] for name in names)


def _expression(
    kind: str,
    node: object,
    context: LoweringContext | None,
    value=None,
    operands: tuple[Expression, ...] = (),
) -> Expression:
    return Expression(
        kind,
        value,
        operands,
        getattr(node, "span", None),
        None if context is None else context.type_of(node),
        () if context is None else ("pure",),
        None if context is None else context.provenance(node),
    )


def _path(node: object) -> tuple[str, ...] | None:
    if isinstance(node, NameExpression):
        return (node.name,)
    if isinstance(node, FieldExpression):
        base = _path(node.target)
        return None if base is None else (*base, node.field)
    return None


def _lower_argument(
    node: Argument, context: LoweringContext | None
) -> Expression:
    value = lower_expression(node.value, context)
    return Expression(
        "argument",
        {"name": node.name},
        (value,),
        node.span,
        value.result_type,
        () if context is None else ("pure",),
        None if context is None else context.provenance(node),
    )


def _lower_map_entry(
    node: MapEntry, context: LoweringContext | None
) -> Expression:
    value = lower_expression(node.value, context)
    return Expression(
        "map_entry",
        {"key": node.key.value},
        (value,),
        node.span,
        value.result_type,
        () if context is None else ("pure",),
        None if context is None else context.provenance(node),
    )


def _pending(node: object, feature: str) -> BangelDiagnostic:
    return BangelDiagnostic(
        "FRONTEND_LOWERING_PENDING",
        f"{feature} parses into the frozen typed AST but is not lowered to JP-IR yet.",
        getattr(node, "span", None),
    )


def lower_expression(
    node, context: LoweringContext | None = None
) -> Expression:
    if isinstance(node, (IntegerLiteral, RealLiteral)):
        magnitude = str(node.value)
        return _expression(
            "quantity", node, context, {"magnitude": magnitude, "unit": "1"}
        )
    if isinstance(node, QuantityLiteral):
        return _expression(
            "quantity",
            node,
            context,
            {
                "magnitude": str(node.magnitude.value),
                "unit": node.unit.text(),
            },
        )
    if isinstance(node, (BooleanLiteral, TextLiteral)):
        return _expression("literal", node, context, node.value)
    if isinstance(node, NameExpression):
        return _expression("name", node, context, node.name)
    if isinstance(node, VectorLiteral):
        return _expression(
            "vector",
            node,
            context,
            operands=tuple(lower_expression(item, context) for item in node.items),
        )
    if isinstance(node, UnaryExpression):
        operand = lower_expression(node.operand, context)
        result_type = None if context is None else context.type_of(node)
        if operand.result_type is None and result_type is not None:
            provenance = dict(operand.provenance or {})
            provenance["role"] = "signed_literal_magnitude"
            operand = replace(
                operand,
                result_type=result_type,
                provenance=provenance,
            )
        return _expression(
            "unary",
            node,
            context,
            node.operator,
            (operand,),
        )
    if isinstance(node, BinaryExpression):
        return _expression(
            "binary",
            node,
            context,
            node.operator,
            (lower_expression(node.left, context), lower_expression(node.right, context)),
        )
    if isinstance(node, CallExpression):
        path = _path(node.callee)
        if path is None:
            raise _pending(node, "Non-symbolic call target")
        reference = None if context is None else context.reference_for(node.callee)
        target = reference.target if reference is not None else ".".join(path)
        if reference is not None and reference.symbol_kind == "record" and context is not None:
            spec = context.records[target]
            ordered = _ordered_arguments(
                node.arguments, tuple(field.name for field in spec.fields)
            )
            return _expression(
                "record",
                node,
                context,
                {"identity": target, "name": spec.value_type.render()},
                tuple(_lower_argument(argument, context) for argument in ordered),
            )
        if reference is not None and reference.symbol_kind == "enum_variant" and context is not None:
            enum_key, variant_name = target.rsplit("#", 1)
            spec = context.enums[enum_key]
            variant = next(item for item in spec.variants if item.name == variant_name)
            ordered = _ordered_arguments(
                node.arguments, tuple(field.name for field in variant.fields)
            )
            return _expression(
                "enum",
                node,
                context,
                {
                    "identity": enum_key,
                    "name": spec.value_type.render(),
                    "variant": variant_name,
                },
                tuple(_lower_argument(argument, context) for argument in ordered),
            )
        return _expression(
            "call",
            node,
            context,
            {
                "target": target,
                "source": ".".join(path),
                "symbol_kind": None if reference is None else reference.symbol_kind,
            },
            tuple(_lower_argument(argument, context) for argument in node.arguments),
        )
    if isinstance(node, MassDeltaExpression):
        return _expression(
            "mass_delta",
            node,
            context,
            {"unit": node.unit.text()},
            (lower_expression(node.magnitude, context),),
        )
    if isinstance(node, UnknownExpression):
        return _expression(
            "unknown",
            node,
            context,
            {"reason": None if node.reason is None else node.reason.value},
        )
    if isinstance(node, MapLiteral):
        ordered = sorted(node.entries, key=lambda item: item.key.value)
        return _expression(
            "map",
            node,
            context,
            operands=tuple(_lower_map_entry(item, context) for item in ordered),
        )
    if isinstance(node, IndexExpression):
        return _expression(
            "index",
            node,
            context,
            operands=(
                lower_expression(node.target, context),
                lower_expression(node.index, context),
            ),
        )
    if isinstance(node, FieldExpression):
        reference = None if context is None else context.reference_for(node)
        if reference is not None:
            if reference.symbol_kind == "enum_variant":
                enum_key, variant_name = reference.target.rsplit("#", 1)
                spec = context.enums[enum_key]
                return _expression(
                    "enum",
                    node,
                    context,
                    {
                        "identity": enum_key,
                        "name": spec.value_type.render(),
                        "variant": variant_name,
                    },
                )
            return _expression(
                "reference",
                node,
                context,
                {
                    "source": reference.source_name,
                    "symbol_kind": reference.symbol_kind,
                    "target": reference.target,
                },
            )
        return _expression(
            "field",
            node,
            context,
            node.field,
            (lower_expression(node.target, context),),
        )
    if isinstance(node, ResultConstructor):
        return _expression(
            "result",
            node,
            context,
            {"variant": node.variant},
            tuple(_lower_argument(item, context) for item in node.arguments),
        )
    if isinstance(node, FailureConstructor):
        field_order = {"code": 0, "message": 1, None: 2}
        ordered = sorted(
            enumerate(node.arguments),
            key=lambda item: (field_order.get(item[1].name, 3), item[0]),
        )
        return _expression(
            "failure",
            node,
            context,
            operands=tuple(_lower_argument(item, context) for _, item in ordered),
        )
    raise _pending(node, type(node).__name__)


def _lower_statement_raw(node, context: LoweringContext | None = None) -> Statement:
    if isinstance(node, LetStatement):
        expression = lower_expression(node.expression, context)
        result_type = expression.result_type if context is None else context.binding_type(node.name, expression.result_type)
        return Statement("let", node.name, expression, span=node.span, result_type=result_type)
    if isinstance(node, DeriveStatement):
        expression = lower_expression(node.expression, context)
        result_type = expression.result_type if context is None else context.binding_type(node.name, expression.result_type)
        return Statement("derive", node.name, expression, span=node.span, result_type=result_type)
    if isinstance(node, VarStatement):
        expression = lower_expression(node.expression, context)
        result_type = expression.result_type if context is None else context.binding_type(node.name, expression.result_type)
        return Statement("var", node.name, expression, span=node.span, result_type=result_type)
    if isinstance(node, SetStatement):
        expression = lower_expression(node.expression, context)
        return Statement("set", node.name, expression, span=node.span, result_type=expression.result_type)
    if isinstance(node, MeasureStatement):
        nominal = lower_expression(node.nominal, context)
        return Statement(
            "measure",
            node.name,
            nominal,
            {"uncertainty": lower_expression(node.uncertainty, context).to_ir()},
            node.span,
            nominal.result_type if context is None else context.binding_type(node.name, nominal.result_type),
        )
    if isinstance(node, EvidenceStatement):
        expression = lower_expression(node.expression, context)
        return Statement(
            "evidence",
            node.name,
            expression,
            {"class": node.evidence_class.upper()},
            node.span,
            expression.result_type if context is None else context.binding_type(node.name, expression.result_type),
        )
    if isinstance(node, RequireStatement):
        return Statement(
            "require",
            expression=lower_expression(node.condition, context),
            details={"code": node.diagnostic_code},
            span=node.span,
        )
    if isinstance(node, EmitStatement):
        return Statement("emit", node.name, lower_expression(node.expression, context), span=node.span)
    if isinstance(node, IfStatement):
        return Statement(
            "if",
            expression=lower_expression(node.condition, context),
            details={
                "then": tuple(_lower_statement(item, context) for item in node.then_body),
                "else": tuple(_lower_statement(item, context) for item in node.else_body),
            },
            span=node.span,
        )
    if isinstance(node, ForStatement):
        iterable = lower_expression(node.iterable, context)
        item_type = None
        if isinstance(iterable.result_type, dict):
            arguments = iterable.result_type.get("arguments", [])
            if iterable.result_type.get("kind") == "Vector" and len(arguments) == 1:
                item_type = arguments[0]
        return Statement(
            "for",
            node.name,
            iterable,
            {
                "limit": node.limit,
                "item_type": item_type,
                "body": tuple(_lower_statement(item, context) for item in node.body),
            },
            node.span,
        )
    if isinstance(node, MatchStatement):
        cases = []
        for case in node.cases:
            cases.append(
                {
                    "tag": list(case.tag),
                    "bindings": list(case.bindings),
                    "body": tuple(_lower_statement(item, context) for item in case.body),
                    "span": case.span.to_dict(),
                }
            )
        return Statement(
            "match",
            expression=lower_expression(node.expression, context),
            details={"cases": cases},
            span=node.span,
        )
    raise _pending(node, type(node).__name__)


def _nested_statement_effects(value: object) -> set[str]:
    result: set[str] = set()
    if isinstance(value, Statement):
        result.update(value.effects)
    elif isinstance(value, dict):
        for nested in value.values():
            result.update(_nested_statement_effects(nested))
    elif isinstance(value, tuple | list):
        for nested in value:
            result.update(_nested_statement_effects(nested))
    return result


def _lower_statement(node, context: LoweringContext | None = None) -> Statement:
    statement = _lower_statement_raw(node, context)
    if context is None:
        return statement
    effects = {"pure"}
    if statement.kind in {"measure", "evidence"}:
        effects.add("evidence")
    effects.update(_nested_statement_effects(statement.details))
    ordered_effects = tuple(
        item for item in ("pure", "evidence") if item in effects
    )
    return replace(
        statement,
        effects=ordered_effects,
        provenance=context.provenance(node),
    )


def lower_source(
    tree: ProgramSource | ModuleSource,
    semantic: SemanticModel | None = None,
) -> Program:
    context = None if semantic is None else LoweringContext.from_model(semantic)
    owner = tree.name if isinstance(tree, ModuleSource) else ("program", tree.name)
    source_kind = "module" if isinstance(tree, ModuleSource) else "program"
    lowered_name = ".".join(tree.name) if isinstance(tree, ModuleSource) else tree.name
    imports = tuple(
        {
            "module": ".".join(declaration.module),
            "kind": "standard" if declaration.module[0] == "std" else "project",
            "alias": declaration.alias,
            "selection": sorted(declaration.selection),
            "span": declaration.span.to_dict(),
            "provenance": (
                None if context is None else context.provenance(declaration)
            ),
        }
        for declaration in sorted(
            tree.imports,
            key=lambda item: (item.module, item.alias or "", tuple(sorted(item.selection))),
        )
    )
    statements: list[Statement] = []
    definitions: list[dict[str, object]] = []
    for item in tree.items:
        if isinstance(item, RecordDeclaration):
            if context is None:
                raise _pending(item, type(item).__name__)
            spec = context.records[_semantic_key(owner, item.name)]
            definitions.append(
                {
                    "kind": "record",
                    "identity": spec.key,
                    "name": item.name,
                    "exported": item.exported,
                    "fields": [
                        {
                            "name": field.name,
                            "type": field.value_type.to_dict(),
                            "span": field.span.to_dict(),
                            "provenance": context.provenance(field),
                        }
                        for field in spec.fields
                    ],
                    "span": item.span.to_dict(),
                    "provenance": context.provenance(item),
                }
            )
            continue
        if isinstance(item, EnumDeclaration):
            if context is None:
                raise _pending(item, type(item).__name__)
            spec = context.enums[_semantic_key(owner, item.name)]
            definitions.append(
                {
                    "kind": "enum",
                    "identity": spec.key,
                    "name": item.name,
                    "exported": item.exported,
                    "variants": [
                        {
                            "name": variant.name,
                            "fields": [
                                {
                                    "name": field.name,
                                    "type": field.value_type.to_dict(),
                                    "span": field.span.to_dict(),
                                    "provenance": context.provenance(field),
                                }
                                for field in variant.fields
                            ],
                            "span": variant.span.to_dict(),
                            "provenance": context.provenance(variant),
                        }
                        for variant in spec.variants
                    ],
                    "span": item.span.to_dict(),
                    "provenance": context.provenance(item),
                }
            )
            continue
        if isinstance(item, FunctionDeclaration):
            spec = (
                None
                if context is None
                else context.function(_semantic_key(owner, item.name))
            )
            parameters = [
                {
                    "name": parameter.name,
                    "type": (
                        None
                        if spec is None
                        else spec.parameters[index].value_type.to_dict()
                    ),
                    "span": parameter.span.to_dict(),
                    "provenance": (
                        None if context is None else context.provenance(parameter)
                    ),
                }
                for index, parameter in enumerate(item.parameters)
            ]
            captures = [
                {
                    "name": name,
                    "type": (
                        None
                        if context is None
                        else context.binding_type(name, None)
                    ),
                    "span": item.span.to_dict(),
                    "provenance": (
                        None if context is None else context.provenance(item)
                    ),
                }
                for name in item.captures
            ]
            statements.append(
                Statement(
                    "function",
                    item.name,
                    lower_expression(item.return_expression, context),
                    {
                        "params": tuple(parameter.name for parameter in item.parameters),
                        "parameters": parameters,
                        "captures": captures,
                        "target": None if spec is None else spec.key,
                        "return_type": None if spec is None else spec.return_type.to_dict(),
                        "body": tuple(_lower_statement(statement, context) for statement in item.body),
                        "call_depth": (
                            None
                            if context is None or spec is None
                            else context.call_depths[spec.key]
                        ),
                        "call_depth_limit": 64,
                    },
                    item.span,
                    None if spec is None else spec.return_type.to_dict(),
                    ("pure",),
                    None if context is None else context.provenance(item),
                )
            )
            continue
        statements.append(_lower_statement(item, context))
    metadata = {}
    if context is not None:
        metadata = {
            "source_kind": source_kind,
            "declared_effects": list(context.declared_effects),
            "inferred_effects": list(context.inferred_effects),
            "maximum_call_depth": context.maximum_call_depth,
            "call_depth_limit": 64,
            "references": [item.to_dict() for item in semantic.references],
            "conversions": [item.to_dict() for item in semantic.conversions],
        }
    exports: tuple[dict[str, object], ...] = ()
    if semantic is not None and semantic.interface is not None:
        exports = tuple(
            {
                **item.to_dict(),
                "provenance": context.provenance(item),
            }
            for item in sorted(
                semantic.interface.exports,
                key=lambda value: (value.target or "", value.kind, value.name),
            )
        )
    return Program(
        profile="bangel 1.0",
        name=lowered_name,
        effects=tree.effects,
        statements=tuple(statements),
        metadata=metadata,
        definitions=tuple(definitions),
        imports=imports,
        exports=exports,
    )
