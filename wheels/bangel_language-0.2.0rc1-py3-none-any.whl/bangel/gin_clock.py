"""Exact rational clock normalization emitted in the frozen Bangel 1.0 grammar.

The host validates structure only. Bounded binary long division avoids forming
the potentially 106-bit tick-times-scale product in the signed Int64 runtime.
"""
from __future__ import annotations

import json

from .gin import GinInputError, MAX_TICK, _IDENTIFIER, _integer


_POWERS = ", ".join(str(2**bit) for bit in range(52, -1, -1))
FUNCTIONS = """record ScaleParts
  quotient: Int
  remainder: Int
end
function divide_scale(numerator: Int, denominator: Int) -> ScaleParts
  let powers = [POWERS]
  var bits: Int = numerator
  var quotient: Int = 0
  var remainder: Int = 0
  for power in powers limit 53
    set quotient = quotient * 2
    set remainder = remainder * 2
    if bits >= power
      set bits = bits - power
      set remainder = remainder + 1
    end
    if remainder >= denominator
      set remainder = remainder - denominator
      set quotient = quotient + 1
    end
  end
  return ScaleParts(quotient = quotient, remainder = remainder)
end
function round_scale(value: Int, scale: ScaleParts, denominator: Int, upward: Bool) -> Int
  let powers = [POWERS]
  var bits: Int = value
  var quotient: Int = 0
  var remainder: Int = 0
  if bits < 0
    set bits = -bits
  end
  for power in powers limit 53
    if quotient <= CAP
      set quotient = quotient * 2
      set remainder = remainder * 2
      if bits >= power
        set bits = bits - power
        set quotient = quotient + scale.quotient
        set remainder = remainder + scale.remainder
      end
      if remainder >= denominator
        set remainder = remainder - denominator
        set quotient = quotient + 1
      end
      if remainder >= denominator
        set remainder = remainder - denominator
        set quotient = quotient + 1
      end
      if quotient > CAP
        set quotient = CAP + 1
      end
    end
  end
  if remainder > 0 and ((value < 0 and not upward) or (value >= 0 and upward))
    set quotient = quotient + 1
  end
  if value < 0
    set quotient = -quotient
  end
  return quotient
end
""".replace("POWERS", _POWERS).replace("CAP", str(3 * MAX_TICK))
# A larger partial quotient cannot be rescued by the offset and error: each is
# within +/-MAX_TICK. Saturated values therefore always fail the outer output
# guards. All intermediate values stay below 7*MAX_TICK + 2 < 2**63.


def transform_source(transform):
    """Return declarations, numeric names, and runtime admission guards."""
    required = {"transformId", "version", "sourceClock", "referenceClock",
                "sourceUnit", "referenceUnit", "scale", "offset", "error",
                "calibrationEvidenceRefs", "admitted"}
    optional = {"validFrom", "validUntil"}
    if (type(transform) is not dict or not required <= set(transform)
            or set(transform) - required - optional):
        raise GinInputError("GIN_INPUT_SHAPE", "Clock transform fields do not match the contract.")
    scale = transform["scale"]
    if type(scale) is not dict or set(scale) != {"numerator", "denominator"}:
        raise GinInputError("GIN_INPUT_SHAPE", "Scale requires numerator and denominator.")
    error = transform["error"]
    if type(error) is not list or len(error) != 2:
        raise GinInputError("GIN_INPUT_SHAPE", "Transform error requires two bounds.")
    if type(transform["admitted"]) is not bool:
        raise GinInputError("GIN_INPUT_SHAPE", "Transform admission requires a boolean.")
    refs = transform["calibrationEvidenceRefs"]
    if type(refs) is not list:
        raise GinInputError("GIN_INPUT_SHAPE", "Calibration evidence requires a reference array.")
    declarations = []
    for name in ("transformId", "version", "sourceClock", "referenceClock", "sourceUnit", "referenceUnit"):
        value = transform[name]
        if type(value) is not str or not _IDENTIFIER.fullmatch(value):
            raise GinInputError("GIN_IDENTITY_INVALID", "Clock transform requires bounded identifiers.")
        declarations.append(f"let t_{name} = " + json.dumps(value))
    for ref in refs:
        if type(ref) is not str or not _IDENTIFIER.fullmatch(ref):
            raise GinInputError("GIN_IDENTITY_INVALID", "Calibration reference requires a bounded identifier.")
    declarations.extend([
        "let t_admitted = " + str(transform["admitted"]).lower(),
        f"let t_calibration_count = {len(refs)}",
    ])
    # Frozen vectors require positive lengths. An empty collection always
    # HOLDs at the provenance guard and needs no unreachable output binding.
    if refs:
        declarations.append(f"let t_calibration_refs: Vector[Text; {len(refs)}] = " + json.dumps(refs))
    values = {"numerator": scale["numerator"], "denominator": scale["denominator"],
              "offset": transform["offset"], "error_lower": error[0], "error_upper": error[1]}
    values.update({key: transform[key] for key in ("validFrom", "validUntil") if key in transform})
    numeric = []
    for name, value in values.items():
        symbol = "t_" + name
        numeric.append(symbol)
        declarations.append("let " + symbol + " = " + _integer(value, symbol))
    guards = [
        "require t_numerator > 0 and t_denominator > 0 else GIN_CLOCK_TRANSFORM_INVALID",
        "require t_error_lower <= 0 and t_error_upper >= 0 else GIN_ERROR_INTERVAL_INVALID",
        "require t_admitted else GIN_CLOCK_TRANSFORM_UNADMITTED",
        "require t_calibration_count > 0 else GIN_PROVENANCE_MISSING",
    ]
    if "validFrom" in transform and "validUntil" in transform:
        guards.append("require t_validFrom <= t_validUntil else GIN_CLOCK_TRANSFORM_WINDOW")
    guards.append("require p_interval_clock == t_sourceClock and p_interval_unit == t_sourceUnit else GIN_CLOCK_TRANSFORM_MISMATCH")
    if "validFrom" in transform:
        guards.append("require p_interval_lower >= t_validFrom else GIN_CLOCK_TRANSFORM_WINDOW")
    if "validUntil" in transform:
        guards.append("require p_interval_upper <= t_validUntil else GIN_CLOCK_TRANSFORM_WINDOW")
    return declarations, numeric, guards


BODY = f"""derive scale_parts = divide_scale(t_numerator, t_denominator)
derive lower = round_scale(p_interval_lower, scale_parts, t_denominator, false) + t_offset + t_error_lower
derive upper = round_scale(p_interval_upper, scale_parts, t_denominator, true) + t_offset + t_error_upper
derive mapped_precision = round_scale(p_interval_precision, scale_parts, t_denominator, true)
derive precision = mapped_precision + t_error_upper - t_error_lower
derive width = upper - lower
require lower >= -{MAX_TICK} and lower <= {MAX_TICK} else GIN_ARITHMETIC_OVERFLOW
require upper >= -{MAX_TICK} and upper <= {MAX_TICK} else GIN_ARITHMETIC_OVERFLOW
require precision <= {MAX_TICK} else GIN_ARITHMETIC_OVERFLOW
require width <= {MAX_TICK} else GIN_ARITHMETIC_OVERFLOW
if lower == upper
  emit state = "known"
else
  emit state = "bounded"
end
emit lower = lower
emit upper = upper
if precision < width
  emit precision = width
else
  emit precision = precision
end
emit clock = t_referenceClock
emit unit = t_referenceUnit
emit transform_id = t_transformId
emit transform_version = t_version
"""
