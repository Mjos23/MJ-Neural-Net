from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .canonical import digest
from .compiler import ElsaCompiler
from .diagnostics import BangelDiagnostic
from .identity import COMPILER_PROTOCOL


@dataclass(frozen=True, slots=True)
class ProjectBuild:
    value: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return dict(self.value)

    def verify(self) -> None:
        claimed = self.value.get("project_root")
        basis = {key: value for key, value in self.value.items() if key != "project_root"}
        if not isinstance(claimed, str) or digest(basis) != claimed:
            raise BangelDiagnostic("PROJECT_ROOT", "Project root does not match canonical content.")


class ElsaProjectBuilder:
    profile = "Bangel-Project-Build/1"

    def build(self, manifest: dict[str, Any], directory: Path) -> ProjectBuild:
        if manifest.get("profile") != "Bangel-Project/1":
            raise BangelDiagnostic("PROJECT_PROFILE", "Project manifest requires Bangel-Project/1.")
        name, entry, sources = manifest.get("name"), manifest.get("entry"), manifest.get("sources")
        if not isinstance(name, str) or not name or not isinstance(entry, str) or not isinstance(sources, list) or not sources:
            raise BangelDiagnostic("PROJECT_MANIFEST", "Project name, entry, and non-empty sources are required.")
        root = directory.resolve()
        modules: list[dict[str, Any]] = []
        seen: set[str] = set()
        for source in sources:
            if not isinstance(source, dict) or not isinstance(source.get("module"), str) or not isinstance(source.get("file"), str):
                raise BangelDiagnostic("PROJECT_SOURCE", "Each project source requires module and file strings.")
            module = source["module"]
            if module in seen:
                raise BangelDiagnostic("PROJECT_MODULE_DUPLICATE", f"Duplicate project module {module!r}.")
            seen.add(module)
            candidate = (root / source["file"]).resolve()
            if root not in candidate.parents:
                raise BangelDiagnostic("PROJECT_PATH", "Project source cannot escape the manifest directory.")
            try:
                text = candidate.read_text(encoding="utf-8")
            except OSError as exc:
                raise BangelDiagnostic("PROJECT_SOURCE_READ", f"Cannot read project source {source['file']!r}.") from exc
            compilation = ElsaCompiler().compile(candidate.name, text).to_dict()
            modules.append({
                "module": module,
                "file": candidate.relative_to(root).as_posix(),
                "program": compilation["program"],
                "program_root": compilation["program_root"],
            })
        if entry not in seen:
            raise BangelDiagnostic("PROJECT_ENTRY", "Project entry must name a declared module.")
        basis = {
            "profile": self.profile,
            "project": name,
            "entry": entry,
            "modules": sorted(modules, key=lambda item: item["module"]),
            "compiler": {
                "name": "Elsa",
                "protocol": COMPILER_PROTOCOL,
                "version": ElsaCompiler.version,
            },
            "authority_effect": "NONE",
            "physical_effect": "NONE",
        }
        result = ProjectBuild({**basis, "project_root": digest(basis)})
        result.verify()
        return result

    def build_file(self, manifest_path: Path) -> ProjectBuild:
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise BangelDiagnostic("PROJECT_MANIFEST_READ", "Project manifest is not valid UTF-8 JSON.") from exc
        if not isinstance(manifest, dict):
            raise BangelDiagnostic("PROJECT_MANIFEST", "Project manifest must be a JSON object.")
        return self.build(manifest, manifest_path.parent)
