from __future__ import annotations

import json
from typing import Any

from .canonical import canonical_bytes, digest
from .diagnostics import BangelDiagnostic
from .identity import AUTHORITY_EFFECT, PHYSICAL_EFFECT
from .receipt_contract import MAX_BYTES, MAX_DEPTH, preflight, verify_contract


def bind_receipt(basis: dict[str, Any]) -> dict[str, Any]:
    bounded = {**basis, "authority_effect": AUTHORITY_EFFECT, "physical_effect": PHYSICAL_EFFECT}
    return {**bounded, "receipt_root": digest(bounded)}


def verify_receipt(receipt: dict[str, Any]) -> None:
    """Verify represented semantics and digest without executing any program."""
    preflight(receipt)
    if type(receipt) is not dict:
        raise BangelDiagnostic("RECEIPT_SHAPE", "Receipt must be an object.")
    claimed = receipt.get("receipt_root")
    basis = {key: value for key, value in receipt.items() if key != "receipt_root"}
    if type(claimed) is not str or digest(basis) != claimed:
        raise BangelDiagnostic("RECEIPT_ROOT", "Receipt root does not match canonical content.")
    from .ir_types import unit_work_budget
    with unit_work_budget():
        verify_contract(receipt)


def receipt_from_bytes(data: bytes) -> dict[str, Any]:
    """Admit only exact canonical UTF-8 JSON, rejecting duplicates before loss."""
    if type(data) is not bytes or len(data) > MAX_BYTES:
        raise BangelDiagnostic("RECEIPT_RESOURCE", "Receipt wire bytes exceed the admission limit.")
    try:
        text = data.decode("utf-8", errors="strict")
        quoted = escaped = False
        depth = 0
        for char in text:
            if quoted:
                if escaped: escaped = False
                elif char == "\\": escaped = True
                elif char == '"': quoted = False
            elif char == '"': quoted = True
            elif char in "[{":
                depth += 1
                if depth > MAX_DEPTH:
                    raise BangelDiagnostic("RECEIPT_RESOURCE", "Receipt wire nesting exceeds its limit.")
            elif char in "]}": depth -= 1

        def object_pairs(pairs):
            value = {}
            for key, item in pairs:
                if key in value:
                    raise BangelDiagnostic("RECEIPT_CANONICAL", "Duplicate receipt object key.")
                value[key] = item
            return value

        def forbidden_number(_):
            raise BangelDiagnostic("RECEIPT_CANONICAL", "Receipt JSON permits only integer numeric tokens.")

        value = json.loads(text, object_pairs_hook=object_pairs, parse_float=forbidden_number, parse_constant=forbidden_number)
        preflight(value)
        if canonical_bytes(value) != data:
            raise BangelDiagnostic("RECEIPT_CANONICAL", "Receipt bytes are not canonical UTF-8 JSON.")
        verify_receipt(value)
        return value
    except BangelDiagnostic:
        raise
    except (UnicodeError, ValueError, TypeError, RecursionError) as exc:
        raise BangelDiagnostic("RECEIPT_CANONICAL", "Receipt wire encoding is malformed.") from exc
