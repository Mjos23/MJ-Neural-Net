from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .diagnostics import SourceSpan


@dataclass(frozen=True, slots=True)
class Expression:
    kind: str
    value: Any = None
    operands: tuple["Expression", ...] = ()
    span: SourceSpan | None = None
    result_type: dict[str, Any] | None = None
    effects: tuple[str, ...] = ()
    provenance: dict[str, Any] | None = None

    def to_ir(self) -> dict[str, Any]:
        result: dict[str, Any] = {"kind": self.kind}
        if self.value is not None:
            result["value"] = self.value
        if self.operands:
            result["operands"] = [operand.to_ir() for operand in self.operands]
        if self.span:
            result["span"] = self.span.to_dict()
        if self.result_type is not None:
            result["type"] = self.result_type
        if self.effects:
            result["effects"] = list(self.effects)
        if self.provenance is not None:
            result["provenance"] = self.provenance
        return result


@dataclass(frozen=True, slots=True)
class Statement:
    kind: str
    name: str | None = None
    expression: Expression | None = None
    details: dict[str, Any] = field(default_factory=dict)
    span: SourceSpan | None = None
    result_type: dict[str, Any] | None = None
    effects: tuple[str, ...] = ()
    provenance: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class Program:
    profile: str
    name: str
    effects: tuple[str, ...]
    statements: tuple[Statement, ...]
    metadata: dict[str, Any] = field(default_factory=dict)
    definitions: tuple[dict[str, Any], ...] = ()
    imports: tuple[dict[str, Any], ...] = ()
    exports: tuple[dict[str, Any], ...] = ()
