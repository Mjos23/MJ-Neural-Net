"""Independent B03.2 resolved-type and expression contract.

This module imports neither the frontend nor the evaluator. Decimal payloads
retain Elsa's source precision; finite Decimal128 admission is checked without
silently rewriting that preserved spelling. Unit expressions are lossy in JP-IR/1:
operators concatenate text, so valid groupings are admitted under explicit work
ceilings; each arithmetic node additionally pins its exact operand-derived unit.
"""
from __future__ import annotations

import re
from contextlib import contextmanager
from contextvars import ContextVar
from decimal import Context, Decimal, DecimalException, ROUND_HALF_EVEN, localcontext
from functools import lru_cache

from .diagnostics import BangelDiagnostic
from .units import UNITS

MAX_UNIT_FACTORS = 128
MAX_UNIT_GROUPING_OPERATIONS = 65536
MAX_UNIT_TOTAL_WORK = 1000000
_UNIT_WORK = ContextVar("bangel_ir_unit_work", default=None)
_SCALARS = {'Bool', 'Text', 'Int', 'Real', 'Failure'}
_PHYSICAL = {'Quantity', 'MassDelta'}
_NUMERIC = {'Int', 'Real'}
_UNKNOWN_BASE = {'Bool', 'Int', 'Real', 'Quantity', 'MassDelta', 'Measurement'}
_MASS = [1, 0, 0, 0, 0]
_DECIMAL128 = Context(prec=34, Emin=-6143, Emax=6144, rounding=ROUND_HALF_EVEN)
_NAME = re.compile(r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)*\Z')
_TERM = re.compile(r'(1|[A-Za-z]+)(?:\^(-?[1-9][0-9]*))?\Z')
_NUMBER = re.compile(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:E[+-][1-9][0-9]*)?\Z')
_INT = re.compile(r'-?(?:0|[1-9][0-9]*)\Z')
_FIXED_SCALE = re.compile(r'(?:10*|0\.0*1)\Z')


def _fail(message, code='IR_TYPE'):
    raise BangelDiagnostic(code, message)


def _check(condition, message, code='IR_TYPE'):
    if not condition:
        _fail(message, code)


def _keys(value, required, optional=()):
    _check(type(value) is dict and set(required) <= set(value) <= set(required) | set(optional), 'Resolved value has missing or extra fields.')


@contextmanager
def unit_work_budget(limit=MAX_UNIT_TOTAL_WORK):
    """Bound total unit matching work for one independent verification.

    The immutable context-local (limit, used) state prevents concurrent or nested
    admissions from changing one another. Every cache hit is charged its original
    deterministic work, so warming the cache cannot change admission decisions.
    Direct helper use outside this context keeps the individual unit ceilings.
    """
    _check(type(limit) is int and limit >= 0, 'Unit work budget must be nonnegative integer.', 'IR_RESOURCE_LIMIT')
    token = _UNIT_WORK.set((limit, 0))
    try:
        yield
    finally:
        _UNIT_WORK.reset(token)


def _charge_unit_work(work):
    budget = _UNIT_WORK.get()
    if budget is not None:
        limit, used = budget
        _check(used + work <= limit, 'Aggregate unit matching work budget exceeded.', 'IR_RESOURCE_LIMIT')
        _UNIT_WORK.set((limit, used + work))


def _scalar(kind):
    return {'kind': kind, 'display': kind}


def _wrap(kind, inner, size=None):
    display = f'Map[Text, {inner["display"]}]' if kind == 'Map' else f'{kind}[{inner["display"]}{"; " + str(size) if size is not None else ""}]'
    result = {'kind': kind, 'display': display, 'arguments': [inner]}
    if size is not None:
        result['size'] = size
    return result


def _physical(kind, unit):
    return {'kind': kind, 'display': f'{kind}[{unit["text"]}]', 'unit': unit}


def _unwrap(value):
    return (value['arguments'][0], True) if value['kind'] == 'Unknown' else (value, False)


def _maybe_unknown(value, unknown):
    return _wrap('Unknown', value) if unknown else value


def _scale_text(value):
    if not value:
        return '0'
    # Bound expanded output before formatting even for internally derived scales.
    exponent = value.as_tuple().exponent
    _check(value.is_finite(), 'Unit scale must be finite.', 'IR_UNIT')
    width = max(value.adjusted() + 1, 1) + max(-exponent, 0) + (1 if exponent < 0 else 0)
    _check(width <= 1048576, 'Derived unit scale exceeds the string budget.', 'IR_RESOURCE_LIMIT')
    # Unit scale output is fixed and has no insignificant fractional zeroes.
    text = format(value, 'f')
    return text.rstrip('0').rstrip('.') if '.' in text else text


def _numeric(text):
    _check(type(text) is str and _NUMBER.fullmatch(text) is not None, 'Noncanonical decimal magnitude.', 'IR_SCALAR')
    try:
        value = Decimal(text)
        _check(value.is_finite(), 'Magnitude must be finite.', 'IR_SCALAR')
        _check(not (value.is_zero() and value.is_signed()), 'Negative zero is not a canonical magnitude.', 'IR_SCALAR')
        # Check Decimal128 overflow before any possible fixed formatting. Tiny
        # preserved source values may still round to zero, as in frozen Elsa.
        with localcontext(_DECIMAL128):
            rounded = +value
        _check(rounded.is_finite(), 'Magnitude exceeds finite Decimal128.', 'IR_SCALAR')
        # Never expand exponent-bearing input. For fixed input, the formatted
        # length is bounded by the already-admitted input string length.
        canonical = str(value) == text if 'E' in text else format(value, 'f') == text
        _check(canonical, 'Noncanonical decimal magnitude.', 'IR_SCALAR')
        return value
    except (DecimalException, ValueError) as exc:
        raise BangelDiagnostic('IR_SCALAR', 'Magnitude exceeds finite Decimal128.') from exc


def _unit_tokens(text):
    _check(type(text) is str and bool(text), 'Unit text must be nonempty.', 'IR_UNIT')
    parts = re.split(r'([*/])', text)
    _check(len(parts) % 2 == 1 and (len(parts) + 1) // 2 <= MAX_UNIT_FACTORS, 'Unit factor budget exceeded.', 'IR_RESOURCE_LIMIT')
    signatures = []
    for token in parts[::2]:
        match = _TERM.fullmatch(token)
        _check(match is not None, 'Unit factor spelling is invalid.', 'IR_UNIT')
        symbol, exponent_text = match.groups()
        _check(symbol in UNITS, 'Unregistered unit factor.', 'IR_UNIT')
        _check(exponent_text != '1', 'Unit exponent one is omitted canonically.', 'IR_UNIT')
        try:
            exponent = 1 if exponent_text is None else int(exponent_text)
        except ValueError as exc:
            raise BangelDiagnostic('IR_RESOURCE_LIMIT', 'Unit exponent exceeds integer parsing budget.') from exc
        unit = UNITS[symbol]
        power = unit.scale.as_tuple().exponent
        signatures.append(tuple(exponent * n for n in (*unit.dimension, power)))
    return signatures, parts[1::2]


def _combine_signature(left, right, divide=False):
    return tuple(a - b if divide else a + b for a, b in zip(left, right))


@lru_cache(maxsize=4096)
def _unit_match_result(text, target, allow_grouping=True):
    terms, operators = _unit_tokens(text)
    flat = terms[0]
    for operator, term in zip(operators, terms[1:]):
        flat = _combine_signature(flat, term, operator == '/')
    if target == flat:
        return True, len(terms)
    if not allow_grouping or len(terms) == 1:
        return False, len(terms)
    # All possible binary associations account for producer concatenation and
    # canonical denominator formatting. Each candidate operation is budgeted.
    table = {(i, i + 1): {term} for i, term in enumerate(terms)}
    operations = 0
    for width in range(2, len(terms) + 1):
        for start in range(len(terms) - width + 1):
            end = start + width
            candidates = set()
            for split in range(start + 1, end):
                for left in table[start, split]:
                    for right in table[split, end]:
                        operations += 1
                        _check(operations <= MAX_UNIT_GROUPING_OPERATIONS, 'Unit grouping work budget exceeded.', 'IR_RESOURCE_LIMIT')
                        candidates.add(_combine_signature(left, right, operators[split - 1] == '/'))
            table[start, end] = candidates
    return target in table[0, len(terms)], len(terms) + operations


def _matches_unit(text, target, allow_grouping=True):
    matches, work = _unit_match_result(text, target, allow_grouping)
    _charge_unit_work(work)
    return matches


def verify_unit(unit, *, allow_grouping=True):
    _keys(unit, {'text', 'dimension', 'scale'})
    dimension = unit['dimension']
    _check(type(dimension) is list and len(dimension) == 5 and all(type(v) is int for v in dimension), 'Unit dimension must have five integer axes.', 'IR_UNIT')
    text = unit['scale']
    _check(type(text) is str and len(text) <= 1048576, 'Unit scale must be decimal text.', 'IR_UNIT')
    # Every registered scale is a power of ten. Validate its canonical fixed
    # spelling before constructing or formatting any Decimal; an exponent in a
    # tiny hostile string must never trigger a large fixed-text allocation.
    _check(_FIXED_SCALE.fullmatch(text) is not None, 'Unit scale must be a positive canonical fixed power of ten.', 'IR_UNIT')
    power = -(len(text) - 2) if text.startswith('0.') else len(text) - 1
    signature = (*dimension, power)
    _check(_matches_unit(unit['text'], signature, allow_grouping), 'Unit text, dimension, and scale disagree.', 'IR_UNIT')


def verify_type(value, definitions=None):
    _check(type(value) is dict and type(value.get('kind')) is str, 'Resolved type must be a discriminated object.')
    kind = value['kind']
    required = {'kind', 'display'}
    optional = set()
    if kind in _SCALARS:
        display = kind
    elif kind in _PHYSICAL:
        required.add('unit')
        _check('unit' in value, 'Physical type requires a unit.')
        verify_unit(value['unit'])
        _check(kind != 'MassDelta' or value['unit']['dimension'] == _MASS, 'MassDelta requires pure mass.')
        display = f'{kind}[{value["unit"]["text"]}]'
    elif kind in {'Measurement', 'Unknown', 'Vector', 'Map', 'Result'}:
        required.add('arguments')
        arguments = value.get('arguments')
        _check(type(arguments) is list and len(arguments) == 1, 'Type requires exactly one type argument.')
        inner = arguments[0]
        verify_type(inner, definitions)
        _check(kind != 'Measurement' or inner['kind'] in _PHYSICAL, 'Measurement requires Quantity or MassDelta.')
        _check(kind != 'Unknown' or inner['kind'] in _UNKNOWN_BASE, 'Unknown underlying type is unsupported.')
        if kind == 'Vector':
            optional.add('size')
            if 'size' in value:
                _check(type(value['size']) is int and 0 <= value['size'] <= 65536, 'Resolved vector size must be in 0..65536 (zero is inferred empty).')
        display = _wrap(kind, inner, value.get('size'))['display']
    elif kind in {'Record', 'Enum'}:
        required.add('identity')
        identity = value.get('identity')
        _check(type(identity) is str and _NAME.fullmatch(identity) is not None and '.' in identity, 'Nominal identity must be canonical.')
        display = identity.rsplit('.', 1)[-1]
        if definitions is not None:
            definition = definitions.get(identity)
            _check(type(definition) is dict and definition.get('kind') == kind.lower(), 'Nominal identity does not resolve to its definition.')
    else:
        _fail('Unknown resolved type kind.')
    _keys(value, required, optional)
    _check(type(value['display']) is str and value['display'] == display, 'Type display does not match its resolved structure.')


def assignable(actual, expected):
    """Frozen assignment relation; actual Unknown retains refinement semantics."""
    if actual == expected:
        return True
    a, e = actual['kind'], expected['kind']
    if a == 'Unknown':
        return assignable(actual['arguments'][0], expected) or (e == 'Unknown' and assignable(actual['arguments'][0], expected['arguments'][0]))
    if e == 'Unknown':
        return False
    if a == 'Int' and e == 'Real':
        return True
    if a == e and a in _PHYSICAL:
        return actual['unit']['dimension'] == expected['unit']['dimension']
    if a == e and a in {'Measurement', 'Vector', 'Map', 'Result'}:
        return (a != 'Vector' or 'size' not in expected or actual.get('size') == expected['size']) and assignable(actual['arguments'][0], expected['arguments'][0])
    return False


def _combined_unit(left, right, divide=False):
    text = (left['text'] if right['text'] == '1' else f'{left["text"]}/{right["text"]}') if divide else (right['text'] if left['text'] == '1' else left['text'] if right['text'] == '1' else f'{left["text"]}*{right["text"]}')
    # Verified scales are exact powers of ten; derive without ambient Decimal
    # precision or exponent traps, then compare the exact wire representation.
    left_power = Decimal(left['scale']).adjusted()
    right_power = Decimal(right['scale']).adjusted()
    scale = Decimal((0, (1,), left_power - right_power if divide else left_power + right_power))
    return {'text': text, 'dimension': list(_combine_signature(left['dimension'], right['dimension'], divide)), 'scale': _scale_text(scale)}


def _comparison(left, right, operator):
    numeric = left['kind'] in _NUMERIC and right['kind'] in _NUMERIC
    physical = left['kind'] in _PHYSICAL and right['kind'] == left['kind'] and left['unit']['dimension'] == right['unit']['dimension']
    same = left == right and (operator in {'==', '!='} or left['kind'] in {'Text', 'Int', 'Real', 'Quantity', 'MassDelta'})
    _check(numeric or physical or same, 'Comparison operand types are incompatible.', 'IR_VALUE_TYPE')


def _binary_type(operator, left, right, operands=None):
    lhs, lu = _unwrap(left)
    rhs, ru = _unwrap(right)
    unknown = lu or ru
    a, b = lhs['kind'], rhs['kind']
    if a == 'Measurement' or b == 'Measurement':
        if operator in {'*', '/'}:
            _fail('Measurement multiplication/division is unsupported in Bangel/1.0.', 'UNCERTAINTY_PROPAGATION_POLICY')
        _check(operator in {'+', '-'}, 'Measurement requires explicit nominal comparison.', 'IR_VALUE_TYPE')
        inner = _binary_type(operator, lhs['arguments'][0] if a == 'Measurement' else lhs, rhs['arguments'][0] if b == 'Measurement' else rhs)
        return _maybe_unknown(_wrap('Measurement', inner), unknown)
    if operator in {'and', 'or'}:
        _check(a == b == 'Bool', 'Boolean operators require Bool operands.', 'IR_VALUE_TYPE')
        if operands and any(v.get('kind') == 'literal' and v.get('value') is (operator == 'or') for v in operands):
            unknown = False
        return _maybe_unknown(_scalar('Bool'), unknown)
    if operator in {'==', '!=', '<', '<=', '>', '>='}:
        _comparison(lhs, rhs, operator)
        return _maybe_unknown(_scalar('Bool'), unknown)
    _check(operator in {'+', '-', '*', '/'}, 'Unrecognized binary operator.', 'IR_VALUE_TYPE')
    if a in _NUMERIC and b in _NUMERIC:
        result = _scalar('Real' if operator == '/' or 'Real' in {a, b} else 'Int')
    elif operator in {'+', '-'}:
        _check(a in _PHYSICAL and b in _PHYSICAL and lhs['unit']['dimension'] == rhs['unit']['dimension'], 'Additive physical operands require equal dimensions.', 'IR_VALUE_TYPE')
        if a == b == 'Quantity':
            result = _physical('MassDelta' if operator == '-' and lhs['unit']['dimension'] == _MASS else 'Quantity', lhs['unit'])
        elif a == 'MassDelta' and b == 'Quantity':
            _check(operator == '+', 'MassDelta minus Quantity is unsupported.', 'IR_VALUE_TYPE')
            result = rhs
        else:
            result = lhs
    elif 'MassDelta' in {a, b}:
        _check((operator == '*' and (a in _NUMERIC or b in _NUMERIC)) or (operator == '/' and a == 'MassDelta' and b in _NUMERIC), 'MassDelta multiplicative operands are unsupported.', 'IR_VALUE_TYPE')
        result = lhs if a == 'MassDelta' else rhs
    elif a == 'Quantity' and b in _NUMERIC:
        result = lhs
    elif a in _NUMERIC and b == 'Quantity':
        result = rhs if operator == '*' else _physical('Quantity', _combined_unit({'text': '1', 'dimension': [0]*5, 'scale':'1'}, rhs['unit'], True))
    elif a == b == 'Quantity':
        result = _physical('Quantity', _combined_unit(lhs['unit'], rhs['unit'], operator == '/'))
    else:
        _fail('Arithmetic operands are unsupported.', 'IR_VALUE_TYPE')
    return _maybe_unknown(result, unknown)


def _canonical_unit(dimension):
    numerator, denominator = [], []
    for name, power in zip(('kg', 'm', 's', 'A', 'K'), dimension):
        if power:
            (numerator if power > 0 else denominator).append(name if abs(power) == 1 else f'{name}^{abs(power)}')
    text = '*'.join(numerator) or '1'
    if denominator:
        text += '/' + '*'.join(denominator)
    return {'text': text, 'dimension': dimension, 'scale': '1'}


def _intrinsic_type(target, arguments):
    types = [value['type'] for value in arguments]
    def count(number):
        _check(len(types) == number, 'Intrinsic argument count mismatch.', 'IR_VALUE_TYPE')
    def container(index, kind):
        _check(types[index]['kind'] == kind, 'Intrinsic container argument mismatch.', 'IR_VALUE_TYPE')
        return types[index]
    def exact(index, kind):
        _check(types[index] == _scalar(kind), 'Intrinsic scalar argument mismatch.', 'IR_VALUE_TYPE')
    if target == 'core.is_known':
        count(1)
        return _scalar('Bool')
    if target in {'core.nominal', 'core.uncertainty'}:
        count(1)
        base, unknown = _unwrap(types[0])
        _check(base['kind'] == 'Measurement', 'Projection requires Measurement.', 'IR_VALUE_TYPE')
        result = base['arguments'][0]
        return _maybe_unknown(result if target.endswith('nominal') else _physical('Quantity', result['unit']), unknown)
    if target == 'core.convert':
        count(2)
        value, unknown = _unwrap(types[0])
        unit_value = arguments[1]
        _check(unit_value['kind'] == 'literal' and type(unit_value.get('value')) is str and unit_value['value'] in UNITS, 'convert requires a registered Text unit literal.', 'IR_VALUE_TYPE')
        unit = UNITS[unit_value['value']]
        physical = value['arguments'][0] if value['kind'] == 'Measurement' else value
        _check(physical['kind'] in _PHYSICAL and physical['unit']['dimension'] == list(unit.dimension), 'convert dimensions are incompatible.', 'IR_VALUE_TYPE')
        result = _physical(physical['kind'], {'text': unit.symbol, 'dimension': list(unit.dimension), 'scale': _scale_text(unit.scale)})
        return _maybe_unknown(_wrap('Measurement', result) if value['kind'] == 'Measurement' else result, unknown)
    module, _, name = target.rpartition('.')
    if module == 'std.math':
        count(2 if name in {'min', 'max'} else 1)
        base, unknown = _unwrap(types[0])
        if name == 'abs':
            _check(base['kind'] in _NUMERIC | _PHYSICAL, 'abs requires numeric or physical values.', 'IR_VALUE_TYPE')
            return types[0]
        if name in {'min', 'max'}:
            right, ru = _unwrap(types[1])
            _comparison(base, right, name)
            result = _scalar('Real') if base['kind'] in _NUMERIC and right['kind'] in _NUMERIC and 'Real' in {base['kind'],right['kind']} else base
            return _maybe_unknown(result, unknown or ru)
        if name == 'sqrt':
            if base['kind'] in _NUMERIC:
                result = _scalar('Real')
            else:
                _check(base['kind'] == 'Quantity' and all(n % 2 == 0 for n in base['unit']['dimension']), 'sqrt requires numeric or even-dimension Quantity.', 'IR_VALUE_TYPE')
                result = _physical('Quantity', _canonical_unit([n // 2 for n in base['unit']['dimension']]))
            return _maybe_unknown(result, unknown)
    if module == 'std.vector':
        count(2 if name in {'at', 'dot', 'moving_mean', 'slope'} else 1)
        vector = container(0, 'Vector')
        item, unknown = _unwrap(vector['arguments'][0])
        if name == 'length':
            return _scalar('Int')
        if name == 'at':
            exact(1, 'Int')
            return _wrap('Result', vector['arguments'][0])
        if name in {'sum', 'mean', 'norm'}:
            _check(item['kind'] in _NUMERIC | _PHYSICAL, 'Vector aggregation requires numeric or physical elements.', 'IR_VALUE_TYPE')
            return _maybe_unknown(_scalar('Real') if name == 'mean' and item['kind'] == 'Int' else item, unknown)
        if name == 'moving_mean':
            _check(item['kind'] in _NUMERIC | _PHYSICAL, 'Moving mean requires numeric or physical elements.', 'IR_VALUE_TYPE')
            exact(1, 'Int')
            result = _maybe_unknown(_scalar('Real') if item['kind'] == 'Int' else item, unknown)
            return _wrap('Vector', result)
        if name in {'dot', 'slope'}:
            other = container(1, 'Vector')['arguments'][0]
            return _binary_type('*', vector['arguments'][0], other) if name == 'dot' else _binary_type('/', other, vector['arguments'][0])
    if module == 'std.map':
        count(2 if name == 'at' else 1)
        mapping = container(0, 'Map')
        if name == 'length':
            return _scalar('Int')
        if name == 'at':
            exact(1, 'Text')
            return _wrap('Result', mapping['arguments'][0])
        if name in {'keys', 'values'}:
            return _wrap('Vector', _scalar('Text') if name == 'keys' else mapping['arguments'][0])
    if module == 'std.topology':
        count(2 if name in {'node_variance', 'shadow_speed'} else 1)
        base, unknown = _unwrap(types[0])
        if name in {'node_variance', 'shadow_speed'}:
            _check(not unknown and base['kind'] == 'Quantity' and types[1]['kind'] == 'Quantity' and base['unit']['dimension'] == types[1]['unit']['dimension'], 'Topology comparison requires exact equal-dimension quantities.', 'IR_VALUE_TYPE')
            return base
        if name == 'dampen':
            if base['kind'] == 'Measurement':
                _fail('Measurement dampen is unsupported.', 'UNCERTAINTY_PROPAGATION_POLICY')
            _check(base['kind'] in {'Real', 'Quantity', 'MassDelta'}, 'dampen operand type is unsupported.', 'IR_VALUE_TYPE')
            return types[0]
        if name in {'step_cap', 'bound'}:
            _check(base['kind'] == 'Real', 'step_cap/bound requires Real.', 'IR_VALUE_TYPE')
            return types[0]
        if name == 'floor_challenge':
            _check(base['kind'] == 'Quantity' and base['unit']['dimension'] == _MASS, 'floor_challenge requires absolute mass.', 'IR_VALUE_TYPE')
            return _maybe_unknown(_scalar('Bool'), unknown)
    _fail('Unknown intrinsic target.', 'IR_VALUE_TYPE')


def verify_value_types(expression, definitions=None):
    """Check one expression after general schema/resource checks; no execution."""
    value_type = expression.get('type')
    verify_type(value_type, definitions)
    kind = expression['kind']
    operands = expression.get('operands', [])
    for operand in operands:
        verify_type(operand.get('type'), definitions)
    value = expression.get('value')
    result = None
    if kind == 'literal':
        _check(type(value) in {bool, str}, 'Literal payload must be Bool or Text.', 'IR_VALUE_TYPE')
        result = _scalar('Bool' if type(value) is bool else 'Text')
    elif kind == 'quantity':
        _keys(value, {'magnitude', 'unit'})
        magnitude = _numeric(value['magnitude'])
        _check(value_type['kind'] in {'Int', 'Real', 'Quantity'}, 'Quantity encoding requires Int, Real, or Quantity.', 'IR_VALUE_TYPE')
        if value_type['kind'] == 'Int':
            limit = 2**63 if expression.get('provenance', {}).get('role') == 'signed_literal_magnitude' else 2**63 - 1
            _check(_INT.fullmatch(value['magnitude']) is not None and -(2**63) <= magnitude <= limit and value['unit'] == '1', 'Int literal exceeds Int64 or has noninteger spelling/unit.', 'IR_SCALAR')
        elif value_type['kind'] == 'Real':
            _check(value['unit'] == '1', 'Real literal must be dimensionless.', 'IR_VALUE_TYPE')
        else:
            _check(value['unit'] == value_type['unit']['text'], 'Quantity unit and type disagree.', 'IR_VALUE_TYPE')
            verify_unit(value_type['unit'], allow_grouping=False)
            _check(value_type['unit']['dimension'] != _MASS or magnitude >= 0, 'Absolute mass cannot be negative.', 'IR_VALUE_TYPE')
    elif kind in {'argument', 'map_entry'}:
        _check(len(operands) == 1, 'Wrapper requires one operand.', 'IR_VALUE_TYPE')
        result = operands[0]['type']
    elif kind == 'unknown':
        _check(value_type['kind'] == 'Unknown', 'Unknown must retain its explicit underlying type.', 'IR_VALUE_TYPE')
    elif kind == 'mass_delta':
        _check(value_type['kind'] == 'MassDelta' and value['unit'] == value_type['unit']['text'] and len(operands) == 1 and operands[0]['type']['kind'] in _NUMERIC, 'MassDelta requires one known numeric magnitude and matching mass unit.', 'IR_VALUE_TYPE')
        verify_unit(value_type['unit'], allow_grouping=False)
    elif kind == 'unary':
        _check(len(operands) == 1, 'Unary expression requires one operand.', 'IR_VALUE_TYPE')
        result = operands[0]['type']
        base, unknown = _unwrap(result)
        if value == 'not':
            _check(base['kind'] == 'Bool', 'not requires Bool.', 'IR_VALUE_TYPE')
        else:
            _check(value in {'+', '-'} and base['kind'] in _NUMERIC | _PHYSICAL | {'Measurement'}, 'Unary sign type is invalid.', 'IR_VALUE_TYPE')
            physical = base['arguments'][0] if base['kind'] == 'Measurement' else base
            _check(not (value == '-' and physical['kind'] == 'Quantity' and physical['unit']['dimension'] == _MASS), 'Unary minus cannot construct negative absolute mass.', 'IR_VALUE_TYPE')
    elif kind == 'binary':
        _check(len(operands) == 2, 'Binary expression requires two operands.', 'IR_VALUE_TYPE')
        result = _binary_type(value, operands[0]['type'], operands[1]['type'], operands)
    elif kind == 'vector':
        _check(value_type['kind'] == 'Vector' and value_type.get('size') == len(operands), 'Vector shape and result type disagree.', 'IR_VALUE_TYPE')
        _check(all(assignable(item['type'], value_type['arguments'][0]) for item in operands), 'Vector element type mismatch.', 'IR_VALUE_TYPE')
        if operands:
            first = operands[0]['type']
            _check(all(assignable(item['type'], first) and assignable(first, item['type']) for item in operands), 'Vector elements must be mutually compatible.', 'IR_VALUE_TYPE')
    elif kind == 'map':
        _check(value_type['kind'] == 'Map' and all(item['kind'] == 'map_entry' and assignable(item['type'], value_type['arguments'][0]) for item in operands), 'Map entry type mismatch.', 'IR_VALUE_TYPE')
        keys = [item['value']['key'] for item in operands]
        _check(keys == sorted(set(keys)), 'Map keys must be sorted and unique.', 'IR_VALUE_TYPE')
    elif kind == 'index':
        _check(len(operands) == 2, 'Index requires target and index.', 'IR_VALUE_TYPE')
        target, index = [item['type'] for item in operands]
        _check(target['kind'] in {'Vector', 'Map'} and index == _scalar('Int' if target['kind'] == 'Vector' else 'Text'), 'Index operand type mismatch.', 'IR_VALUE_TYPE')
        result = _wrap('Result', target['arguments'][0])
    elif kind == 'field':
        _check(len(operands) == 1, 'Field requires one target.', 'IR_VALUE_TYPE')
        base = operands[0]['type']
        if base['kind'] == 'Failure':
            _check(value in {'code', 'message'}, 'Failure field is unknown.', 'IR_VALUE_TYPE')
            result = _scalar('Text')
        else:
            _check(base['kind'] == 'Record', 'Field access requires record or Failure.', 'IR_VALUE_TYPE')
            if definitions is not None:
                fields = definitions[base['identity']]['fields']
                field = next((item for item in fields if item['name'] == value), None)
                _check(field is not None, 'Record field is unknown.', 'IR_VALUE_TYPE')
                result = field['type']
    elif kind == 'failure':
        _check(len(operands) == 2 and all(item['kind'] == 'argument' and item['type'] == _scalar('Text') for item in operands), 'Failure requires code/message Text arguments.', 'IR_VALUE_TYPE')
        names = [item['value']['name'] for item in operands]
        _check(names == ['code', 'message'], 'Failure field order is invalid.', 'IR_VALUE_TYPE')
        result = _scalar('Failure')
    elif kind == 'result':
        _check(value_type['kind'] == 'Result' and len(operands) == 1 and operands[0]['kind'] == 'argument', 'Result constructor shape is invalid.', 'IR_VALUE_TYPE')
        variant = value.get('variant')
        _check(variant in {'Ok', 'Err'}, 'Unknown Result variant.', 'IR_VALUE_TYPE')
        _check(operands[0]['value']['name'] in {None, 'value' if variant == 'Ok' else 'error'}, 'Result argument name mismatch.', 'IR_VALUE_TYPE')
        _check(assignable(operands[0]['type'], value_type['arguments'][0] if variant == 'Ok' else _scalar('Failure')), 'Result payload type mismatch.', 'IR_VALUE_TYPE')
    elif kind in {'record', 'enum'}:
        _check(value_type['kind'] == kind.title() and value['identity'] == value_type['identity'] and value['name'] == value_type['display'], 'Nominal constructor type mismatch.', 'IR_VALUE_TYPE')
        if definitions is not None:
            definition = definitions[value['identity']]
            if kind == 'enum':
                definition = next((item for item in definition['variants'] if item['name'] == value['variant']), None)
                _check(definition is not None, 'Unknown enum variant.', 'IR_VALUE_TYPE')
            fields = definition['fields']
            _check(len(operands) == len(fields), 'Constructor field count mismatch.', 'IR_VALUE_TYPE')
            names = [item['value']['name'] for item in operands]
            _check((kind == 'enum' and all(name is None for name in names)) or names == [item['name'] for item in fields], 'Constructor field order mismatch.', 'IR_VALUE_TYPE')
            _check(all(item['kind'] == 'argument' and assignable(item['type'], field['type']) for item, field in zip(operands, fields)), 'Constructor field type mismatch.', 'IR_VALUE_TYPE')
    elif kind == 'call':
        target = value['target']
        _check(all(item['kind'] == 'argument' for item in operands), 'Calls require argument wrappers.', 'IR_VALUE_TYPE')
        if target.startswith(('core.', 'std.')):
            _check(all(item['value']['name'] is None for item in operands), 'Intrinsics require positional arguments.', 'IR_VALUE_TYPE')
            result = _intrinsic_type(target, [item['operands'][0] for item in operands])
    elif kind not in {'name', 'reference'}:
        _fail('Unknown typed value kind.', 'IR_VALUE_TYPE')
    if result is not None:
        _check(value_type == result, 'Expression resolved result disagrees with operand contract.', 'IR_VALUE_TYPE')
