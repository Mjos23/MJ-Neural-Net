from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True, slots=True)
class SourceSpan:
    line: int
    column: int = 1
    end_column: int | None = None

    def to_dict(self) -> dict[str, int | None]:
        return {
            "line": self.line,
            "column": self.column,
            "end_column": self.end_column,
        }


class BangelDiagnostic(ValueError):
    def __init__(
        self,
        code: str,
        message: str,
        span: SourceSpan | None = None,
        details: Mapping[str, object] | None = None,
    ):
        self.code = code
        self.message = message
        self.span = span
        self.details = dict(details or {})
        location = ""
        if span is not None:
            location = f" at {span.line}:{span.column}"
        super().__init__(f"{code}{location}: {message}")

    def to_dict(self) -> dict[str, object]:
        return {
            "code": self.code,
            "message": self.message,
            "span": self.span.to_dict() if self.span else None,
            "details": dict(self.details),
        }
