from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any

from .canonical import canonical_bytes, digest
from .diagnostics import BangelDiagnostic
from .identity import (
    AUTHORITY_EFFECT,
    CANONICAL_PATH,
    CANONICAL_STACK,
    COMPILER_PROTOCOL,
    CONFORMANCE_PROFILE,
    LANGUAGE_IDENTITY,
    PHYSICAL_EFFECT,
    SEMANTIC_DIAGNOSTIC_CONTRACT_SHA256,
    SEMANTIC_DIAGNOSTIC_FREEZE,
    Stage,
    TYPED_IR,
)
from .ir_registry import (
    registry_identity,
    verify_registered_instruction,
    verify_registered_value,
)
from .units import require_unit
from .ir_contract import preflight, wire_preflight, verify_contract


def _verify_provenance(
    value: Any,
    *,
    span: Any,
    source_name: str,
) -> None:
    if (
        not isinstance(value, dict)
        or value.get("language") != LANGUAGE_IDENTITY
        or value.get("compiler") != COMPILER_PROTOCOL
        or value.get("source") != source_name
        or value.get("span") != span
    ):
        raise BangelDiagnostic(
            "IR_PROVENANCE",
            "JP-IR provenance must bind the frozen identities, source, and exact span.",
        )
    conversions = value.get("conversions", [])
    if not isinstance(conversions, list):
        raise BangelDiagnostic(
            "IR_PROVENANCE", "JP-IR provenance conversions must be a list."
        )
    reference = value.get("reference")
    if reference is not None and (
        not isinstance(reference, dict)
        or not isinstance(reference.get("target"), str)
        or not isinstance(reference.get("symbol_kind"), str)
    ):
        raise BangelDiagnostic(
            "IR_PROVENANCE", "JP-IR reference provenance is invalid."
        )


def _verify_expression(
    expression: Any,
    *,
    strict: bool = False,
    source_name: str = "",
) -> None:
    if not isinstance(expression, dict) or not isinstance(expression.get("kind"), str):
        raise BangelDiagnostic("IR_EXPRESSION", "JP-IR expression structure is invalid.")
    verify_registered_value(expression, strict=strict)
    if expression["kind"] == "quantity":
        value = expression.get("value")
        try:
            if not isinstance(value, dict):
                raise TypeError
            magnitude_text = value.get("magnitude")
            unit_symbol = value.get("unit")
            if not isinstance(magnitude_text, str) or not isinstance(unit_symbol, str):
                raise TypeError
            magnitude = Decimal(magnitude_text)
            if not magnitude.is_finite():
                raise InvalidOperation
            encoded_type = expression.get("type")
            resolved_unit = (
                encoded_type.get("unit")
                if isinstance(encoded_type, dict)
                else None
            )
            if resolved_unit is None:
                require_unit(unit_symbol)
            else:
                if (
                    not isinstance(resolved_unit, dict)
                    or resolved_unit.get("text") != unit_symbol
                    or not isinstance(resolved_unit.get("dimension"), list)
                    or len(resolved_unit["dimension"]) != 5
                    or not all(type(item) is int for item in resolved_unit["dimension"])
                ):
                    raise TypeError
                scale = Decimal(resolved_unit.get("scale"))
                if not scale.is_finite() or scale <= 0:
                    raise InvalidOperation
        except (InvalidOperation, TypeError, ValueError) as exc:
            raise BangelDiagnostic(
                "IR_QUANTITY",
                "JP-IR quantity must contain a finite decimal magnitude and registered unit.",
            ) from exc
    if expression["kind"] == "mass_delta":
        value = expression.get("value")
        encoded_type = expression.get("type")
        if (
            not isinstance(value, dict)
            or not isinstance(encoded_type, dict)
            or encoded_type.get("kind") != "MassDelta"
            or not isinstance(encoded_type.get("unit"), dict)
            or value.get("unit") != encoded_type["unit"].get("text")
        ):
            raise BangelDiagnostic(
                "IR_MASS_DELTA", "JP-IR MassDelta value and resolved type disagree."
            )
    if expression["kind"] == "unknown":
        encoded_type = expression.get("type")
        if (
            not isinstance(encoded_type, dict)
            or encoded_type.get("kind") != "Unknown"
            or not isinstance(encoded_type.get("arguments"), list)
            or len(encoded_type["arguments"]) != 1
        ):
            raise BangelDiagnostic(
                "IR_UNKNOWN", "JP-IR Unknown must carry one resolved underlying type."
            )
    if strict:
        if not isinstance(expression.get("type"), dict):
            raise BangelDiagnostic(
                "IR_TYPE", "Every strict A1 expression must retain its resolved type."
            )
        if expression.get("effects") != ["pure"]:
            raise BangelDiagnostic(
                "IR_EFFECT", "Every strict A1 expression must retain its pure effect."
            )
        span = expression.get("span")
        if not isinstance(span, dict):
            raise BangelDiagnostic(
                "IR_SPAN", "Every strict A1 expression must retain a source span."
            )
        _verify_provenance(
            expression.get("provenance"), span=span, source_name=source_name
        )
    operands = expression.get("operands", [])
    if not isinstance(operands, list):
        raise BangelDiagnostic("IR_EXPRESSION", "JP-IR expression operands must be a list.")
    for operand in operands:
        _verify_expression(operand, strict=strict, source_name=source_name)


def _verify_instruction(
    instruction: Any,
    *,
    strict: bool,
    source_name: str,
) -> None:
    if not isinstance(instruction, dict):
        raise BangelDiagnostic(
            "IR_INSTRUCTION", "Every JP-IR instruction must be an object."
        )
    verify_registered_instruction(instruction, strict=strict)
    if strict:
        if not isinstance(instruction.get("path"), list):
            raise BangelDiagnostic(
                "IR_INSTRUCTION", "Every strict A1 instruction must retain its path."
            )
        effects = instruction.get("effects")
        if (
            not isinstance(effects, list)
            or not effects
            or any(item not in {"pure", "evidence"} for item in effects)
        ):
            raise BangelDiagnostic(
                "IR_EFFECT", "Every strict A1 instruction must retain valid effects."
            )
        span = instruction.get("span")
        if not isinstance(span, dict):
            raise BangelDiagnostic(
                "IR_SPAN", "Every strict A1 instruction must retain a source span."
            )
        _verify_provenance(
            instruction.get("provenance"), span=span, source_name=source_name
        )
    expression = instruction.get("expression")
    if expression is not None:
        _verify_expression(expression, strict=strict, source_name=source_name)
    details = instruction.get("details", {})
    if not isinstance(details, dict):
        raise BangelDiagnostic(
            "IR_INSTRUCTION", "JP-IR instruction details must be an object."
        )

    def verify_nested(value: Any) -> None:
        if isinstance(value, dict):
            if {"index", "path", "kind", "stage", "details"} <= set(value):
                _verify_instruction(value, strict=strict, source_name=source_name)
                return
            if isinstance(value.get("kind"), str) and (
                "value" in value or "operands" in value or "type" in value
            ):
                _verify_expression(value, strict=strict, source_name=source_name)
                return
            for nested in value.values():
                verify_nested(nested)
        elif isinstance(value, list):
            for nested in value:
                verify_nested(nested)

    verify_nested(details)


@dataclass(frozen=True, slots=True)
class JPIR:
    value: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return copy.deepcopy(self.value)

    def to_bytes(self) -> bytes:
        """Serialize JP-IR/1 as canonical UTF-8 JSON without a trailing newline."""

        return canonical_bytes(self.value)

    @classmethod
    def from_bytes(cls, data: bytes) -> "JPIR":
        """Admit only canonical, duplicate-free, verified JP-IR/1 bytes."""

        if not isinstance(data, bytes):
            raise BangelDiagnostic(
                "IR_SERIALIZATION", "JP-IR serialization input must be bytes."
            )

        wire_preflight(data)

        def closed_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
            value: dict[str, Any] = {}
            for key, item in pairs:
                if key in value:
                    raise ValueError(f"duplicate JSON key {key!r}")
                value[key] = item
            return value

        try:
            decoded = data.decode("utf-8", errors="strict")
            value = json.loads(decoded, object_pairs_hook=closed_object,
                               parse_constant=lambda text: (_ for _ in ()).throw(ValueError("nonfinite JSON number")))
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, RecursionError) as exc:
            raise BangelDiagnostic(
                "IR_SERIALIZATION",
                "JP-IR bytes must be duplicate-free UTF-8 JSON.",
            ) from exc
        if not isinstance(value, dict):
            raise BangelDiagnostic(
                "IR_SERIALIZATION", "JP-IR serialization root must be an object."
            )
        preflight(value)
        if canonical_bytes(value) != data:
            raise BangelDiagnostic(
                "IR_SERIALIZATION_NONCANONICAL",
                "JP-IR bytes do not use the canonical serialization form.",
            )
        result = cls(value)
        result.verify()
        return result

    def verify(self) -> None:
        preflight(self.value)
        if type(self.value) is not dict:
            raise BangelDiagnostic("IR_ENVELOPE", "JP-IR root must be an object.")
        try:
            self._verify_registered_contract()
            verify_contract(self.value)
        except BangelDiagnostic:
            raise
        except (TypeError, KeyError, IndexError, AttributeError, RecursionError, InvalidOperation, ValueError) as exc:
            raise BangelDiagnostic("IR_SCHEMA", "Malformed JP-IR contract field.") from exc

    def _verify_registered_contract(self) -> None:
        if self.value.get("profile") != TYPED_IR:
            raise BangelDiagnostic("IR_PROFILE", f"JP-IR profile must be {TYPED_IR}.")
        if self.value.get("identity") != CANONICAL_STACK:
            raise BangelDiagnostic(
                "IR_IDENTITY", "JP-IR identity block does not match the frozen A1 stack."
            )
        compiler = self.value.get("compiler")
        if (not isinstance(compiler, dict) or compiler.get("protocol") != COMPILER_PROTOCOL
                or compiler.get("name") != "Elsa"):
            raise BangelDiagnostic(
                "COMPILER_IDENTITY", f"JP-IR compiler protocol must be {COMPILER_PROTOCOL}."
            )
        if self.value.get("diagnostic_contract") != {
            "profile": CONFORMANCE_PROFILE,
            "freeze": SEMANTIC_DIAGNOSTIC_FREEZE,
            "compiler": COMPILER_PROTOCOL,
            "sha256": SEMANTIC_DIAGNOSTIC_CONTRACT_SHA256,
        }:
            raise BangelDiagnostic(
                "IR_DIAGNOSTIC_IDENTITY",
                "JP-IR diagnostic contract identity does not match frozen A1.",
            )
        if self.value.get("registry") != registry_identity():
            raise BangelDiagnostic(
                "IR_REGISTRY_IDENTITY",
                "JP-IR registry identity does not match the B03.1 freeze.",
            )
        claimed = self.value.get("program_root")
        basis = {key: value for key, value in self.value.items() if key != "program_root"}
        if not isinstance(claimed, str) or digest(basis) != claimed:
            raise BangelDiagnostic("PROGRAM_ROOT", "JP-IR program_root does not match canonical content.")
        instructions = self.value.get("instructions")
        if not isinstance(instructions, list):
            raise BangelDiagnostic("IR_INSTRUCTIONS", "JP-IR instructions must be a list.")
        source = self.value.get("source")
        source_name = source.get("name") if isinstance(source, dict) else None
        analysis = self.value.get("analysis")
        strict = (
            isinstance(source_name, str)
            and isinstance(analysis, dict)
            and analysis.get("source_kind") in {"program", "module"}
        )
        for instruction in instructions:
            _verify_instruction(
                instruction,
                strict=strict,
                source_name=source_name if isinstance(source_name, str) else "",
            )
        modules = self.value.get("modules", [])
        if not isinstance(modules, list):
            raise BangelDiagnostic("IR_MODULES", "JP-IR modules must be a list.")
        for module in modules:
            if not isinstance(module, dict) or not isinstance(module.get("name"), str):
                raise BangelDiagnostic("IR_MODULE", "Every linked JP-IR module must be an object with a name.")
            module_instructions = module.get("instructions")
            if not isinstance(module_instructions, list):
                raise BangelDiagnostic("IR_MODULE", "Every linked JP-IR module must contain instructions.")
            module_source = module.get("source")
            module_source_name = (
                module_source.get("name") if isinstance(module_source, dict) else None
            )
            module_analysis = module.get("analysis")
            module_strict = (
                isinstance(module_source_name, str)
                and isinstance(module_analysis, dict)
                and module_analysis.get("source_kind") == "module"
            )
            for instruction in module_instructions:
                _verify_instruction(
                    instruction,
                    strict=module_strict,
                    source_name=(
                        module_source_name
                        if isinstance(module_source_name, str)
                        else ""
                    ),
                )


def build_ir(
    *,
    source_name: str,
    source_digest: str,
    profile: str,
    program: str,
    effects: tuple[str, ...],
    instructions: list[dict[str, Any]],
    compiler_version: str,
    metadata: dict[str, Any] | None = None,
    definitions: list[dict[str, Any]] | None = None,
    imports: list[dict[str, Any]] | None = None,
    modules: list[dict[str, Any]] | None = None,
) -> JPIR:
    basis = {
        "profile": "JP-IR/1",
        "identity": dict(CANONICAL_STACK),
        "source": {
            "name": source_name,
            "digest": source_digest,
            "profile": profile,
        },
        "program": program,
        "effects": list(effects),
        "canonical_path": [stage.value for stage in CANONICAL_PATH],
        "state_meanings": {
            "R1": "Unidentified transition",
            "R2": "Living static",
            "N1": "First prediction node",
        },
        "compiler": {
            "name": "Elsa",
            "protocol": COMPILER_PROTOCOL,
            "version": compiler_version,
        },
        "diagnostic_contract": {
            "profile": CONFORMANCE_PROFILE,
            "freeze": SEMANTIC_DIAGNOSTIC_FREEZE,
            "compiler": COMPILER_PROTOCOL,
            "sha256": SEMANTIC_DIAGNOSTIC_CONTRACT_SHA256,
        },
        "registry": registry_identity(),
        "analysis": dict(metadata or {}),
        "type_definitions": list(definitions or []),
        "imports": list(imports or []),
        "modules": list(modules or []),
        "instructions": instructions,
        "capabilities": [
            "quantities",
            "uncertainty",
            "vectors",
            "pure_functions",
            "extended_nodes",
            "classified_evidence",
        ],
        "authority_effect": AUTHORITY_EFFECT,
        "physical_effect": PHYSICAL_EFFECT,
    }
    return JPIR({**basis, "program_root": digest(basis)})


def assigned_stage(kind: str, derive_index: int = 0) -> Stage:
    if kind in {"let", "var", "set", "measure", "role", "function", "evidence"}:
        return Stage.R1
    if kind == "derive":
        return Stage(f"N{min(7, 1 + derive_index)}")
    if kind == "require":
        return Stage.N8
    if kind in {"emit", "collect"}:
        return Stage.N9
    return Stage.N1
