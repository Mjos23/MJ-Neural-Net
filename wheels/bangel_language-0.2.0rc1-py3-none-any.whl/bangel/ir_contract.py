"""B03.2 closed JP-IR/1 admission, independent of Elsa's frontend.

Resource checks run before canonicalization or recursive semantic checking.
See docs/B03-2-JP-IR-CONTRACT.md for the frozen object and byte contracts.
"""
from __future__ import annotations

import re
from decimal import Context, Decimal, DecimalException, ROUND_HALF_EVEN, localcontext
from typing import Any

from .canonical import canonical_bytes
from .diagnostics import BangelDiagnostic
from .identity import (AUTHORITY_EFFECT, PHYSICAL_EFFECT, CANONICAL_PATH,
                       COMPILER_PROTOCOL, LANGUAGE_IDENTITY, EDGE_MODES)
from .ir_registry import verify_registered_instruction, verify_registered_value
from .topology import LOGICAL_NODES, canonical_stage
from .units import require_unit

MAX_BYTES = 16_777_216
MAX_NODES = 1_000_000
MAX_DEPTH = 128
MAX_STRING_BYTES = 1_048_576
MAX_ARRAY = 65_536
MAX_INSTRUCTIONS = 65_536
MAX_MODULES = 256
MAX_DEFINITIONS = 4096
MAX_POSITION = 2**31 - 1
IDENT = r'[A-Za-z_][A-Za-z0-9_]*'
QUALIFIED = IDENT + r'(?:\.' + IDENT + r')*'
ROOT_KEYS = set('profile identity source program effects canonical_path state_meanings compiler diagnostic_contract registry analysis type_definitions imports modules instructions capabilities authority_effect physical_effect program_root'.split())
MODULE_KEYS = set('name source effects imports exports analysis type_definitions instructions'.split())
ANALYSIS_KEYS = set('source_kind declared_effects inferred_effects maximum_call_depth call_depth_limit references conversions'.split())
CAPABILITIES = ['quantities', 'uncertainty', 'vectors', 'pure_functions', 'extended_nodes', 'classified_evidence']
STATE_MEANINGS = {'R1': 'Unidentified transition', 'R2': 'Living static', 'N1': 'First prediction node'}
REFERENCE_KINDS = {'let', 'derive', 'var', 'measure', 'evidence', 'parameter', 'capture', 'loop', 'pattern', 'refinement', 'function', 'intrinsic', 'record', 'enum_variant', 'type'}


def fail(code: str, message: str) -> None:
    raise BangelDiagnostic(code, message)


def check(condition: bool, code: str, message: str) -> None:
    if not condition:
        fail(code, message)


def exact(value: Any, keys: set[str], code='IR_SCHEMA') -> None:
    check(type(value) is dict and set(value) == keys, code,
          f'Object must have exactly these fields: {sorted(keys)}.')


def text(value: Any, pattern: str | None = None, *, nullable=False, code='IR_SCHEMA') -> None:
    if nullable and value is None:
        return
    check(type(value) is str and bool(value) and (pattern is None or re.fullmatch(pattern, value) is not None), code, 'Invalid text field.')


def integer(value: Any, low=0, high=MAX_POSITION, code='IR_SCHEMA') -> None:
    check(type(value) is int and low <= value <= high, code, f'Expected integer in {low}..{high}.')


def array(value: Any, code='IR_SCHEMA') -> None:
    check(type(value) is list, code, 'Expected an array.')


def preflight(value: Any) -> None:
    """Check exact JSON types, cycles, work/depth/size before any recursive work."""
    active: set[int] = set()
    stack = [(value, 0, False)]
    nodes = 0
    # Lower-bound accounting stops very large objects before JSON serialization.
    byte_floor = 0
    while stack:
        item, depth, leaving = stack.pop()
        kind = type(item)
        if leaving:
            active.remove(id(item))
            continue
        nodes += 1
        check(nodes <= MAX_NODES, 'IR_RESOURCE', 'JSON node budget exceeded.')
        if kind in (dict, list):
            depth += 1
            check(depth <= MAX_DEPTH, 'IR_RESOURCE', 'JSON container depth exceeded.')
            check(id(item) not in active, 'IR_SERIALIZATION', 'Cyclic objects are not JSON.')
            check(nodes + len(item) <= MAX_NODES, 'IR_RESOURCE', 'Container exceeds the remaining node budget.')
            active.add(id(item)); stack.append((item, depth, True))
            byte_floor += 2
            if kind is list:
                check(len(item) <= MAX_ARRAY, 'IR_RESOURCE', 'Array entry budget exceeded.')
                stack.extend((v, depth, False) for v in reversed(item))
            else:
                for key in item:
                    check(type(key) is str, 'IR_SERIALIZATION', 'Object keys must be strings.')
                    try: size = len(key.encode('utf-8', errors='strict'))
                    except UnicodeError: fail('IR_SERIALIZATION', 'Invalid Unicode scalar string.')
                    check(size <= MAX_STRING_BYTES, 'IR_RESOURCE', 'Object key byte budget exceeded.')
                    byte_floor += size + 3
                stack.extend((v, depth, False) for v in reversed(list(item.values())))
        elif kind is str:
            try: size = len(item.encode('utf-8', errors='strict'))
            except UnicodeError: fail('IR_SERIALIZATION', 'Invalid Unicode scalar string.')
            check(size <= MAX_STRING_BYTES, 'IR_RESOURCE', 'String byte budget exceeded.')
            byte_floor += size + 2
        elif kind is int:
            integer(item, -(2**63), 2**63 - 1, 'IR_RESOURCE')
            byte_floor += 1
        elif item is None or kind is bool:
            byte_floor += 4
        else:
            fail('IR_SERIALIZATION', 'Only exact JSON-native objects and scalars are admitted.')
        check(byte_floor <= MAX_BYTES, 'IR_RESOURCE', 'JSON byte budget exceeded.')
    check(len(canonical_bytes(value)) <= MAX_BYTES, 'IR_RESOURCE', 'Canonical byte budget exceeded.')


def wire_preflight(data: bytes) -> None:
    check(type(data) is bytes, 'IR_SERIALIZATION', 'JP-IR serialization input must be bytes.')
    check(len(data) <= MAX_BYTES, 'IR_RESOURCE', 'Wire byte budget exceeded.')
    depth = 0; quoted = False; escaped = False
    for byte in data:
        if quoted:
            if escaped: escaped = False
            elif byte == 92: escaped = True
            elif byte == 34: quoted = False
        elif byte == 34: quoted = True
        elif byte in (91, 123):
            depth += 1
            check(depth <= MAX_DEPTH, 'IR_RESOURCE', 'Wire container depth exceeded.')
        elif byte in (93, 125): depth -= 1


def span(value: Any, strict: bool) -> None:
    exact(value, {'line', 'column', 'end_column'}, 'IR_SPAN')
    integer(value['line'], 1, code='IR_SPAN')
    integer(value['column'], 1, code='IR_SPAN')
    if value['end_column'] is not None or strict:
        integer(value['end_column'], value['column'], code='IR_SPAN')


def effects(value: Any) -> None:
    check(value in (['pure'], ['pure', 'evidence']), 'IR_EFFECT', 'Effects must use the frozen pure/evidence order.')


def reference(value: Any) -> None:
    exact(value, {'span', 'source_name', 'symbol_kind', 'target'}, 'IR_PROVENANCE')
    span(value['span'], True)
    text(value['source_name'], QUALIFIED, code='IR_PROVENANCE')
    text(value['target'], QUALIFIED + '(?:#' + IDENT + ')?', code='IR_PROVENANCE')
    check(value['symbol_kind'] in REFERENCE_KINDS, 'IR_PROVENANCE', 'Unrecognized reference kind.')


def conversion(value: Any) -> None:
    exact(value, {'span', 'source_unit', 'target_unit', 'context'}, 'IR_PROVENANCE')
    span(value['span'], True)
    for key in ('source_unit', 'target_unit'):
        text(value[key], code='IR_PROVENANCE')
    text(value['context'], QUALIFIED, code='IR_PROVENANCE')
    check(value['source_unit'] != value['target_unit'], 'IR_PROVENANCE', 'Identity conversions are not emitted.')


class Contract:
    def __init__(self, root):
        self.root = root
        self.definitions = {}
        self.instructions = 0
        self.definition_count = 0
        self.units = {}
        self.constants = {}
        self.fact_indexes = {}

    def provenance(self, value, node_span, source, analysis, *, signed=False):
        check(type(value) is dict, 'IR_PROVENANCE', 'Provenance must be an object.')
        required = {'language', 'compiler', 'source', 'span'}
        allowed = required | {'reference', 'conversions'} | ({'role'} if signed else set())
        check(required <= set(value) <= allowed, 'IR_PROVENANCE', 'Provenance has missing or extra fields.')
        check(value['language'] == LANGUAGE_IDENTITY and value['compiler'] == COMPILER_PROTOCOL and value['source'] == source and value['span'] == node_span, 'IR_PROVENANCE', 'Provenance identity/source/span does not match its node.')
        if 'role' in value:
            check(value['role'] == 'signed_literal_magnitude', 'IR_PROVENANCE', 'Unrecognized provenance role.')
        if 'reference' in value:
            reference(value['reference'])
            check(value['reference']['span'] == node_span and canonical_bytes(value['reference']) in self.fact_indexes[id(analysis)][0], 'IR_PROVENANCE', 'Local reference does not match analysis.')
        if 'conversions' in value:
            array(value['conversions'], 'IR_PROVENANCE')
            check(bool(value['conversions']), 'IR_PROVENANCE', 'Empty optional conversions must be omitted.')
            for fact in value['conversions']:
                conversion(fact)
                check(fact['span'] == node_span and canonical_bytes(fact) in self.fact_indexes[id(analysis)][1], 'IR_PROVENANCE', 'Local conversion does not match analysis.')

    def typed(self, value):
        from .ir_types import verify_type
        verify_type(value, self.definitions)
        def collect(t):
            if 'unit' in t:
                self.units.setdefault(t['unit']['text'], set()).add(tuple(t['unit']['dimension']))
            for arg in t.get('arguments', []): collect(arg)
        collect(value)

    def field(self, value, source, analysis):
        exact(value, {'name', 'type', 'span', 'provenance'}, 'IR_DEFINITION')
        text(value['name'], IDENT, code='IR_DEFINITION'); self.typed(value['type'])
        span(value['span'], True)
        self.provenance(value['provenance'], value['span'], source, analysis)

    def definition(self, value, source, analysis):
        check(type(value) is dict and value.get('kind') in ('record', 'enum'), 'IR_DEFINITION', 'Unknown type definition kind.')
        field = 'fields' if value['kind'] == 'record' else 'variants'
        exact(value, {'kind', 'identity', 'name', 'exported', field, 'span', 'provenance'}, 'IR_DEFINITION')
        text(value['identity'], QUALIFIED, code='IR_DEFINITION'); text(value['name'], IDENT, code='IR_DEFINITION')
        check(type(value['exported']) is bool, 'IR_DEFINITION', 'Export marker must be Boolean.')
        span(value['span'], True); self.provenance(value['provenance'], value['span'], source, analysis)
        array(value[field], 'IR_DEFINITION')
        check(bool(value[field]), 'IR_DEFINITION', 'Definitions must contain at least one field or variant.')
        for item in value[field]:
            if field == 'fields': self.field(item, source, analysis)
            else:
                exact(item, {'name', 'fields', 'span', 'provenance'}, 'IR_DEFINITION')
                text(item['name'], IDENT, code='IR_DEFINITION'); span(item['span'], True)
                self.provenance(item['provenance'], item['span'], source, analysis)
                array(item['fields'], 'IR_DEFINITION')
                for f in item['fields']: self.field(f, source, analysis)

    def expression(self, value, strict, source, analysis, *, signed=False):
        check(type(value) is dict, 'IR_EXPRESSION', 'Expression must be an object.')
        verify_registered_value(value, strict=strict)
        span(value['span'], strict)
        if strict:
            self.typed(value['type'])
            self.provenance(value['provenance'], value['span'], source, analysis, signed=signed)
            if value['kind'] in {'name', 'reference'}:
                check('reference' in value['provenance'], 'IR_PROVENANCE', 'Resolved names require reference provenance.')
        for item in value.get('operands', []):
            self.expression(item, strict, source, analysis, signed=value['kind'] == 'unary' and value.get('value') == '-' and item.get('kind') == 'quantity')
        if strict:
            from .ir_types import verify_value_types
            verify_value_types(value, self.definitions)
        elif value['kind'] == 'quantity':
            raw = value['value']['magnitude']
            check(type(raw) is str and re.fullmatch(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?', raw) is not None, 'IR_QUANTITY', 'Invalid compatibility decimal spelling.')
            check(Decimal(raw).is_finite(), 'IR_QUANTITY', 'Nonfinite quantity.')
            require_unit(value['value']['unit'])
        if strict:
            self.constant(value)

    def constant(self, value):
        """Bounded independent literal arithmetic for statically decidable checks."""
        kind = value['kind']; result = None
        operands = value.get('operands', [])
        numbers = [self.constants.get(id(x)) for x in operands]
        try:
            with localcontext(Context(prec=34, Emin=-6143, Emax=6144, rounding=ROUND_HALF_EVEN)):
                if kind == 'quantity':
                    result = Decimal(value['value']['magnitude'])
                    if 'unit' in value['type']: result *= Decimal(value['type']['unit']['scale'])
                elif kind == 'unary' and numbers[0] is not None and value['value'] in ('+','-'):
                    result = numbers[0] if value['value'] == '+' else -numbers[0]
                elif kind in ('argument','map_entry'):
                    result = numbers[0]
                elif kind == 'mass_delta' and numbers[0] is not None:
                    result = numbers[0] * Decimal(value['type']['unit']['scale'])
                elif kind == 'binary' and all(x is not None for x in numbers):
                    a, b = numbers
                    operator = value['value']
                    if operator == '+': result = a + b
                    elif operator == '-': result = a - b
                    elif operator == '*': result = a * b
                    elif operator == '/':
                        check(b != 0, 'IR_SCALAR', 'Statically zero divisor.')
                        result = a / b
        except DecimalException as exc:
            raise BangelDiagnostic('IR_SCALAR', 'Static arithmetic exceeds the finite numeric contract.') from exc
        if result is not None and kind in ('binary','unary'):
            if value['type']['kind'] == 'Int':
                check(-(2**63) <= result <= 2**63 - 1 and result == result.to_integral_value(), 'IR_SCALAR', 'Static Int arithmetic exceeds Int64.')
        if result is not None and value['type']['kind'] == 'Quantity' and value['type']['unit']['dimension'] == [1,0,0,0,0]:
            check(result >= 0, 'IR_SCALAR', 'Static arithmetic cannot produce negative absolute mass.')
        self.constants[id(value)] = result

    def block(self, values, strict, source, analysis, prefix=(), *, nested=False):
        array(values, 'IR_INSTRUCTIONS'); derive_count = 0; inferred = {'pure'}
        nodes = set(); previous_node = 0
        for index, value in enumerate(values):
            self.instructions += 1
            check(self.instructions <= MAX_INSTRUCTIONS, 'IR_RESOURCE', 'Total instruction budget exceeded.')
            check(type(value) is dict, 'IR_INSTRUCTION', 'Instruction must be an object.')
            verify_registered_instruction(value, strict=strict)
            kind = value['kind']; details = value['details']; expr = value['expression']
            check(value['index'] == index and type(value['index']) is int, 'IR_PATH', 'Instruction index must match its sibling position.')
            if kind == 'legacy_operation':
                check(not strict and self.root['source']['profile'] == 'bangel 0.1', 'IR_INSTRUCTION_LANE', 'Legacy instruction outside legacy source.')
                integer(details['generation'], 0, 2**32 - 1, 'IR_RESOURCE')
                text(details['input_root'], '[0-9a-f]{64}', code='IR_LEGACY')
                check(details['compatibility'] == 'Bangel-0.1' and details['operation'] in ('observe resource', 'recommend hagar', 'verify receipt', 'acoustic transcript'), 'IR_LEGACY', 'Invalid legacy payload.')
                check(self.root['program'] == f"legacy_generation_{details['generation']}", 'IR_LEGACY', 'Legacy generation mismatch.')
                check(value['stage'] == f'N{min(index + 1, 7)}', 'IR_STAGE', 'Invalid legacy stage.')
                if index:
                    check(all(details[k] == values[0]['details'][k] for k in ('generation', 'input_root', 'compatibility')), 'IR_LEGACY', 'Legacy envelope fields disagree.')
                continue
            check(self.root['source']['profile'] != 'bangel 0.1', 'IR_INSTRUCTION_LANE', 'Nonlegacy instruction in legacy source.')
            expected_path = [*prefix, index]
            check(value['path'] == expected_path and all(type(x) in (int, str) for x in value['path']), 'IR_PATH', 'Instruction path must match its structural position.')
            span(value['span'], strict)
            if value['name'] is not None: text(value['name'], IDENT, code='IR_INSTRUCTION')
            if strict:
                self.provenance(value['provenance'], value['span'], source, analysis)
                if value['type'] is not None: self.typed(value['type'])
            expected_stage = ('R1' if kind in {'let','var','set','measure','role','function','evidence'} else 'N8' if kind == 'require' else 'N9' if kind in {'emit','collect'} else 'N1')
            if kind == 'derive':
                expected_stage = f'N{min(7, 1 + (0 if nested else derive_count))}'; derive_count += 1
            if kind in {'node', 'mirror'}:
                node = details['node'] if kind == 'node' else details['target']
                check(node in LOGICAL_NODES, 'IR_TOPOLOGY', 'Unknown logical node.')
                expected_stage = canonical_stage(node).value
                if kind == 'node':
                    check(details['mode'] in EDGE_MODES and node not in nodes, 'IR_TOPOLOGY', 'Invalid or duplicate node.')
                    order = list(LOGICAL_NODES).index(node) if node.startswith('N') else previous_node
                    check(order >= previous_node, 'IR_TOPOLOGY', 'Backward node order.'); previous_node = order; nodes.add(node)
                else:
                    check(details['source'] in LOGICAL_NODES, 'IR_TOPOLOGY', 'Unknown mirror source.')
                    text(details['kind'], IDENT, code='IR_TOPOLOGY')
                    check(list(CANONICAL_PATH).index(canonical_stage(details['source'])) <= list(CANONICAL_PATH).index(canonical_stage(node)), 'IR_TOPOLOGY', 'Backward mirror.')
            check(value['stage'] == expected_stage, 'IR_STAGE', 'Stage does not match its instruction.')
            if expr is not None: self.expression(expr, strict, source, analysis)
            if strict and kind in {'if', 'require'}:
                condition = expr['type']
                if condition['kind'] == 'Unknown': condition = condition['arguments'][0]
                check(condition == {'kind':'Bool','display':'Bool'}, 'IR_CONTROL', 'Condition must be Bool or Unknown[Bool].')
            local_effects = {'pure', 'evidence'} if kind in {'measure','evidence'} else {'pure'}
            if kind == 'measure':
                self.expression(details['uncertainty'], strict, source, analysis)
                if strict:
                    from .ir_types import assignable
                    container = value['type']; nominal = expr['type']; uncertainty = details['uncertainty']['type']
                    check(container['kind'] == 'Measurement' and nominal['kind'] != 'Unknown', 'IR_MEASUREMENT', 'Measurement requires a known nominal and explicit container type.')
                    underlying = container['arguments'][0]
                    check(assignable(nominal, underlying), 'IR_MEASUREMENT', 'Measurement nominal type mismatch.')
                    check(uncertainty['kind'] == 'Quantity' and uncertainty['unit']['dimension'] == underlying['unit']['dimension'], 'IR_MEASUREMENT', 'Measurement uncertainty must be an absolute Quantity of the nominal dimension.')
                    number = self.constants.get(id(details['uncertainty']))
                    check(number is None or number >= 0, 'IR_MEASUREMENT', 'Direct uncertainty cannot be negative.')
            elif kind == 'evidence':
                check(details['class'] in {'MODEL','SIMULATED','OBSERVED','EXTERNAL'}, 'IR_EFFECT', 'Unknown evidence class.')
            elif kind == 'require': text(details['code'], r'[A-Z][A-Z0-9_]*', code='IR_DIAGNOSTIC')
            elif kind == 'function':
                if strict:
                    check(set(details) == {'body','call_depth','call_depth_limit','captures','parameters','params','return_type','target'}, 'IR_DEFINITION', 'Strict function details are incomplete.')
                    integer(details['call_depth'], 1, 64, 'IR_RESOURCE'); check(type(details['call_depth_limit']) is int and details['call_depth_limit'] == 64, 'IR_RESOURCE', 'Function depth limit is frozen.')
                    self.typed(details['return_type']); text(details['target'], QUALIFIED, code='IR_DEFINITION')
                    for key in ('parameters', 'captures'):
                        array(details[key], 'IR_DEFINITION')
                        for item in details[key]: self.field(item, source, analysis)
                    actual = self.block(details['body'], strict, source, analysis, (*expected_path,'body'), nested=True)
                    check(actual == {'pure'}, 'IR_EFFECT', 'Functions cannot emit evidence.')
                else: check(set(details) == {'params'}, 'IR_DEFINITION', 'Compatibility function has only params.')
                array(details['params'], 'IR_DEFINITION')
                for name in details['params']: text(name, IDENT, code='IR_DEFINITION')
                check(len(details['params']) == len(set(details['params'])), 'IR_DEFINITION', 'Duplicate parameters.')
            elif kind == 'if':
                for arm in ('then','else'):
                    local_effects |= self.block(details[arm], strict, source, analysis, (*expected_path,arm), nested=True)
            elif kind == 'for':
                integer(details['limit'], 1, 65536, 'IR_RESOURCE'); self.typed(details['item_type'])
                local_effects |= self.block(details['body'], strict, source, analysis, (*expected_path,'body'), nested=True)
            elif kind == 'match':
                array(details['cases'], 'IR_MATCH')
                check(bool(details['cases']), 'IR_MATCH', 'Match must have cases.')
                for n, case in enumerate(details['cases']):
                    exact(case, {'tag','bindings','body','span'}, 'IR_MATCH'); span(case['span'], True)
                    for key in ('tag','bindings'):
                        array(case[key], 'IR_MATCH')
                        for name in case[key]: text(name, IDENT, code='IR_MATCH')
                    check(bool(case['tag']), 'IR_MATCH', 'Case tag must be nonempty.')
                    local_effects |= self.block(case['body'], strict, source, analysis, (*expected_path,'cases',n,'body'), nested=True)
            elif kind == 'collect':
                text(details['kind'], IDENT, code='IR_TOPOLOGY')
                check(details['node'] in nodes, 'IR_TOPOLOGY', 'Collect requires an earlier node.')
            if strict:
                check(value['effects'] == [x for x in ('pure','evidence') if x in local_effects], 'IR_EFFECT', 'Instruction effects do not match contained operations.')
            inferred |= local_effects
        return inferred

    def fragment(self, value, *, module=False):
        source = value['source']; exact(source, {'name','digest','profile'}, 'IR_SOURCE')
        text(source['name'], code='IR_SOURCE'); check(source['name'].endswith('.bangel'), 'IR_SOURCE', 'Source name must end in .bangel.')
        text(source['digest'], '[0-9a-f]{64}', code='IR_SOURCE')
        check(source['profile'] in ('bangel 1.0','bangel 1.1','bangel physics 0.1','bangel 0.1'), 'IR_SOURCE', 'Unknown source profile.')
        text(value['name'] if module else value['program'], QUALIFIED, code='IR_MODULE')
        effects(value['effects']); analysis = value['analysis']
        check(type(analysis) is dict, 'IR_ANALYSIS', 'Analysis must be an object.')
        strict = bool(analysis)
        if strict:
            exact(analysis, ANALYSIS_KEYS, 'IR_ANALYSIS')
            check(source['profile'] == 'bangel 1.0', 'IR_ANALYSIS', 'Strict analysis requires Bangel 1.0.')
            check(analysis['source_kind'] in ('program','module') and (not module or analysis['source_kind'] == 'module'), 'IR_ANALYSIS', 'Invalid source kind.')
            if analysis['source_kind'] == 'program':
                text(value['program'], IDENT, code='IR_SOURCE')
                check(bool(value['instructions']) or bool(value['type_definitions']), 'IR_SOURCE', 'Strict programs must not be empty.')
            effects(analysis['declared_effects']); effects(analysis['inferred_effects'])
            check(analysis['declared_effects'] == value['effects'], 'IR_EFFECT', 'Declared effects mismatch.')
            integer(analysis['maximum_call_depth'], 0, 64, 'IR_RESOURCE')
            check(type(analysis['call_depth_limit']) is int and analysis['call_depth_limit'] == 64, 'IR_RESOURCE', 'Call-depth limit is frozen.')
            for key, validator in (('references',reference), ('conversions',conversion)):
                array(analysis[key], 'IR_ANALYSIS')
                for fact in analysis[key]: validator(fact)
            self.fact_indexes[id(analysis)] = tuple({canonical_bytes(f) for f in analysis[key]} for key in ('references','conversions'))
        else:
            check(not module and not value['imports'] and not value['type_definitions'] and not value['modules'], 'IR_ANALYSIS', 'Compatibility cannot carry strict linkage.')
            if source['profile'] == 'bangel 0.1':
                check(value['effects'] == ['pure','evidence'] and bool(value['instructions']), 'IR_LEGACY', 'Legacy envelope mismatch.')
        array(value['type_definitions'], 'IR_DEFINITION'); array(value['imports'], 'IR_IMPORT')
        for d in value['type_definitions']: self.definition(d, source['name'], analysis)
        for imp in value['imports']:
            exact(imp, {'module','kind','alias','selection','span','provenance'}, 'IR_IMPORT')
            text(imp['module'], QUALIFIED, code='IR_IMPORT'); text(imp['alias'], IDENT, nullable=True, code='IR_IMPORT')
            check(imp['kind'] == ('standard' if imp['module'].startswith('std.') else 'project'), 'IR_IMPORT', 'Import kind mismatch.')
            array(imp['selection'], 'IR_IMPORT')
            for name in imp['selection']: text(name, IDENT, code='IR_IMPORT')
            check(imp['selection'] == sorted(set(imp['selection'])), 'IR_IMPORT', 'Selection must be sorted and unique.')
            span(imp['span'], True); self.provenance(imp['provenance'], imp['span'], source['name'], analysis)
        if module:
            array(value['exports'], 'IR_EXPORT')
            for exp in value['exports']:
                exact(exp, {'name','kind','type','mutable','exported','span','target','provenance'}, 'IR_EXPORT')
                text(exp['name'], IDENT, code='IR_EXPORT'); text(exp['target'], QUALIFIED, code='IR_EXPORT')
                check(exp['kind'] in {'let','derive','function','type'}, 'IR_EXPORT', 'Invalid exported symbol kind.')
                check(exp['mutable'] is False and exp['exported'] is True, 'IR_EXPORT', 'Exports must be marked immutable and exported.')
                if exp['kind'] == 'function': check(exp['type'] is None, 'IR_EXPORT', 'Function export has null value type.')
                else: self.typed(exp['type'])
                span(exp['span'], True); self.provenance(exp['provenance'], exp['span'], source['name'], analysis)
        inferred = self.block(value['instructions'], strict, source['name'], analysis)
        if strict:
            check(analysis['inferred_effects'] == [x for x in ('pure','evidence') if x in inferred] and inferred <= set(value['effects']), 'IR_EFFECT', 'Inferred or declared effects do not match the instructions.')

    def run(self):
        root = self.root
        exact(root, ROOT_KEYS, 'IR_ENVELOPE')
        exact(root['compiler'], {'name','protocol','version'}, 'COMPILER_IDENTITY')
        check(root['compiler'] == {'name':'Elsa','protocol':'Elsa/1','version':'0.3.0a2'}, 'COMPILER_IDENTITY', 'Compiler descriptor is not the frozen internal compiler.')
        check(root['canonical_path'] == [s.value for s in CANONICAL_PATH], 'IR_CANONICAL_PATH', 'Canonical traversal mismatch.')
        check(root['state_meanings'] == STATE_MEANINGS, 'IR_STATE_MEANINGS', 'State meanings mismatch.')
        check(root['capabilities'] == CAPABILITIES, 'IR_CAPABILITIES', 'Capability declaration mismatch.')
        check(root['authority_effect'] == AUTHORITY_EFFECT and root['physical_effect'] == PHYSICAL_EFFECT, 'IR_AUTHORITY', 'Authority and physical effects must remain NONE.')
        array(root['modules'], 'IR_MODULES'); check(len(root['modules']) <= MAX_MODULES, 'IR_RESOURCE', 'Module budget exceeded.')
        fragments = [*root['modules'], root]
        for module in root['modules']: exact(module, MODULE_KEYS, 'IR_MODULE')
        # Inventory definitions before any recursive type reference checks.
        for fragment in fragments:
            array(fragment['type_definitions'], 'IR_DEFINITION')
            for d in fragment['type_definitions']:
                check(type(d) is dict and type(d.get('identity')) is str, 'IR_DEFINITION', 'Definition requires identity.')
                check(d['identity'] not in self.definitions, 'IR_DEFINITION', 'Duplicate definition identity.')
                self.definitions[d['identity']] = d
                self.definition_count += 1
                check(self.definition_count <= MAX_DEFINITIONS, 'IR_RESOURCE', 'Definition budget exceeded.')
        for module in root['modules']: self.fragment(module, module=True)
        self.fragment(root)
        if root['modules']:
            check(root['analysis'].get('source_kind') == 'program', 'IR_MODULE', 'Linked project requires an entry program.')
        conversion_contexts = {'function_return','binding_initializer','set_assignment','measurement_nominal',
                               'measurement_uncertainty','evidence_initializer','vector_element','map_value',
                               'Result.Ok','Result.Err','binary_operand','comparison_operand','convert',
                               'function_call','enum_constructor','std.math.min','std.math.max',
                               'std.topology.node_variance','std.topology.shadow_speed'}
        for d in self.definitions.values():
            if d['kind'] == 'record':
                conversion_contexts.update(d['name'] + '.' + f['name'] for f in d['fields'])
            else:
                conversion_contexts.update(d['name'] + '.' + v['name'] + '.' + f['name'] for v in d['variants'] for f in v['fields'])
        for fragment in fragments:
            for fact in fragment['analysis'].get('conversions', []):
                check(fact['context'] in conversion_contexts, 'IR_PROVENANCE', 'Unknown conversion context.')
                left = self.units.get(fact['source_unit'], set())
                right = self.units.get(fact['target_unit'], set())
                check(bool(left & right), 'IR_PROVENANCE', 'Conversion units do not have an evidenced matching dimension.')
        from .ir_crossfields import verify_crossfields
        verify_crossfields(root)


def verify_contract(root):
    from .ir_types import unit_work_budget
    with unit_work_budget():
        Contract(root).run()
