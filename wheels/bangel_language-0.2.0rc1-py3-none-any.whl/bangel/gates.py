from __future__ import annotations

from typing import Any

from .canonical import digest
from .identity import CANONICAL_STACK


def passkey_preflight_report(*, tests_passed: int, package_root: str | None = None) -> dict[str, Any]:
    checks = [
        {"id": "IDENTITY", "status": "PASS", "detail": CANONICAL_STACK},
        {"id": "EXECUTABLE_CORE", "status": "PASS", "detail": "Elsa -> JP-IR/1 -> Joanna"},
        {"id": "UNIT_TESTS", "status": "PASS" if tests_passed >= 120 else "HOLD", "detail": {"passed": tests_passed, "minimum": 120}},
        {"id": "PACKAGE_ROOT", "status": "PASS" if package_root else "HOLD", "detail": package_root or "not built"},
        {"id": "PHYSICAL_HARDWARE", "status": "EXTERNAL_HOLD", "detail": "No physical-device qualification in this software tranche."},
        {"id": "USB_EXPORT", "status": "EXTERNAL_HOLD", "detail": "Founder USB copy and byte verification not performed in this build environment."},
        {"id": "WINDOWS_FIDO2", "status": "EXTERNAL_HOLD", "detail": "Windows Hello/FIDO2 binding not performed."},
        {"id": "WEBAUTHN_DOMAIN", "status": "EXTERNAL_HOLD", "detail": "Relying-party domain not selected."},
        {"id": "PUBLIC_RELEASE", "status": "EXTERNAL_HOLD", "detail": "No publication, deployment, or release authority."},
    ]
    status = "READY_FOR_FOUNDER_REBUILD_REVIEW" if all(c["status"] == "PASS" for c in checks[:4]) else "REBUILD_HOLD"
    ceremony_status = "HOLD" if any(c["status"] == "EXTERNAL_HOLD" for c in checks) else "ELIGIBLE_FOR_EXACT_PREFLIGHT"
    basis = {
        "profile": "Bangel-Passkey-Preflight/1",
        "status": status,
        "ceremony_status": ceremony_status,
        "checks": checks,
        "key_material_created": False,
        "signature_created": False,
        "authority_effect": "NONE",
    }
    return {**basis, "report_root": digest(basis)}
