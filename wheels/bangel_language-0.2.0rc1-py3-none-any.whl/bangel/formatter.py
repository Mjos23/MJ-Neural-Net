"""Comment-preserving presentation for the frozen source grammar.

Formatting never rewrites literal spelling or source meaning. Parsing the result
and comparing its syntax tree is a final guard against significant whitespace
changes (notably quantities and postfix expressions).
"""
from __future__ import annotations

from dataclasses import fields, is_dataclass

from .diagnostics import BangelDiagnostic
from .frontend.ast import UnitExpression, UnaryExpression
from .frontend.lexer import _normalized_text, _without_comment, lex
from .frontend.parser import parse_source
from .frontend.tokens import Token, TokenKind
from .source import MAX_SOURCE_BYTES


_OPEN = {'(', '[', '{'}
_CLOSE = {')', ']', '}'}
_BLOCKS = {'record', 'enum', 'function', 'if', 'for', 'match'}
_SPACED = {'=', '->', '+/-', '+', '-', '*', '/', '==', '!=', '<', '<=', '>', '>='}


def _shape(value):
    if isinstance(value, dict):
        return {key: _shape(child) for key, child in value.items() if key != 'span'}
    if isinstance(value, list):
        return [_shape(child) for child in value]
    return value


def _syntax_marks(tree, tokens: tuple[Token, ...]):
    """Locate unit-internal gaps and unary signs using the admitted AST."""
    positions = {(token.span.line, token.span.column): index for index, token in enumerate(tokens)}
    unit_gaps: set[tuple[int, int]] = set()
    unary: set[tuple[int, int]] = set()
    pending = [tree]
    while pending:
        node = pending.pop()
        if isinstance(node, UnitExpression):
            start = positions[(node.span.line, node.span.column)]
            cursor = start
            for index, _term in enumerate(node.terms):
                if index:
                    cursor += 1  # * or /
                cursor += 1  # unit symbol
                if tokens[cursor].text == '^':
                    cursor += 1
                    if tokens[cursor].text == '-':
                        cursor += 1
                    cursor += 1  # exponent
            unit_gaps.update((token.span.line, token.span.column) for token in tokens[start + 1:cursor])
        elif isinstance(node, UnaryExpression):
            unary.add((node.span.line, node.span.column))
        if is_dataclass(node):
            pending.extend(getattr(node, field.name) for field in fields(node) if field.name != 'span')
        elif isinstance(node, (tuple, list)):
            pending.extend(node)
    return unit_gaps, unary


def _spacing(previous: Token, token: Token, unit_gaps, unary) -> str:
    position = (token.span.line, token.span.column)
    previous_position = (previous.span.line, previous.span.column)
    if position in unit_gaps:
        return ''
    if token.text in _CLOSE | {',', ':', ';', '.'} or previous.text == '.':
        return ''
    if previous.text in _OPEN:
        return ''
    if previous_position in unary and previous.text in {'+', '-'}:
        return ''
    if token.text in {'(', '['}:
        # Postfix whitespace is significant. Type/function punctuation may be
        # compacted; the AST guard below confirms that it remains the same tree.
        return ' ' if previous.text in {'if', 'return', 'in', 'not', 'and', 'or'} or previous.text in _SPACED else ''
    if previous.text in {',', ':', ';'} or previous.text in _SPACED or token.text in _SPACED:
        return ' '
    return ' '


def format_source(source: str) -> str:
    normalized = _normalized_text(source)
    tokens = lex(normalized)
    meaningful = [token for token in tokens if token.kind not in {TokenKind.NEWLINE, TokenKind.EOF}]
    strict = len(meaningful) >= 2 and meaningful[0].text == 'bangel' and meaningful[1].text == '1.0'
    tree = parse_source(normalized) if strict else None
    unit_gaps, unary = _syntax_marks(tree, tokens) if tree is not None else (set(), set())
    by_line: dict[int, list[Token]] = {}
    for token in meaningful:
        by_line.setdefault(token.span.line, []).append(token)

    result: list[str] = []
    blocks: list[str] = []
    delimiter_depth = 0
    logical_head: str | None = None
    for number, physical in enumerate(normalized.split('\n'), 1):
        code = _without_comment(physical)
        comment = physical[len(code):].rstrip(' ')
        line_tokens = by_line.get(number, [])
        if not line_tokens and not comment:
            if result and result[-1] != '':
                result.append('')
            continue
        head = line_tokens[0].text if line_tokens else ''
        if delimiter_depth == 0 and line_tokens:
            logical_head = line_tokens[1].text if head == 'export' and len(line_tokens) > 1 else head
            if strict and head == 'end':
                if blocks and blocks[-1] == 'case':
                    blocks.pop()
                if blocks:
                    blocks.pop()
            elif strict and head == 'case' and blocks and blocks[-1] == 'case':
                blocks.pop()
        level = len(blocks) if strict else 0
        if strict and head == 'else' and delimiter_depth == 0:
            level = max(0, level - 1)
        continuation = delimiter_depth
        for token in line_tokens:
            if token.text in _CLOSE:
                continuation = max(0, continuation - 1)
            else:
                break
        pieces: list[str] = []
        for index, token in enumerate(line_tokens):
            if index:
                previous = line_tokens[index - 1]
                gap = _spacing(previous, token, unit_gaps, unary) if strict else (' ' if token.leading_space else '')
                pieces.append(gap)
            pieces.append(token.text)
        formatted = '  ' * (level + continuation) + ''.join(pieces)
        if comment:
            formatted += ('  ' if line_tokens else '') + comment
        result.append(formatted)
        for token in line_tokens:
            if token.text in _OPEN:
                delimiter_depth += 1
            elif token.text in _CLOSE:
                delimiter_depth -= 1
        if strict and line_tokens and delimiter_depth == 0:
            if logical_head in _BLOCKS or logical_head == 'case':
                blocks.append(logical_head)
            logical_head = None

    while result and result[-1] == '':
        result.pop()
    formatted_source = '\n'.join(result) + '\n'
    if len(formatted_source.encode('utf-8')) > MAX_SOURCE_BYTES:
        raise BangelDiagnostic('SOURCE_SIZE', f'Formatted source exceeds the {MAX_SOURCE_BYTES}-byte profile.')
    if tree is not None:
        try:
            same_tree = _shape(tree.to_dict()) == _shape(parse_source(formatted_source).to_dict())
        except BangelDiagnostic:
            same_tree = False
        if not same_tree:
            raise BangelDiagnostic('FORMAT_SEMANTICS', 'Formatting would change the source syntax tree.')
    return formatted_source
