from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from .diagnostics import BangelDiagnostic
from .units import (
    DIMENSIONLESS,
    MASS,
    Dimension,
    combine_dimensions,
    dimension_text,
    require_unit,
)


@dataclass(frozen=True, slots=True)
class Quantity:
    magnitude_si: Decimal | None
    dimension: Dimension = DIMENSIONLESS
    display_unit: str = "1"
    uncertainty_si: Decimal | None = None
    signed_delta: bool = False

    def __post_init__(self) -> None:
        if self.signed_delta and self.dimension != MASS:
            raise BangelDiagnostic(
                "MASS_DELTA_UNIT",
                "Signed mass delta requires a mass dimension.",
            )
        if (
            self.dimension == MASS
            and self.magnitude_si is not None
            and self.magnitude_si < 0
            and not self.signed_delta
        ):
            raise BangelDiagnostic(
                "NEGATIVE_MASS",
                "Negative physical mass is invalid; use a future signed mass-delta type for deltas.",
            )

    @classmethod
    def known(cls, magnitude: Decimal, unit_symbol: str = "1") -> "Quantity":
        unit = require_unit(unit_symbol)
        return cls(magnitude * unit.scale, unit.dimension, unit_symbol)

    @classmethod
    def unknown(cls, unit_symbol: str = "1") -> "Quantity":
        unit = require_unit(unit_symbol)
        return cls(None, unit.dimension, unit_symbol)

    @classmethod
    def mass_delta(cls, magnitude: Decimal, unit_symbol: str = "mg") -> "Quantity":
        unit = require_unit(unit_symbol)
        if unit.dimension != MASS:
            raise BangelDiagnostic("MASS_DELTA_UNIT", "Signed mass delta requires a mass unit.")
        return cls(magnitude * unit.scale, unit.dimension, unit_symbol, signed_delta=True)

    @property
    def is_unknown(self) -> bool:
        return self.magnitude_si is None

    def with_uncertainty(self, uncertainty: "Quantity") -> "Quantity":
        self._same_dimension(uncertainty)
        if uncertainty.is_unknown or uncertainty.magnitude_si is None:
            raise BangelDiagnostic("UNCERTAINTY_UNKNOWN", "Uncertainty must be known.")
        if uncertainty.magnitude_si < 0:
            raise BangelDiagnostic("UNCERTAINTY_NEGATIVE", "Uncertainty cannot be negative.")
        return Quantity(
            self.magnitude_si,
            self.dimension,
            self.display_unit,
            uncertainty.magnitude_si,
            self.signed_delta,
        )

    def _same_dimension(self, other: "Quantity") -> None:
        if self.dimension != other.dimension:
            raise BangelDiagnostic(
                "DIMENSION_MISMATCH",
                f"{dimension_text(self.dimension)} is not compatible with {dimension_text(other.dimension)}.",
            )

    def add(self, other: "Quantity", sign: int = 1) -> "Quantity":
        self._same_dimension(other)
        if self.is_unknown or other.is_unknown:
            return Quantity.unknown(self.display_unit)
        assert self.magnitude_si is not None and other.magnitude_si is not None
        uncertainty = None
        if self.uncertainty_si is not None or other.uncertainty_si is not None:
            uncertainty = (self.uncertainty_si or Decimal(0)) + (other.uncertainty_si or Decimal(0))
        return Quantity(
            self.magnitude_si + sign * other.magnitude_si,
            self.dimension,
            self.display_unit,
            uncertainty,
            self.signed_delta and other.signed_delta,
        )

    def multiply(self, other: "Quantity", divide: bool = False) -> "Quantity":
        dimension = combine_dimensions(self.dimension, other.dimension, -1 if divide else 1)
        if divide and other.magnitude_si == 0:
            raise BangelDiagnostic("DIVISION_ZERO", "Division by zero is not admitted.")
        if self.uncertainty_si is not None or other.uncertainty_si is not None:
            raise BangelDiagnostic(
                "UNCERTAINTY_PROPAGATION_POLICY",
                "Multiplication or division with measurement uncertainty requires an approved propagation policy.",
            )
        signed_delta = dimension == MASS and (
            (self.signed_delta and other.dimension == DIMENSIONLESS)
            or (not divide and other.signed_delta and self.dimension == DIMENSIONLESS)
        )
        if self.is_unknown or other.is_unknown:
            return Quantity(None, dimension, "1", signed_delta=signed_delta)
        assert self.magnitude_si is not None and other.magnitude_si is not None
        magnitude = self.magnitude_si / other.magnitude_si if divide else self.magnitude_si * other.magnitude_si
        return Quantity(magnitude, dimension, "1", signed_delta=signed_delta)

    def negate(self) -> "Quantity":
        if self.is_unknown:
            return self
        assert self.magnitude_si is not None
        return Quantity(
            -self.magnitude_si,
            self.dimension,
            self.display_unit,
            self.uncertainty_si,
            self.signed_delta,
        )

    def compare(self, other: "Quantity", operator: str) -> bool | None:
        self._same_dimension(other)
        if self.is_unknown or other.is_unknown:
            return None
        assert self.magnitude_si is not None and other.magnitude_si is not None
        return {
            "==": self.magnitude_si == other.magnitude_si,
            "!=": self.magnitude_si != other.magnitude_si,
            "<": self.magnitude_si < other.magnitude_si,
            "<=": self.magnitude_si <= other.magnitude_si,
            ">": self.magnitude_si > other.magnitude_si,
            ">=": self.magnitude_si >= other.magnitude_si,
        }[operator]

    def to(self, unit_symbol: str) -> Decimal | None:
        unit = require_unit(unit_symbol)
        if unit.dimension != self.dimension:
            raise BangelDiagnostic("DIMENSION_MISMATCH", "Cannot convert across dimensions.")
        if self.magnitude_si is None:
            return None
        return self.magnitude_si / unit.scale

    def to_dict(self) -> dict[str, Any]:
        if self.display_unit == "1" and self.dimension != DIMENSIONLESS:
            value = self.magnitude_si
            unit_scale = Decimal("1")
            rendered_unit = dimension_text(self.dimension)
        else:
            value = self.to(self.display_unit)
            unit_scale = require_unit(self.display_unit).scale
            rendered_unit = self.display_unit
        uncertainty = None
        if self.uncertainty_si is not None:
            uncertainty = format(self.uncertainty_si / unit_scale, "f")
        return {
            "kind": "mass_delta" if self.signed_delta else "quantity",
            "value": None if value is None else format(value, "f"),
            "unit": rendered_unit,
            "dimension": dimension_text(self.dimension),
            "uncertainty": uncertainty,
            "unknown": self.is_unknown,
        }


def evidence_value(value: Any) -> Any:
    if isinstance(value, Quantity):
        return value.to_dict()
    if isinstance(value, tuple):
        return [evidence_value(item) for item in value]
    if isinstance(value, dict):
        return {key: evidence_value(item) for key, item in sorted(value.items())}
    return value
