from __future__ import annotations

from dataclasses import dataclass
import heapq
from typing import Any, Callable, Iterable

from .canonical import canonical_bytes, digest
from .diagnostics import BangelDiagnostic
from .ir import JPIR
from .receipts import verify_receipt
from .runtime import JoannaRuntime

RUNTIME_LIMITS = ('instruction_limit', 'event_limit', 'function_depth', 'evaluation_limit', 'allocation_limit', 'output_limit', 'receipt_limit')
MAX_JOBS = 65536
MAX_REPORT_BYTES = 16777216
MAX_PLAN_BYTES = 16777216


@dataclass(frozen=True, slots=True)
class ScheduledJob:
    job_id: str
    compilation: dict[str, Any]
    depends_on: tuple[str, ...] = ()
    limits: dict[str, int] | None = None


class JoannaScheduler:
    def __init__(self, *, max_jobs: int = 256, runtime: JoannaRuntime | None = None):
        if type(max_jobs) is not int or not 1 <= max_jobs <= MAX_JOBS:
            raise BangelDiagnostic('SCHEDULER_LIMIT', f'Scheduler job limit must be an integer in 1..{MAX_JOBS}.')
        if runtime is not None and not isinstance(runtime, JoannaRuntime):
            raise BangelDiagnostic("SCHEDULER_RUNTIME", "Scheduler requires a JoannaRuntime instance.")
        self.max_jobs = max_jobs
        self.runtime = runtime or JoannaRuntime()

    def run(self, jobs: Iterable[ScheduledJob], *, cancelled: Callable[[], bool] | None = None) -> dict[str, Any]:
        if cancelled is not None and not callable(cancelled):
            raise BangelDiagnostic('SCHEDULER_CANCEL', 'Cancellation must be a callback.')
        # Do not materialize an unbounded iterable before enforcing max_jobs.
        queued = []
        for job in jobs:
            if len(queued) >= self.max_jobs:
                raise BangelDiagnostic('SCHEDULER_LIMIT', f'Scheduler exceeds {self.max_jobs} jobs.')
            queued.append(job)
        by_id = {}
        effective = {}
        edge_count = 0
        parent_limits = {key: getattr(self.runtime, key) for key in RUNTIME_LIMITS}
        for job in queued:
            if type(job) is not ScheduledJob or type(job.job_id) is not str or not job.job_id:
                raise BangelDiagnostic('SCHEDULER_JOB', 'Jobs require a nonempty Text identifier.')
            try:
                valid_name = len(job.job_id.encode('utf-8')) <= 256
            except UnicodeError:
                valid_name = False
            if not valid_name or job.job_id in by_id:
                raise BangelDiagnostic('SCHEDULER_JOB', 'Job identifiers must be unique Unicode scalar text of at most 256 UTF-8 bytes.')
            if type(job.depends_on) is not tuple or len(job.depends_on) > self.max_jobs or any(type(item) is not str or not item for item in job.depends_on):
                raise BangelDiagnostic('SCHEDULER_DEPENDENCY', 'Dependencies must be a tuple of job identifiers.')
            edge_count += len(job.depends_on)
            if edge_count > MAX_JOBS:
                raise BangelDiagnostic('SCHEDULER_LIMIT', 'Dependency graph exceeds its 65,536-edge ceiling.')
            if len(job.depends_on) > self.max_jobs or len(set(job.depends_on)) != len(job.depends_on):
                raise BangelDiagnostic('SCHEDULER_DEPENDENCY', 'Dependencies must be bounded and unique.')
            if job.limits is not None:
                if type(job.limits) is not dict or any(type(key) is not str or key not in RUNTIME_LIMITS for key in job.limits):
                    raise BangelDiagnostic('SCHEDULER_LIMIT', 'Unknown per-job runtime limit.')
                if any(type(value) is not int or not 1 <= value <= parent_limits[key] for key, value in job.limits.items()):
                    raise BangelDiagnostic('SCHEDULER_LIMIT', 'Per-job limits must be positive integers no greater than the scheduler runtime limits.')
            by_id[job.job_id] = job
            effective[job.job_id] = {**parent_limits, **(job.limits or {})}

        incoming = {key: len(job.depends_on) for key, job in by_id.items()}
        dependents = {key: [] for key in by_id}
        for job in queued:
            for dependency in job.depends_on:
                if dependency not in by_id:
                    raise BangelDiagnostic('SCHEDULER_DEPENDENCY', f'Job {job.job_id!r} has a missing dependency {dependency!r}.')
                dependents[dependency].append(job.job_id)
        ready = [key for key, count in incoming.items() if count == 0]
        heapq.heapify(ready)
        ordered = []
        while ready:
            key = heapq.heappop(ready)
            ordered.append(key)
            for child in dependents[key]:
                incoming[child] -= 1
                if incoming[child] == 0:
                    heapq.heappush(ready, child)
        if len(ordered) != len(queued):
            raise BangelDiagnostic('SCHEDULER_CYCLE', 'Job dependencies contain a cycle.')
        # Admission of the whole plan precedes every runtime execution.
        plan_bytes = 0
        for job in queued:
            JPIR(job.compilation).verify()
            plan_bytes += len(canonical_bytes(job.compilation))
            if plan_bytes > MAX_PLAN_BYTES:
                raise BangelDiagnostic('SCHEDULER_LIMIT', 'Verified job programs exceed the 16 MiB aggregate plan ceiling.')

        extended = cancelled is not None or any(job.depends_on or job.limits is not None for job in queued)
        results = []
        completed = {}
        report_bytes = 0
        for key in ordered:
            job = by_id[key]
            if not extended:
                receipt = self.runtime.execute(job.compilation).to_dict()
                verify_receipt(receipt)
                if receipt['program_root'] != job.compilation['program_root']:
                    raise BangelDiagnostic('SCHEDULER_RECEIPT', 'Job receipt is linked to another program.')
                record = {'job_id': key, 'status': receipt['status'], 'receipt_root': receipt['receipt_root']}
            else:
                blocked = sorted(dependency for dependency in job.depends_on if completed[dependency]['status'] != 'PASS')
                receipt = None
                diagnostic = None
                if blocked:
                    diagnostic = BangelDiagnostic('DEPENDENCY_HOLD', 'A required job did not pass.', details={'dependencies': blocked}).to_dict()
                else:
                    runtime = self.runtime if job.limits is None else JoannaRuntime(**effective[key])
                    try:
                        receipt = runtime.execute(job.compilation, cancelled=cancelled).to_dict()
                        verify_receipt(receipt)
                        if receipt['program_root'] != job.compilation['program_root']:
                            raise BangelDiagnostic('SCHEDULER_RECEIPT', 'Job receipt is linked to another program.')
                    except BangelDiagnostic as exc:
                        diagnostic = exc.to_dict()
                        receipt = None
                record = {
                    'job_id': key,
                    'depends_on': sorted(job.depends_on),
                    'program_root': job.compilation['program_root'],
                    'runtime_limits': effective[key],
                    'status': receipt['status'] if receipt is not None else 'HOLD',
                    'hold_code': receipt['hold_code'] if receipt is not None else diagnostic['code'],
                    'diagnostic': diagnostic,
                    'receipt_root': receipt['receipt_root'] if receipt is not None else None,
                    'receipt': receipt,
                }
                completed[key] = record
            report_bytes += len(canonical_bytes(record))
            if report_bytes > MAX_REPORT_BYTES:
                raise BangelDiagnostic('SCHEDULER_LIMIT', 'Schedule report exceeds its 16 MiB byte ceiling.')
            results.append(record)
        basis = {
            'profile': 'Joanna-Schedule/1',
            'order': 'dependency_topological_job_id_ascending' if extended else 'job_id_ascending',
            'jobs': results,
            'authority_effect': 'NONE',
            'physical_effect': 'NONE',
        }
        if extended:
            basis.update(status='PASS' if all(item['status'] == 'PASS' for item in results) else 'HOLD', resource_limits={'max_jobs': self.max_jobs, 'jobs_used': len(results), 'report_byte_limit': MAX_REPORT_BYTES}, capabilities=[])
        result = {**basis, 'schedule_root': digest(basis)}
        if len(canonical_bytes(result)) > MAX_REPORT_BYTES:
            raise BangelDiagnostic('SCHEDULER_LIMIT', 'Schedule report exceeds its 16 MiB byte ceiling.')
        return result
