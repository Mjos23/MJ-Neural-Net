from __future__ import annotations

import re

from .ast import Program, Statement
from .diagnostics import BangelDiagnostic, SourceSpan
from .expression import parse_expression
from .identity import EDGE_MODES, EXTENDED_NODES
from .source import SourceLine, logical_lines


_NAME = r"[A-Za-z_][A-Za-z0-9_]*"
_LOGICAL_NODE = rf"(?:N[1-9]|{'|'.join(EXTENDED_NODES)})"
_PROGRAM = re.compile(rf"program (?P<name>{_NAME})")
_BIND = re.compile(rf"(?P<kind>let|var|derive) (?P<name>{_NAME}) = (?P<expr>.+)")
_SET = re.compile(rf"set (?P<name>{_NAME}) = (?P<expr>.+)")
_FUNCTION = re.compile(rf"function (?P<name>{_NAME})\((?P<params>[^)]*)\) = (?P<expr>.+)")
_MEASURE = re.compile(rf"measure (?P<name>{_NAME}) = (?P<expr>.+)")
_EVIDENCE = re.compile(rf"evidence (?P<class>model|simulated|observed|external) (?P<name>{_NAME}) = (?P<expr>.+)")
_REQUIRE = re.compile(r"require (?P<expr>.+) else (?P<code>[A-Z][A-Z0-9_]*)")
_EMIT = re.compile(rf"emit (?:(?P<name>{_NAME}) = )?(?P<expr>.+)")
_NODE = re.compile(rf"node (?P<node>{_LOGICAL_NODE}) (?P<mode>{'|'.join(x.lower() for x in EDGE_MODES)}) (?P<expr>.+)")
_MIRROR = re.compile(rf"mirror (?P<kind>{_NAME}) from (?P<source>{_LOGICAL_NODE}) to (?P<target>{_LOGICAL_NODE}) value (?P<expr>.+)")
_COLLECT = re.compile(rf"collect (?P<kind>{_NAME}) from (?P<node>{_LOGICAL_NODE}) as (?P<name>{_NAME})")
_ROLE = re.compile(rf"role (?P<name>{_NAME}) = (?P<expr>.+)")


def _statement(line: SourceLine) -> Statement:
    text = line.text
    span = SourceSpan(line.number)
    match = _BIND.fullmatch(text)
    if match:
        return Statement(match["kind"], match["name"], parse_expression(match["expr"], line.number), span=span)
    match = _SET.fullmatch(text)
    if match:
        return Statement("set", match["name"], parse_expression(match["expr"], line.number), span=span)
    match = _FUNCTION.fullmatch(text)
    if match:
        raw = match["params"].strip()
        params = tuple(part.strip() for part in raw.split(",")) if raw else ()
        if any(re.fullmatch(_NAME, param) is None for param in params):
            raise BangelDiagnostic("FUNCTION_PARAMETER", "Function parameters must be identifiers.", span)
        if len(set(params)) != len(params):
            raise BangelDiagnostic("FUNCTION_PARAMETER_DUPLICATE", "Function parameters must be unique.", span)
        return Statement(
            "function",
            match["name"],
            parse_expression(match["expr"], line.number),
            {"params": params},
            span,
        )
    match = _MEASURE.fullmatch(text)
    if match:
        expression_text = match["expr"]
        separator = "±" if "±" in expression_text else "+/-" if "+/-" in expression_text else None
        uncertainty = None
        if separator:
            expression_text, uncertainty_text = (part.strip() for part in expression_text.split(separator, 1))
            uncertainty = parse_expression(uncertainty_text, line.number).to_ir()
        return Statement(
            "measure",
            match["name"],
            parse_expression(expression_text, line.number),
            {"uncertainty": uncertainty},
            span,
        )
    match = _EVIDENCE.fullmatch(text)
    if match:
        return Statement(
            "evidence",
            match["name"],
            parse_expression(match["expr"], line.number),
            {"class": match["class"].upper()},
            span,
        )
    match = _REQUIRE.fullmatch(text)
    if match:
        return Statement("require", expression=parse_expression(match["expr"], line.number), details={"code": match["code"]}, span=span)
    match = _EMIT.fullmatch(text)
    if match:
        return Statement("emit", match["name"], parse_expression(match["expr"], line.number), span=span)
    match = _NODE.fullmatch(text)
    if match:
        return Statement(
            "node",
            expression=parse_expression(match["expr"], line.number),
            details={"node": match["node"], "mode": match["mode"].upper()},
            span=span,
        )
    match = _MIRROR.fullmatch(text)
    if match:
        return Statement(
            "mirror",
            expression=parse_expression(match["expr"], line.number),
            details={key: match[key] for key in ("kind", "source", "target")},
            span=span,
        )
    match = _COLLECT.fullmatch(text)
    if match:
        return Statement(
            "collect",
            match["name"],
            details={key: match[key] for key in ("kind", "node")},
            span=span,
        )
    match = _ROLE.fullmatch(text)
    if match:
        return Statement("role", match["name"], parse_expression(match["expr"], line.number), span=span)
    if text.startswith(("passkey ", "sign ", "publish ", "deploy ")):
        raise BangelDiagnostic(
            "AUTHORITY_SYNTAX",
            "Authority, signing, publication, deployment, and passkey actions are not language syntax.",
            span,
        )
    raise BangelDiagnostic("STATEMENT_UNKNOWN", f"Unknown statement {text!r}.", span)


def parse_program(source: str) -> Program:
    lines = logical_lines(source)
    if lines[0].text not in {"bangel 1.0", "bangel 1.1", "bangel physics 0.1"}:
        raise BangelDiagnostic(
            "PROFILE_HEADER",
            "Source must begin with 'bangel 1.0', 'bangel 1.1', or 'bangel physics 0.1'.",
            SourceSpan(lines[0].number),
        )
    if len(lines) < 3:
        raise BangelDiagnostic("PROGRAM_SHORT", "A program requires at least one statement.")
    declaration = lines[1]
    if lines[0].text == "bangel physics 0.1":
        if not declaration.text.startswith("experiment "):
            raise BangelDiagnostic("EXPERIMENT_DECLARATION", "Physics profile requires an experiment declaration.", SourceSpan(declaration.number))
        name = declaration.text.removeprefix("experiment ")
        if re.fullmatch(_NAME, name) is None:
            raise BangelDiagnostic("PROGRAM_NAME", "Invalid experiment name.", SourceSpan(declaration.number))
    else:
        match = _PROGRAM.fullmatch(declaration.text)
        if match is None:
            raise BangelDiagnostic("PROGRAM_DECLARATION", "Bangel requires 'program <name>'.", SourceSpan(declaration.number))
        name = match["name"]
    index = 2
    effects = ("pure",)
    if index < len(lines) and lines[index].text.startswith("effects "):
        effects = tuple(part.strip() for part in lines[index].text.removeprefix("effects ").split(","))
        allowed = {"pure", "evidence"}
        if not effects or any(effect not in allowed for effect in effects):
            raise BangelDiagnostic("EFFECT_UNKNOWN", "Effects are limited to pure and evidence.", SourceSpan(lines[index].number))
        index += 1
    statements = tuple(_statement(line) for line in lines[index:])
    if not statements:
        raise BangelDiagnostic("PROGRAM_EMPTY", "A program requires at least one statement.")
    return Program(lines[0].text, name, effects, statements)
