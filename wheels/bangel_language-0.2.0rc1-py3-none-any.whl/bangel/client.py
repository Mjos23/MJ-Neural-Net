"""Local BANGEL-API/1 stdio adapter. Language behavior belongs to the service."""
from __future__ import annotations
import asyncio
import json
import queue
import subprocess
import threading
from typing import Any, Sequence
from bangel.api import make_request, decode_frame, validate_response
from bangel.ir_contract import preflight

MAX_FRAME_BYTES = 16 * 1024 * 1024

class ProtocolError(ValueError):
    """The peer violated BANGEL-API/1 or closed before replying."""

class Client:
    """Persistent, bounded stdio session. Cancellation terminates this session.

    ``argv`` is passed directly to Popen, never a shell. A transport timeout closes
    the session and reaps the peer. Create a new client to recover.
    """
    def __init__(self, argv: Sequence[str], *, timeout: float = 15.0,
                 max_frame_bytes: int = MAX_FRAME_BYTES):
        if not argv or isinstance(argv, (str, bytes)):
            raise ValueError('argv must be a nonempty argument sequence')
        if timeout <= 0 or not 1 <= max_frame_bytes <= MAX_FRAME_BYTES:
            raise ValueError('invalid transport bounds')
        self.timeout, self.max_frame_bytes = timeout, max_frame_bytes
        self.process = subprocess.Popen(list(argv), stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self._pending: dict[str, tuple[dict, queue.Queue]] = {}
        self._lock = threading.Lock()
        self._outgoing: queue.Queue = queue.Queue()
        self._closed = False
        threading.Thread(target=self._read, daemon=True).start()
        threading.Thread(target=self._write, daemon=True).start()

    def _fail(self, error: Exception):
        with self._lock:
            pending = list(self._pending.values()); self._pending.clear()
            self._closed = True
        for _, answer in pending: answer.put(error)
        self._outgoing.put(None)
        if self.process.poll() is None:
            self.process.terminate()
            try: self.process.wait(timeout=0.5)
            except subprocess.TimeoutExpired: self.process.kill()
        self.process.wait(timeout=2)

    def _read(self):
        try:
            while True:
                line = self.process.stdout.readline(self.max_frame_bytes + 2)
                if not line:
                    raise ProtocolError('peer closed without a complete response')
                if not line.endswith(b'\n') or len(line) - 1 > self.max_frame_bytes:
                    raise ProtocolError('response exceeds frame limit or lacks newline')
                response = decode_frame(line[:-1])
                if not isinstance(response, dict): raise ProtocolError('response is not an object')
                with self._lock:
                    pending = self._pending.get(response.get('id'))
                if pending is None: raise ProtocolError('unsolicited response ID')
                request, answer = pending
                validate_response(response, request)
                with self._lock: self._pending.pop(response.get('id'), None)
                answer.put(response)
        except Exception as exc:
            self._fail(exc if isinstance(exc, ProtocolError) else ProtocolError(str(exc)))

    def _write(self):
        try:
            while True:
                data = self._outgoing.get()
                if data is None: return
                self.process.stdin.write(data)
                self.process.stdin.flush()
        except Exception as exc:
            self._fail(ProtocolError(str(exc)))

    def request(self, request: dict[str, Any], *, timeout: float | None = None) -> dict[str, Any]:
        preflight(request)
        request_id = request.get('id')
        if not isinstance(request_id, str) or not request_id or len(request_id.encode('utf-8')) > 128:
            request_id = None
        data = json.dumps(request, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf-8')
        if len(data) > self.max_frame_bytes: raise ValueError('request exceeds transport frame limit')
        answer: queue.Queue = queue.Queue(maxsize=1)
        with self._lock:
            if self._closed: raise ProtocolError('client is closed')
            if request_id in self._pending: raise ValueError('request ID already pending')
            self._pending[request_id] = (decode_frame(data), answer)
        self._outgoing.put(data + b'\n')
        try: result = answer.get(timeout=self.timeout if timeout is None else timeout)
        except queue.Empty:
            self.close()
            raise TimeoutError('BANGEL-API/1 transport deadline exceeded') from None
        if isinstance(result, Exception): raise result
        return result

    def call(self, operation: str, input: dict | None = None, **options) -> dict:
        return self.request(make_request(operation, input, **options))

    def identity(self) -> dict:
        return self.call('identity')

    def check(self, text: str, *, name: str = 'input.bangel', **options) -> dict:
        return self.call('check', {'source': {'name': name, 'text': text}}, **options)

    def compile(self, text: str, *, name: str = 'input.bangel', **options) -> dict:
        return self.call('compile', {'source': {'name': name, 'text': text}}, **options)

    def run(self, text: str, *, name: str = 'input.bangel', **options) -> dict:
        return self.call('run', {'source': {'name': name, 'text': text}}, **options)

    def cancel(self) -> None:
        """Terminate and reap this local session; no ninth wire operation exists."""
        self.close()

    def close(self):
        self._fail(ProtocolError('client closed'))
        for stream in (self.process.stdin, self.process.stdout):
            if stream is not None: stream.close()

    def __enter__(self): return self
    def __exit__(self, *args): self.close()


class AsyncClient:
    """Async facade over the same bounded process client and response validator."""
    def __init__(self, argv: Sequence[str], **options): self.client = Client(argv, **options)
    async def request(self, request: dict, **options) -> dict:
        try: return await asyncio.to_thread(self.client.request, request, **options)
        except asyncio.CancelledError:
            await self.close()
            raise
    async def call(self, operation: str, input: dict | None = None, **options) -> dict:
        return await self.request(make_request(operation, input, **options))
    async def cancel(self): await asyncio.to_thread(self.client.cancel)
    async def close(self): await asyncio.to_thread(self.client.close)
    async def __aenter__(self): return self
    async def __aexit__(self, *args): await self.close()
