"""Closed Joanna-Receipt/1 admission, without evaluation or host authority.

Digest integrity is not authorship. Source/IR-dependent facts are checked by
replay; this module checks every represented field and represented cross-link.
"""
from __future__ import annotations

from collections import Counter
from decimal import Decimal, DecimalException
import re

from .canonical import canonical_bytes
from .diagnostics import BangelDiagnostic
from .identity import CANONICAL_PATH, PREDICTION_NODES, EDGE_MODES, EXTENDED_NODES, Stage
from .state import STATE_MEANINGS
from .units import UNITS, MASS, dimension_text

MAX_BYTES = 16777216
MAX_NODES = 1000000
MAX_DEPTH = 128
MAX_STRING_BYTES = 1048576
MAX_ARRAY = 65536
NAME = r'[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)*'
CODE = r'[A-Z][A-Z0-9_]*'
HEX = r'[0-9a-f]{64}'
NUMBER = r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:E[+-][1-9][0-9]*)?'
STAGES = [x.value for x in CANONICAL_PATH]
OLD_LIMITS = {'instruction_limit', 'event_limit', 'function_depth', 'evaluation_limit', 'evaluations_used'}
NEW_LIMITS = OLD_LIMITS | {'allocation_limit', 'output_limit', 'receipt_limit', 'instructions_used', 'events_used', 'allocations_used', 'output_bytes', 'function_depth_used'}
ROOT_KEYS = {'profile', 'runtime', 'program', 'program_root', 'status', 'hold_code', 'outputs', 'roles', 'evidence', 'events', 'traversal', 'resource_limits', 'state_meanings', 'prediction_nodes', 'authority_effect', 'physical_effect', 'receipt_root'}


def check(condition, message, code='RECEIPT_SHAPE'):
    if not condition:
        raise BangelDiagnostic(code, message)


def exact(value, keys, code='RECEIPT_SHAPE'):
    check(type(value) is dict and set(value) == set(keys), 'Receipt object has missing or extra fields.', code)


def text(value, pattern=None, *, empty=False, code='RECEIPT_SHAPE'):
    check(type(value) is str and (empty or bool(value)), 'Receipt text is invalid.', code)
    if pattern is not None:
        check(re.fullmatch(pattern, value) is not None, 'Receipt text spelling is invalid.', code)


def integer(value, lower=0, upper=2**63-1, code='RECEIPT_LIMITS'):
    check(type(value) is int and lower <= value <= upper, 'Receipt integer is outside its allowed range.', code)


def preflight(root):
    """Bound native objects before recursive hashing, parsing, or serialization."""
    stack = [(root, 0, False)]
    active = set()
    count = 0
    estimated_bytes = 0
    while stack:
        value, depth, leaving = stack.pop()
        if leaving:
            active.remove(id(value)); continue
        count += 1
        check(count <= MAX_NODES and depth <= MAX_DEPTH, 'Receipt structural budget exceeded.', 'RECEIPT_RESOURCE')
        kind = type(value)
        check(kind in (dict, list, str, int, bool, type(None)), 'Receipt requires exact JSON-native values.', 'RECEIPT_SHAPE')
        if kind in (dict, list):
            check(id(value) not in active, 'Receipt cycles are forbidden.', 'RECEIPT_SHAPE')
            check(len(value) <= MAX_ARRAY, 'Receipt collection budget exceeded.', 'RECEIPT_RESOURCE')
            active.add(id(value)); stack.append((value, depth, True))
            estimated_bytes += 2 + max(len(value) - 1, 0) + (len(value) if kind is dict else 0)
            if kind is dict:
                for key, item in value.items():
                    check(type(key) is str, 'Receipt object keys must be strings.', 'RECEIPT_SHAPE')
                    stack.append((key, depth + 1, False)); stack.append((item, depth + 1, False))
            else:
                stack.extend((item, depth + 1, False) for item in value)
        elif kind is str:
            try:
                width = len(value.encode('utf-8'))
            except UnicodeError as exc:
                raise BangelDiagnostic('RECEIPT_SHAPE', 'Receipt strings require valid Unicode.') from exc
            check(width <= MAX_STRING_BYTES, 'Receipt string budget exceeded.', 'RECEIPT_RESOURCE')
            escaped_extra = sum(1 if char in '\\"\b\f\n\r\t' else 5 if ord(char) < 32 else 0 for char in value)
            estimated_bytes += width + 2 + escaped_extra
        elif kind is int:
            integer(value, -(2**63), 2**63-1, 'RECEIPT_SHAPE'); estimated_bytes += len(str(value))
        else:
            estimated_bytes += 4 if value is None or value is True else 5
        check(estimated_bytes <= MAX_BYTES, 'Receipt byte budget exceeded.', 'RECEIPT_RESOURCE')
    check(len(canonical_bytes(root)) <= MAX_BYTES, 'Receipt byte budget exceeded.', 'RECEIPT_RESOURCE')


def number(value):
    text(value, NUMBER, code='RECEIPT_VALUE')
    try:
        result = Decimal(value)
        check(result.is_finite() and not (result.is_zero() and result.is_signed()), 'Receipt numeric value must be finite and canonical.', 'RECEIPT_VALUE')
        check((str(result) if 'E' in value else format(result, 'f')) == value, 'Receipt decimal spelling is noncanonical.', 'RECEIPT_VALUE')
        # A fixed magnitude is bounded by preflight; exponent form must never
        # provoke an expanded allocation and remains inside Decimal128 range.
        check(result.is_zero() or -6176 <= result.adjusted() <= 6144, 'Receipt magnitude exceeds Decimal128 exponent range.', 'RECEIPT_VALUE')
        return result
    except (DecimalException, ValueError) as exc:
        raise BangelDiagnostic('RECEIPT_VALUE', 'Invalid receipt numeric value.') from exc


def dimension(value):
    text(value, code='RECEIPT_VALUE')
    if value == '1': return (0, 0, 0, 0, 0)
    names = ('kg', 'm', 's', 'A', 'K')
    parts = value.split(' '); result = [0] * 5; previous = -1
    for part in parts:
        match = re.fullmatch(r'(kg|m|s|A|K)\^(-?[1-9][0-9]{0,8})', part)
        check(match is not None, 'Invalid receipt dimension.', 'RECEIPT_VALUE')
        index = names.index(match[1]); check(index > previous, 'Receipt dimensions are not in canonical axis order.', 'RECEIPT_VALUE')
        result[index] = int(match[2]); previous = index
    return tuple(result)


def value_contract(value):
    kind = type(value)
    if kind in (str, bool, type(None)): return
    if kind is list:
        for item in value: value_contract(item)
        return
    check(kind is dict, 'Unknown receipt value representation.', 'RECEIPT_VALUE')
    tag = value.get('kind')
    check(type(tag) is str, 'Receipt value requires a registered kind.', 'RECEIPT_VALUE')
    if tag in ('quantity', 'mass_delta'):
        exact(value, {'kind', 'value', 'unit', 'dimension', 'uncertainty', 'unknown'}, 'RECEIPT_VALUE')
        dims = dimension(value['dimension']); text(value['unit'], code='RECEIPT_VALUE')
        unit = UNITS.get(value['unit'])
        check((unit is not None and unit.dimension == dims) or value['unit'] == dimension_text(dims), 'Receipt unit and dimension disagree.', 'RECEIPT_VALUE')
        check(type(value['unknown']) is bool and value['unknown'] == (value['value'] is None), 'Receipt unknown/value fields disagree.', 'RECEIPT_VALUE')
        nominal = None if value['value'] is None else number(value['value'])
        if value['uncertainty'] is not None:
            check(number(value['uncertainty']) >= 0, 'Direct uncertainty must be nonnegative.', 'RECEIPT_VALUE')
        if tag == 'mass_delta': check(dims == MASS, 'MassDelta requires a mass dimension.', 'RECEIPT_VALUE')
        if tag == 'quantity' and dims == MASS and nominal is not None:
            check(nominal >= 0, 'Absolute mass cannot be negative.', 'RECEIPT_VALUE')
    elif tag == 'int':
        exact(value, {'kind', 'value'}, 'RECEIPT_VALUE'); text(value['value'], r'-?(?:0|[1-9][0-9]*)', code='RECEIPT_VALUE')
        check(len(value['value']) <= 20 and value['value'] != '-0', 'Invalid Int64 spelling.', 'RECEIPT_VALUE')
        integer(int(value['value']), -(2**63), 2**63-1, 'RECEIPT_VALUE')
    elif tag == 'real':
        exact(value, {'kind', 'value'}, 'RECEIPT_VALUE'); numeric = number(value['value'])
        check('E' not in value['value'] and ('.' not in value['value'] or not value['value'].endswith('0')) and (numeric != 0 or value['value'] == '0'), 'Real values require normalized fixed decimal spelling.', 'RECEIPT_VALUE')
        digits = list(numeric.as_tuple().digits)
        while digits and digits[-1] == 0: digits.pop()
        check(len(digits) <= 34, 'Real exceeds Decimal128 precision.', 'RECEIPT_VALUE')
    elif tag == 'failure':
        exact(value, {'kind', 'code', 'message'}, 'RECEIPT_VALUE'); text(value['code'], empty=True, code='RECEIPT_VALUE'); text(value['message'], empty=True, code='RECEIPT_VALUE')
    elif tag == 'result':
        exact(value, {'kind', 'variant', 'value'}, 'RECEIPT_VALUE')
        check(value['variant'] in ('Ok', 'Err'), 'Unknown Result variant.', 'RECEIPT_VALUE')
        value_contract(value['value'])
        if value['variant'] == 'Err': check(type(value['value']) is dict and value['value'].get('kind') == 'failure', 'Err requires Failure.', 'RECEIPT_VALUE')
    elif tag in ('record', 'enum'):
        exact(value, {'kind', 'identity', 'fields'} | ({'variant'} if tag == 'enum' else set()), 'RECEIPT_VALUE')
        text(value['identity'], NAME, code='RECEIPT_VALUE')
        if tag == 'enum': text(value['variant'], NAME, code='RECEIPT_VALUE')
        named_values(value['fields'])
    elif tag == 'map':
        exact(value, {'kind', 'entries'}, 'RECEIPT_VALUE')
        check(type(value['entries']) is dict, 'Map entries must be an object.', 'RECEIPT_VALUE')
        for item in value['entries'].values(): value_contract(item)
    elif tag == 'unknown':
        exact(value, {'kind', 'type', 'reason', 'provenance'}, 'RECEIPT_VALUE')
        from .ir_types import verify_type
        try:
            verify_type(value['type'])
        except BangelDiagnostic as exc:
            raise BangelDiagnostic('RECEIPT_VALUE', 'Unknown underlying type is invalid.') from exc
        check(value['type']['kind'] in ('Bool', 'Int', 'Real', 'Quantity', 'MassDelta', 'Measurement'), 'Unknown requires an admitted scalar/physical type.', 'RECEIPT_VALUE')
        text(value['reason'], empty=True, code='RECEIPT_VALUE')
        check(type(value['provenance']) is list and bool(value['provenance']), 'Unknown provenance must be nonempty.', 'RECEIPT_VALUE')
        for reason in value['provenance']: text(reason, empty=True, code='RECEIPT_VALUE')
    else:
        check(False, 'Unknown receipt value kind.', 'RECEIPT_VALUE')


def named_values(values):
    check(type(values) is dict, 'Named receipt values must be an object.', 'RECEIPT_VALUE')
    for name, value in values.items():
        text(name, NAME, code='RECEIPT_VALUE'); value_contract(value)


def evidence_record(value):
    exact(value, {'name', 'class', 'trust', 'value'}, 'RECEIPT_EVENT')
    text(value['name'], NAME, code='RECEIPT_EVENT'); value_contract(value['value'])
    check(value['class'] in ('MODEL', 'SIMULATED', 'OBSERVED', 'EXTERNAL'), 'Unknown evidence class.', 'RECEIPT_EVENT')
    check(value['trust'] == ('DERIVED' if value['class'] in ('MODEL', 'SIMULATED') else 'UNATTESTED'), 'Evidence trust does not match its class.', 'RECEIPT_EVENT')


def event_contract(value, strict):
    check(type(value) is dict, 'Receipt events must be objects.', 'RECEIPT_EVENT')
    kind = value.get('event'); base = {'event', 'stage'}
    check(type(kind) is str and value.get('stage') in STAGES, 'Unknown event kind or stage.', 'RECEIPT_EVENT')
    fields = {
        'function': {'name', 'params', 'pure'},
        'let': {'name', 'value'}, 'var': {'name', 'value'}, 'derive': {'name', 'value'}, 'measure': {'name', 'value'}, 'set': {'name', 'value'},
        'evidence': {'name', 'value', 'class', 'trust', 'authority_effect'},
        'emit': {'name'}, 'role': {'name', 'authority_effect'},
        'node': {'node', 'mode', 'value', 'model_only', 'physical_effect'},
        'mirror': {'kind', 'source', 'target', 'value', 'model_only', 'physical_effect'},
        'collect': {'collector', 'node', 'name', 'value', 'model_only', 'physical_effect'},
        'legacy_operation': {'operation', 'generation', 'input_root', 'compatibility', 'status', 'hold_code'},
        'if': {'result'}, 'for': {'count'}, 'match': {'tag'},
    }
    if kind == 'require':
        check(value.get('result') is None or type(value.get('result')) is bool, 'Requirement result must be Bool or unknown.', 'RECEIPT_EVENT')
        keys = base | {'result'} | ({'hold_code'} if value.get('result') is not True else set())
        if 'requested_code' in value: keys |= {'requested_code'}
        exact(value, keys, 'RECEIPT_EVENT')
        if value['result'] is not True: text(value['hold_code'], CODE, code='RECEIPT_EVENT')
        if value['result'] is None: check(value['hold_code'] == 'REQUIREMENT_UNKNOWN', 'Unknown requirement uses its named HOLD result.', 'RECEIPT_EVENT')
        if 'requested_code' in value:
            check(value['result'] is None, 'Requested code applies only to an unknown requirement.', 'RECEIPT_EVENT'); text(value['requested_code'], CODE, code='RECEIPT_EVENT')
    else:
        check(kind in fields, 'Unknown receipt event kind.', 'RECEIPT_EVENT')
        exact(value, base | fields[kind], 'RECEIPT_EVENT')
    if 'name' in value: text(value['name'], NAME, code='RECEIPT_EVENT')
    if 'value' in value: value_contract(value['value'])
    for effect in ('authority_effect', 'physical_effect'):
        if effect in value: check(value[effect] == 'NONE', 'Receipt event effects must remain NONE.', 'RECEIPT_EFFECT')
    if 'model_only' in value: check(value['model_only'] is True, 'Topology events are model-only.', 'RECEIPT_EFFECT')
    if kind == 'function':
        check(value['pure'] is True and type(value['params']) is list, 'Function events must be pure with parameter names.', 'RECEIPT_EVENT')
        for name in value['params']: text(name, NAME, code='RECEIPT_EVENT')
        check(len(set(value['params'])) == len(value['params']), 'Function parameter names must be unique.', 'RECEIPT_EVENT')
    if kind == 'evidence': evidence_record({key: value[key] for key in ('name', 'class', 'trust', 'value')})
    if kind == 'measure':
        check(type(value['value']) is dict and value['value'].get('kind') in ('quantity', 'mass_delta') and value['value']['uncertainty'] is not None, 'Measurement events require explicit direct uncertainty.', 'RECEIPT_VALUE')
    nodes = [x.value for x in PREDICTION_NODES] + list(EXTENDED_NODES)
    for key in ('node', 'source', 'target'):
        if key in value: check(value[key] in nodes, 'Unknown topology node.', 'RECEIPT_EVENT')
    if kind == 'node': check(value['mode'] in EDGE_MODES, 'Unknown topology mode.', 'RECEIPT_EVENT')
    if kind in ('mirror', 'collect'): text(value['kind' if kind == 'mirror' else 'collector'], NAME, code='RECEIPT_EVENT')
    if kind == 'legacy_operation':
        integer(value['generation'], 0, 2**32-1, 'RECEIPT_EVENT'); text(value['input_root'], HEX, code='RECEIPT_EVENT')
        check(value['operation'] in ('observe resource', 'recommend hagar', 'verify receipt', 'acoustic transcript') and value['compatibility'] == 'Bangel-0.1' and value['status'] == 'HOLD' and value['hold_code'] == 'PHYSICAL_PROVIDER_UNAVAILABLE', 'Invalid legacy event.', 'RECEIPT_EVENT')
    if kind == 'if': check(type(value['result']) is bool, 'If event must record a selected Boolean branch.', 'RECEIPT_EVENT')
    if kind == 'for': integer(value['count'], 0, 65536, 'RECEIPT_EVENT')
    if kind == 'match':
        check(type(value['tag']) is list and bool(value['tag']), 'Match tag must be nonempty.', 'RECEIPT_EVENT')
        for tag in value['tag']: text(tag, NAME, code='RECEIPT_EVENT')
    minimum = 'R1' if kind in ('function', 'let', 'var', 'set', 'measure', 'evidence', 'role') else 'N8' if kind == 'require' else 'N9' if kind in ('emit', 'collect') else 'N1'
    if kind not in ('node', 'mirror', 'legacy_operation'):
        check(STAGES.index(value['stage']) >= STAGES.index(minimum) and value['stage'] != 'R2', 'Event stage does not match its instruction.', 'RECEIPT_EVENT')
        if not strict and kind != 'derive': check(value['stage'] == minimum, 'Historical event stage mismatch.', 'RECEIPT_EVENT')


def verify_contract(root):
    exact(root, ROOT_KEYS)
    exact(root['runtime'], {'name', 'protocol', 'version'}, 'RECEIPT_PROFILE')
    check(root['runtime'] == {'name': 'Joanna', 'protocol': 'Joanna/1', 'version': '0.3.0a2'} and root['profile'] == 'Joanna-Receipt/1', 'Receipt runtime/profile identity is invalid.', 'RECEIPT_PROFILE')
    text(root['program'], NAME); text(root['program_root'], HEX); text(root['receipt_root'], HEX, code='RECEIPT_ROOT')
    check(root['authority_effect'] == root['physical_effect'] == 'NONE', 'Receipts cannot claim authority or physical effect.', 'RECEIPT_EFFECT')
    check(root['status'] in ('PASS', 'HOLD'), 'Receipt status must be PASS or HOLD.', 'RECEIPT_STATUS')
    if root['status'] == 'PASS': check(root['hold_code'] is None, 'PASS receipt cannot carry HOLD code.', 'RECEIPT_STATUS')
    else: text(root['hold_code'], CODE, code='RECEIPT_STATUS')
    exact(root['state_meanings'], {'R1', 'R2', 'N1'})
    check(root['state_meanings'] == {key: STATE_MEANINGS[Stage(key)] for key in ('R1', 'R2', 'N1')}, 'Receipt state meanings are frozen.')
    check(root['prediction_nodes'] == [x.value for x in PREDICTION_NODES], 'Receipt prediction-node list is frozen.')
    limits = root['resource_limits']; check(type(limits) is dict and set(limits) in (OLD_LIMITS, NEW_LIMITS), 'Receipt resource record is incomplete or extended.', 'RECEIPT_LIMITS')
    strict = set(limits) == NEW_LIMITS
    for key, val in limits.items(): integer(val, 0 if key.endswith('_used') or key == 'output_bytes' else 1)
    check(limits['evaluations_used'] <= limits['evaluation_limit'], 'Evaluation usage exceeds its limit.', 'RECEIPT_LIMITS')
    for key in ('events', 'evidence', 'traversal'): check(type(root[key]) is list, 'Receipt collection must be an array.')
    check(len(root['events']) <= limits['event_limit'], 'Event usage exceeds its limit.', 'RECEIPT_LIMITS')
    named_values(root['outputs']); named_values(root['roles'])
    for record in root['evidence']: evidence_record(record)
    for event in root['events']: event_contract(event, strict)
    if strict:
        order = [STAGES.index(event['stage']) for event in root['events']]
        check(order == sorted(order), 'Effective strict event stages cannot move backward.', 'RECEIPT_TRAVERSAL')
    emitted = {event['name'] for event in root['events'] if event['event'] == 'emit'}
    roles = {event['name'] for event in root['events'] if event['event'] == 'role'}
    check(emitted == set(root['outputs']) and roles == set(root['roles']), 'Output/role names disagree with events.', 'RECEIPT_LINK')
    evidence = [{key: event[key] for key in ('name', 'class', 'trust', 'value')} for event in root['events'] if event['event'] == 'evidence']
    check(evidence == root['evidence'], 'Evidence records disagree with event history.', 'RECEIPT_LINK')
    holds = [event['hold_code'] for event in root['events'] if 'hold_code' in event]
    check((not holds and root['status'] == 'PASS') or (bool(holds) and root['status'] == 'HOLD' and root['hold_code'] == holds[-1]), 'Receipt status disagrees with events.', 'RECEIPT_STATUS')
    for index, event in enumerate(root['events']):
        if event['event'] == 'require' and event['result'] is not True:
            check(index == len(root['events']) - 1, 'Failed requirement must terminate execution.', 'RECEIPT_LINK')
    traversal = root['traversal']; previous = -1; grouped = {}; instructions = []
    for item in traversal:
        exact(item, {'stage', 'meaning', 'instruction', 'action'}, 'RECEIPT_TRAVERSAL')
        check(item['stage'] in STAGES, 'Unknown traversal stage.', 'RECEIPT_TRAVERSAL')
        order = STAGES.index(item['stage']); check(order >= previous, 'Traversal is not canonically ordered.', 'RECEIPT_TRAVERSAL'); previous = order
        check(item['meaning'] == STATE_MEANINGS[Stage(item['stage'])], 'Traversal meaning is frozen.', 'RECEIPT_TRAVERSAL')
        grouped.setdefault(item['stage'], []).append(item)
        if item['instruction'] is None:
            expected = {'R0': 'source_arrival', 'R': 'identity_normalization', 'R2': 'receipt_binding_living_static'}.get(item['stage'], 'injected_path_marker')
            check(item['action'] == expected, 'Invalid traversal marker.', 'RECEIPT_TRAVERSAL')
        else:
            integer(item['instruction'], 0, 65535, 'RECEIPT_TRAVERSAL'); text(item['action'], NAME, code='RECEIPT_TRAVERSAL')
            instructions.append((item['action'], item['stage']))
    check(set(grouped) == set(STAGES), 'Traversal must cover every canonical stage.', 'RECEIPT_TRAVERSAL')
    for stage, items in grouped.items():
        markers = [item for item in items if item['instruction'] is None]
        check(not markers or len(items) == 1, 'Traversal marker must be unique and cannot accompany an instruction.', 'RECEIPT_TRAVERSAL')
    check(Counter(instructions) == Counter((event['event'], event['stage']) for event in root['events']), 'Traversal and runtime events disagree.', 'RECEIPT_LINK')
    check(len(traversal) <= len(root['events']) + len(STAGES), 'Traversal exceeds its derived bound.', 'RECEIPT_LIMITS')
    if strict:
        check(limits['events_used'] == len(root['events']) <= limits['instructions_used'] <= limits['instruction_limit'], 'Instruction/event usage is inconsistent.', 'RECEIPT_LIMITS')
        if root['status'] == 'PASS': check(limits['instructions_used'] == limits['events_used'], 'PASS cannot leave an attempted instruction incomplete.', 'RECEIPT_LIMITS')
        check(limits['function_depth_used'] <= limits['function_depth'] and limits['allocations_used'] <= limits['allocation_limit'], 'Runtime allocation/depth usage exceeds limits.', 'RECEIPT_LIMITS')
        check(limits['output_bytes'] == len(canonical_bytes(root['outputs'])) <= limits['output_limit'], 'Output byte usage is inconsistent.', 'RECEIPT_LIMITS')
        check(len(canonical_bytes(root)) <= limits['receipt_limit'], 'Receipt byte usage exceeds its limit.', 'RECEIPT_LIMITS')
