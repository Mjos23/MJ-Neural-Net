from __future__ import annotations

from enum import StrEnum


LANGUAGE = "Bangel"
LANGUAGE_CATEGORY = "Robotics-focused Measurement Programming Language"
SOURCE_EXTENSION = ".bangel"
LANGUAGE_VERSION = "1.0"
LANGUAGE_IDENTITY = "Bangel/1.0"
SOURCE_HEADER = "bangel 1.0"
COMPILER = "Elsa"
COMPILER_PROTOCOL = "Elsa/1"
TYPED_IR = "JP-IR/1"
RUNTIME = "Joanna"
RUNTIME_PROTOCOL = "Joanna/1"
RECEIPT_PROFILE = "Joanna-Receipt/1"
PUBLIC_API = "BANGEL-API/1"
PROJECT_PROFILE = "Bangel-Project/1"
CONFORMANCE_PROFILE = "Bangel-Conformance/1"
SEMANTIC_DIAGNOSTIC_FREEZE = "A1"
SEMANTIC_DIAGNOSTIC_CONTRACT_SHA256 = (
    "258bb93707f91931eb0e8ccf623c1257340367a7ed5da2aa9237a91919fd69d6"
)
UNITS_PROFILE = "Bangel-Units/1"
OWNER_FOUNDER = "Michael Patrick Bangel"
AUTHORITY_EFFECT = "NONE"
PHYSICAL_EFFECT = "NONE"


class Stage(StrEnum):
    R0 = "R0"
    R = "R"
    R1 = "R1"
    N1 = "N1"
    N2 = "N2"
    N3 = "N3"
    N4 = "N4"
    N5 = "N5"
    N6 = "N6"
    N7 = "N7"
    N8 = "N8"
    N9 = "N9"
    R2 = "R2"


CANONICAL_PATH = tuple(Stage)
PREDICTION_NODES = tuple(Stage(f"N{i}") for i in range(1, 10))
EXTENDED_NODES = (
    "L0", "U1", "U2", "U3", "D1", "D2", "D3", "C1", "C2", "C3"
)
EDGE_MODES = (
    "OBSERVE", "PROPAGATE", "CAPTURE", "ISOLATE", "DESCEND", "REALLOCATE"
)

CANONICAL_STACK = {
    "language": LANGUAGE_IDENTITY,
    "category": LANGUAGE_CATEGORY,
    "extension": SOURCE_EXTENSION,
    "compiler": COMPILER_PROTOCOL,
    "typed_ir": TYPED_IR,
    "runtime": RUNTIME_PROTOCOL,
    "receipt": RECEIPT_PROFILE,
    "api": PUBLIC_API,
    "owner_founder": OWNER_FOUNDER,
}

HISTORICAL_ALIASES = {
    "compiler": ("Voodoo",),
    "typed_ir": ("JP", "JP-IR/0.1"),
    "runtime": ("JO", "JO-RUNTIME-ABI/1"),
    "umbrella": ("MJ", "MJos", "MJos Quantum", "Perth", "Covenant Ring"),
}
