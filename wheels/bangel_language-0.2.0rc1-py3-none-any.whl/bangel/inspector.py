from __future__ import annotations

from typing import Any

from .receipts import verify_receipt
from .canonical import canonical_bytes, digest
from .diagnostics import BangelDiagnostic


def inspect_receipt(receipt: dict[str, Any]) -> dict[str, Any]:
    verify_receipt(receipt)
    return {
        "valid": True,
        "profile": receipt["profile"],
        "program": receipt["program"],
        "status": receipt["status"],
        "hold_code": receipt.get("hold_code"),
        "program_root": receipt["program_root"],
        "receipt_root": receipt["receipt_root"],
        "authority_effect": receipt["authority_effect"],
        "physical_effect": receipt["physical_effect"],
        "traversal_stages": [event["stage"] for event in receipt["traversal"]],
    }


def query_receipt(receipt: dict[str, Any], path: str) -> dict[str, Any]:
    verify_receipt(receipt)
    if type(path) is not str or not path or len(path) > 256:
        raise BangelDiagnostic("QUERY_PATH", "Receipt query path must contain 1 to 256 characters.")
    current: Any = receipt
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, list) and part.isascii() and part.isdigit() and (part == "0" or not part.startswith("0")) and int(part) < len(current):
            current = current[int(part)]
        else:
            raise BangelDiagnostic("QUERY_PATH", f"Receipt path component {part!r} does not exist.")
    return {"path": path, "value": current, "receipt_root": receipt["receipt_root"]}


def compare_receipts(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    verify_receipt(left)
    verify_receipt(right)
    fields = ("program", "program_root", "status", "hold_code", "outputs", "evidence")
    changes = {
        field: {"left": left.get(field), "right": right.get(field)}
        for field in fields
        if left.get(field) != right.get(field)
    }
    basis = {
        "profile": "Joanna-Receipt-Comparison/1",
        "left_root": left["receipt_root"],
        "right_root": right["receipt_root"],
        "equivalent": not changes,
        "changes": changes,
    }
    return {**basis, "comparison_root": digest(basis)}


def replay_receipt(compilation: dict[str, Any], receipt: dict[str, Any]) -> dict[str, Any]:
    """Re-execute admitted IR with receipt limits and compare complete bytes."""
    from .ir import JPIR
    from .runtime import JoannaRuntime

    JPIR(compilation).verify()
    verify_receipt(receipt)
    if compilation["program_root"] != receipt["program_root"] or compilation["program"] != receipt["program"]:
        raise BangelDiagnostic("REPLAY_PROGRAM_ROOT", "Replay IR does not match the receipt's program identity and root.")
    names = ("instruction_limit", "event_limit", "function_depth", "evaluation_limit", "allocation_limit", "output_limit", "receipt_limit")
    limits = {name: receipt["resource_limits"][name] for name in names if name in receipt["resource_limits"]}
    actual = JoannaRuntime(**limits).execute(compilation).to_dict()
    if canonical_bytes(actual) != canonical_bytes(receipt):
        raise BangelDiagnostic("REPLAY_MISMATCH", "Re-execution differs from the complete recorded receipt.")
    basis = {"profile": "Joanna-Receipt-Replay/1", "program_root": compilation["program_root"], "receipt_root": receipt["receipt_root"], "replayed_receipt_root": actual["receipt_root"], "equivalent": True, "authority_effect": "NONE", "physical_effect": "NONE"}
    return {**basis, "replay_root": digest(basis)}
