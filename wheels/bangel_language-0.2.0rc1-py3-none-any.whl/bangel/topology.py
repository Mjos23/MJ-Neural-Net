from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .diagnostics import BangelDiagnostic
from .identity import EDGE_MODES, EXTENDED_NODES, PREDICTION_NODES, Stage


LOGICAL_NODES = tuple(node.value for node in PREDICTION_NODES) + EXTENDED_NODES


def canonical_stage(node: str) -> Stage:
    if node.startswith("N") and node in LOGICAL_NODES:
        return Stage(node)
    if node == "L0":
        return Stage.R1
    family = node[:1]
    number = int(node[1:]) if len(node) == 2 and node[1:].isdigit() else 0
    bases = {"U": 0, "D": 3, "C": 6}
    if family in bases and 1 <= number <= 3:
        return Stage(f"N{bases[family] + number}")
    raise BangelDiagnostic("NODE_UNKNOWN", f"Unknown logical node {node!r}.")


@dataclass(frozen=True, slots=True)
class Edge:
    source: str
    target: str
    mode: str

    def __post_init__(self) -> None:
        canonical_stage(self.source)
        canonical_stage(self.target)
        if self.mode not in EDGE_MODES:
            raise BangelDiagnostic("EDGE_MODE", f"Unknown edge mode {self.mode!r}.")

    def to_dict(self) -> dict[str, str]:
        return {"source": self.source, "target": self.target, "mode": self.mode}


@dataclass(slots=True)
class Topology:
    nodes: set[str] = field(default_factory=set)
    edges: list[Edge] = field(default_factory=list)

    def add_node(self, node: str) -> None:
        canonical_stage(node)
        if node in self.nodes:
            raise BangelDiagnostic("NODE_DUPLICATE", f"Logical node {node!r} already exists.")
        self.nodes.add(node)

    def add_edge(self, source: str, target: str, mode: str) -> None:
        if source not in self.nodes:
            raise BangelDiagnostic("EDGE_SOURCE", f"Edge source {source!r} is not declared.")
        edge = Edge(source, target, mode)
        if edge in self.edges:
            raise BangelDiagnostic("EDGE_DUPLICATE", "Duplicate logical edge.")
        self.nodes.add(target)
        self.edges.append(edge)

    def to_dict(self) -> dict[str, Any]:
        return {
            "nodes": sorted(self.nodes, key=lambda node: (canonical_stage(node).value, node)),
            "edges": [edge.to_dict() for edge in self.edges],
            "physical_effect": "NONE",
        }
