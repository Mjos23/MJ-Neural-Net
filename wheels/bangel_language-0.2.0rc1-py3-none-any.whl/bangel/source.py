from __future__ import annotations

from dataclasses import dataclass

from .diagnostics import BangelDiagnostic, SourceSpan


MAX_SOURCE_BYTES = 65_536


@dataclass(frozen=True, slots=True)
class SourceLine:
    number: int
    text: str


def normalize_source(source: str) -> str:
    if not isinstance(source, str):
        raise BangelDiagnostic("SOURCE_TYPE", "Source must be UTF-8 text.")
    normalized = source.replace("\r\n", "\n").replace("\r", "\n")
    encoded = normalized.encode("utf-8")
    if len(encoded) > MAX_SOURCE_BYTES:
        raise BangelDiagnostic(
            "SOURCE_SIZE",
            f"Source exceeds the {MAX_SOURCE_BYTES}-byte profile.",
        )
    if "\0" in normalized:
        raise BangelDiagnostic("SOURCE_NUL", "NUL bytes are not admitted.")
    for number, line in enumerate(normalized.splitlines(), 1):
        if "\t" in line:
            raise BangelDiagnostic(
                "SOURCE_TAB", "Tabs are not admitted.", SourceSpan(number)
            )
        if line.rstrip(" ") != line:
            raise BangelDiagnostic(
                "SOURCE_TRAILING_SPACE",
                "Trailing spaces are not admitted.",
                SourceSpan(number, len(line.rstrip(" ")) + 1),
            )
    return normalized


def logical_lines(source: str) -> tuple[SourceLine, ...]:
    normalized = normalize_source(source)
    lines: list[SourceLine] = []
    for number, text in enumerate(normalized.splitlines(), 1):
        stripped = text.strip()
        if not stripped or stripped.startswith("#"):
            continue
        lines.append(SourceLine(number, stripped))
    if not lines:
        raise BangelDiagnostic("SOURCE_EMPTY", "Bangel source cannot be empty.")
    return tuple(lines)

