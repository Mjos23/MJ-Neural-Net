from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .diagnostics import BangelDiagnostic
from .topology import canonical_stage
from .units import LENGTH
from .values import Quantity, evidence_value


@dataclass(frozen=True, slots=True)
class Point3:
    x: Quantity
    y: Quantity
    z: Quantity

    def __post_init__(self) -> None:
        for coordinate in (self.x, self.y, self.z):
            if coordinate.dimension != LENGTH:
                raise BangelDiagnostic("GEOMETRY_LENGTH", "Point coordinates require length quantities.")

    def to_dict(self) -> dict[str, Any]:
        return {"kind": "point3", "coordinates": evidence_value((self.x, self.y, self.z))}


@dataclass(frozen=True, slots=True)
class MirrorModel:
    kind: str
    source: str
    target: str
    center: Point3 | None = None

    def __post_init__(self) -> None:
        canonical_stage(self.source)
        canonical_stage(self.target)
        if not self.kind:
            raise BangelDiagnostic("MIRROR_KIND", "Mirror kind cannot be empty.")

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "source": self.source,
            "target": self.target,
            "center": None if self.center is None else self.center.to_dict(),
            "model_only": True,
            "physical_effect": "NONE",
        }


@dataclass(frozen=True, slots=True)
class CollectorModel:
    kind: str
    node: str
    aperture: Quantity | None = None

    def __post_init__(self) -> None:
        canonical_stage(self.node)
        if not self.kind:
            raise BangelDiagnostic("COLLECTOR_KIND", "Collector kind cannot be empty.")
        if self.aperture is not None and self.aperture.dimension != LENGTH:
            raise BangelDiagnostic("APERTURE_LENGTH", "Collector aperture requires a length quantity.")

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "node": self.node,
            "aperture": None if self.aperture is None else evidence_value(self.aperture),
            "model_only": True,
            "physical_effect": "NONE",
        }
