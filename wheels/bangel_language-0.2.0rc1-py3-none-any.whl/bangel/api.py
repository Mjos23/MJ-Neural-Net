"""Frozen A1 BANGEL-API/1 envelopes and eight-operation local reference service."""
from __future__ import annotations
import argparse
import copy
import json
import queue
import os
import re
import signal
import subprocess
import sys
import threading
import time
from typing import Any, Callable
from .canonical import canonical_bytes, digest
from .diagnostics import BangelDiagnostic
from .identity import CANONICAL_STACK, PUBLIC_API
from .ir_contract import preflight
VERSIONS={key:CANONICAL_STACK[key] for key in ('language','compiler','typed_ir','runtime','api')}
DEFAULT_LIMITS=dict(instruction_limit=4096,event_limit=8192,function_depth=64,evaluation_limit=16384,
                    allocation_limit=1000000,output_limit=1048576,receipt_limit=4194304,wall_time_ms=10000)
MAX_FRAME=16777216
OPERATIONS=('identity','check','compile','run','format','inspect','projectBuild','conformance')
COMMON={'versions','options','limits','capabilities','cancelled'}

def fail(code,message):
    raise BangelDiagnostic('CLOSED_SCHEMA_VIOLATION' if code=='API_SCHEMA' else code,message)

def exact(value,keys,label):
    if type(value) is not dict or set(value)!=keys:
        fail('CLOSED_SCHEMA_VIOLATION',f'{label} requires exactly {sorted(keys)}.')

def valid_id(value):
    return type(value) is str and 0<len(value.encode('utf-8'))<=128

def make_request(operation,input=None,*,request_id='request-1',limits=None,compatibility=None):
    return {'api':PUBLIC_API,'id':request_id,'op':operation,'params':{
        'versions':dict(VERSIONS),'options':{'compatibility':compatibility},
        'limits':dict(limits or {}),'capabilities':[],**copy.deepcopy(input or {})}}

def _safe_json(value: Any, code: str) -> None:
    try:
        preflight(value)
        if len(canonical_bytes(value)) > MAX_FRAME:
            fail(code, 'Frame exceeds 16 MiB.')
    except (BangelDiagnostic, ValueError, TypeError, OverflowError, RecursionError, UnicodeError) as error:
        fail(code, 'Frame must contain bounded native JSON values with valid Unicode and no floats.')


def decode_frame(data: bytes) -> Any:
    if type(data) is not bytes or len(data) > MAX_FRAME:
        fail('API_JSON', 'Frame exceeds 16 MiB or is not bytes.')
    def pairs(items):
        obj = {}
        for key, value in items:
            if key in obj:
                fail('API_JSON', 'Duplicate JSON object key.')
            obj[key] = value
        return obj
    def forbidden(_):
        fail('API_JSON', 'Floating JSON numbers and constants are not admitted.')
    # Bound nesting before json.loads, including inputs whose decoded structure is invalid.
    depth = 0; quoted = False; escaped = False
    for byte in data:
        if quoted:
            if escaped: escaped = False
            elif byte == 92: escaped = True
            elif byte == 34: quoted = False
        elif byte == 34: quoted = True
        elif byte in (91,123):
            depth += 1
            if depth > 128: fail('API_JSON', 'Frame nesting exceeds 128.')
        elif byte in (93,125): depth -= 1
    try:
        value = json.loads(data.decode('utf-8'), object_pairs_hook=pairs,
                           parse_float=forbidden, parse_constant=forbidden)
        _safe_json(value, 'API_JSON')
        return value
    except (ValueError, UnicodeError, RecursionError) as error:
        if isinstance(error, BangelDiagnostic): raise
        fail('API_JSON', 'Frame is not valid bounded UTF-8 JSON.')


def _source(source: Any) -> None:
    exact(source, {'name','text'}, 'source')
    if type(source['name']) is not str or not source['name'] or type(source['text']) is not str:
        fail('API_SCHEMA', 'Source name and text must be strings.')
    if len(source['text'].encode('utf-8')) > 65536:
        fail('SOURCE_SIZE', 'Source exceeds the 65536-byte profile.')


def validate_request(request):
    from .compiler import ElsaCompiler
    _safe_json(request,'CLOSED_SCHEMA_VIOLATION')
    exact(request,{'api','id','op','params'},'request')
    if request['api']!=PUBLIC_API: fail('API_VERSION_UNSUPPORTED','Exact BANGEL-API/1 identity is required.')
    if not valid_id(request['id']): fail('CLOSED_SCHEMA_VIOLATION','Request ID requires 1 to 128 UTF-8 bytes.')
    op=request['op']; p=request['params']
    if type(op) is not str or op not in OPERATIONS: fail('API_OPERATION','Unsupported BANGEL-API/1 operation.')
    if type(p) is not dict: fail('CLOSED_SCHEMA_VIOLATION','params must be an object.')
    if p.get('versions',VERSIONS)!=VERSIONS: fail('API_VERSION_UNSUPPORTED','Exact stack identities are required.')
    options=p.get('options',{'compatibility':None});exact(options,{'compatibility'},'options')
    compatibility=options['compatibility']
    if compatibility is not None and (type(compatibility) is not str or compatibility not in ElsaCompiler.compatibility_profiles):
        fail('COMPATIBILITY_PROFILE_UNKNOWN','Unknown explicit compatibility profile.')
    if type(p.get('capabilities',[])) is not list or p.get('capabilities',[])!=[]:
        fail('API_CAPABILITY','BANGEL-API/1 admits no host capability tokens.')
    limits=p.get('limits',{})
    if type(limits) is not dict or not set(limits)<=set(DEFAULT_LIMITS) or any(type(v) is not int or not 0<v<=DEFAULT_LIMITS[k] for k,v in limits.items()):
        fail('API_LIMIT','Limits must be positive integer attenuations of known defaults.')
    if type(p.get('cancelled',False)) is not bool: fail('CLOSED_SCHEMA_VIOLATION','cancelled must be Boolean.')
    payload={k:v for k,v in p.items() if k not in COMMON}
    if op in ('identity',): exact(payload,set(),'identity parameters')
    elif op in ('check','compile','format'): exact(payload,{'source'},'source operation parameters');_source(payload['source'])
    elif op=='projectBuild': exact(payload,{'project'},'projectBuild parameters')
    elif op=='run':
        keys=set(payload)-{'expected_receipt'}
        if keys not in ({'source'},{'project'},{'ir'}): fail('CLOSED_SCHEMA_VIOLATION','run requires exactly one source, project or IR.')
        if 'source' in payload:_source(payload['source'])
    elif op=='inspect':
        action=payload.get('action','view')
        expected={'view':{'receipt'},'verify':{'receipt'},'query':{'receipt','path'},'compare':{'receipt','other'}}
        if type(action) is not str or action not in expected: fail('CLOSED_SCHEMA_VIOLATION','Unknown read-only inspection action.')
        actual=set(payload)-{'action'}
        if actual!=expected[action]:fail('CLOSED_SCHEMA_VIOLATION','Inspection parameters do not match its action.')
        if action=='query' and type(payload['path']) is not str:fail('CLOSED_SCHEMA_VIOLATION','Query path must be text.')
    elif op=='conformance':
        if set(payload) not in (set(),{'names'}):fail('CLOSED_SCHEMA_VIOLATION','Conformance accepts only names.')
        if 'names' in payload and (type(payload['names']) is not list or not 1<=len(payload['names'])<=256 or any(type(n) is not str or not n for n in payload['names']) or len(set(payload['names']))!=len(payload['names'])):
            fail('CLOSED_SCHEMA_VIOLATION','Conformance names must be 1 to 256 unique strings.')
    if 'project' in payload:
        project=payload['project'];exact(project,{'sources','entry'},'project')
        sources=project['sources']
        if type(sources) is not dict or not 1<=len(sources)<=256:fail('CLOSED_SCHEMA_VIOLATION','Project requires 1 to 256 sources.')
        for name,text in sources.items():_source({'name':name,'text':text})
        if project['entry'] is not None and type(project['entry']) is not str:fail('CLOSED_SCHEMA_VIOLATION','Entry is a source name or null.')
        if compatibility is not None:fail('CLOSED_SCHEMA_VIOLATION','Projects require strict Bangel/1.0.')
    return {**DEFAULT_LIMITS,**limits}


def _response(request,*,result=None,error=None):
    rid=request.get('id') if type(request) is dict else None
    try:rid=rid if valid_id(rid) else None
    except UnicodeError:rid=None
    value={'api':PUBLIC_API,'id':rid,'ok':error is None}
    value['diagnostic' if error else 'result']=error.to_dict() if error else result
    return value

def error_response(request,code,message,**_):
    return _response(request,error=BangelDiagnostic(code,message))


def _project(compiler,project):
    return compiler.compile_project(project['sources'],entry_source_name=project['entry']).to_dict()


def _conformance(names):
    from importlib.resources import files
    path=files('bangel').joinpath('data/b07-vectors.json')
    if not path.is_file():fail('CONFORMANCE_UNAVAILABLE','Named candidate corpus is not packaged.')
    corpus=json.loads(path.read_text(encoding='utf-8')); rows=corpus['vectors']
    selected={r['id']:r for r in rows}
    requested=list(selected) if names is None else names
    if any(name not in selected for name in requested):fail('CONFORMANCE_NAME','Unknown conformance vector name.')
    def subset(expected,actual):
        if type(expected) is dict:return type(actual) is dict and all(k in actual and subset(v,actual[k]) for k,v in expected.items())
        if type(expected) is list:return type(actual) is list and len(expected)==len(actual) and all(subset(a,b) for a,b in zip(expected,actual))
        return type(expected) is type(actual) and expected==actual
    results=[]
    for name in requested:
        row=selected[name]
        if row['request']['op']=='conformance':fail('CONFORMANCE_CORPUS','Recursive conformance is prohibited.')
        response=handle_request(row['request']);validate_response(response,row['request']);expect=row['expect']
        ok=response['ok']==expect['ok']
        if 'diagnostic' in expect:ok=ok and response.get('diagnostic',{}).get('code')==expect['diagnostic']
        for key in ('outputs','receipt','result'):
            if key not in expect:continue
            actual=response.get('result',{})
            if key=='receipt':actual=actual.get('receipt')
            if key=='outputs':
                receipt=actual.get('receipt',{});actual=receipt.get('outputs')
                ok=ok and receipt.get('status')=='PASS' and type(actual) is dict and set(actual)==set(expect[key])
            ok=ok and subset(expect[key],actual)
        results.append({'id':name,'status':'PASS' if ok else 'FAIL'})
    return {'profile':'Bangel-Conformance/1','passed':sum(r['status']=='PASS' for r in results),'total':len(results),'results':results}


def handle_request(request,*,cancelled:Callable[[],bool]|None=None):
    """Trusted in-process facade; call_isolated/stdio enforce host deadlines."""
    try:
        effective=validate_request(request);p=request['params'];op=request['op']
        if p.get('cancelled',False) or cancelled and cancelled():fail('API_CANCELLED','Request was cancelled.')
        from .compiler import ElsaCompiler
        from .runtime import JoannaRuntime
        from .ir import JPIR
        from .receipts import verify_receipt
        from .inspector import inspect_receipt,query_receipt,compare_receipts
        compiler=ElsaCompiler(compatibility_profile=p.get('options',{}).get('compatibility'))
        if op=='identity':
            result={'identities':dict(CANONICAL_STACK),'implementation_versions':{'Elsa':'0.3.0-alpha.2','Joanna':'0.3.0-alpha.2'},
                    'capabilities':{'operations':list(OPERATIONS),'source_profiles':['Bangel/1.0',*sorted(compiler.compatibility_profiles)],'authority_effect':'NONE','physical_effect':'NONE'},'effective_limits':effective}
        elif op in ('check','compile'):
            s=p['source']
            if op=='check' and compiler.compatibility_profile is None:
                model=compiler.check(s['name'],s['text']).to_dict()
                result={'valid':True,**{k:model[k] for k in ('language','source','source_kind','declared_effects','inferred_effects','maximum_call_depth')}}
            else:
                ir=compiler.compile(s['name'],s['text']).to_dict()
                result={'ir':ir,'program_root':ir['program_root']}
                if op=='check':result={'valid':True,'language':'Bangel/1.0','source':s['name'],'source_kind':'CompatibilitySource','declared_effects':ir['effects'],'inferred_effects':ir['effects'],'maximum_call_depth':0}
        elif op=='projectBuild':
            ir=_project(compiler,p['project'])
            result={'profile':'Bangel-Project-Build/1','entry':ir['source']['name'],
                    'modules':[{'name':m['name'],'source_digest':m['source']['digest'],'exports':m['exports']} for m in ir['modules']],
                    'ir':ir,'program_root':ir['program_root']}
            result['project_root']=digest(result)
        elif op=='format':
            from .formatter import format_source
            original=p['source']['text'];formatted=format_source(original)
            result={'text':formatted,'changed':original!=formatted}
        elif op=='inspect':
            receipt=p['receipt'];action=p.get('action','view')
            if action=='view':result=inspect_receipt(receipt)
            elif action=='query':result=query_receipt(receipt,p['path'])
            elif action=='compare':result=compare_receipts(receipt,p['other'])
            else:verify_receipt(receipt);result={'valid':True,'receipt_root':receipt['receipt_root']}
        elif op=='conformance':result=_conformance(p.get('names'))
        else:
            if 'ir' in p:ir=p['ir']
            elif 'project' in p:ir=_project(compiler,p['project'])
            else:s=p['source'];ir=compiler.compile(s['name'],s['text']).to_dict()
            JPIR(ir).verify()
            expected=p.get('expected_receipt')
            if 'expected_receipt' in p:
                verify_receipt(expected)
                if expected['program_root']!=ir['program_root'] or expected['program']!=ir['program']:fail('REPLAY_PROGRAM_ROOT','Receipt and program identities differ.')
            receipt=JoannaRuntime(**{k:v for k,v in effective.items() if k!='wall_time_ms'}).execute(ir,cancelled=cancelled).to_dict()
            if expected is not None and canonical_bytes(receipt)!=canonical_bytes(expected):fail('REPLAY_MISMATCH','Re-execution differs from the expected receipt; use the recorded runtime limits.')
            result={'receipt':receipt,'program_root':receipt['program_root'],'receipt_root':receipt['receipt_root'],
                    'resources':{'limits':effective,'usage':receipt['resource_limits']}}
        if cancelled and cancelled():fail('API_CANCELLED','Request was cancelled.')
        response=_response(request,result=result);_safe_json(response,'API_RESPONSE_LIMIT');return response
    except BangelDiagnostic as error:
        if error.code=='CANCELLED':error=BangelDiagnostic('API_CANCELLED','Request was cancelled.')
        return _response(request,error=error)
    except (RecursionError,MemoryError,OverflowError):return error_response(request,'API_RESOURCE','Host computation exceeded safe resource capacity.')
    except Exception:return error_response(request,'API_INTERNAL','Unexpected internal implementation failure.')


def validate_response(response,request=None):
    try:
        _safe_json(response,'API_RESPONSE')
        if type(response) is not dict or type(response.get('ok')) is not bool:fail('API_RESPONSE','Invalid response discriminator.')
        exact(response,{'api','id','ok','result' if response['ok'] else 'diagnostic'},'response')
        if response['api']!=PUBLIC_API or (response['id'] is not None and not valid_id(response['id'])):fail('API_RESPONSE','Invalid response identity.')
        if request is not None:
            rid=request.get('id');rid=rid if valid_id(rid) else None
            if response['id']!=rid:fail('API_RESPONSE','Response ID does not correlate.')
        if not response['ok']:
            d=response['diagnostic'];exact(d,{'code','message','span','details'},'diagnostic')
            if any(type(d[k]) is not str or not d[k] for k in ('code','message')) or type(d['details']) is not dict:fail('API_RESPONSE','Invalid diagnostic fields.')
            if not re.fullmatch(r'[A-Z][A-Z0-9_]*',d['code']):fail('API_RESPONSE','Diagnostic code spelling is invalid.')
            if d['span'] is not None:
                s=d['span'];exact(s,{'line','column','end_column'},'diagnostic span')
                if any(type(s[k]) is not int or s[k]<1 for k in ('line','column')) or (s['end_column'] is not None and (type(s['end_column']) is not int or s['end_column']<s['column'])):fail('API_RESPONSE','Invalid diagnostic span.')
            return
        result=response['result']
        if type(result) is not dict:fail('API_RESPONSE','Successful result must be an object.')
        if request is None:return
        op=request['op'];p=request['params']
        from .ir import JPIR
        from .receipts import verify_receipt
        from .inspector import inspect_receipt,query_receipt,compare_receipts
        if op=='identity':
            exact(result,{'identities','implementation_versions','capabilities','effective_limits'},'identity result')
            if result['identities']!=CANONICAL_STACK:fail('API_RESPONSE','Frozen stack identity mismatch.')
            exact(result['implementation_versions'],{'Elsa','Joanna'},'implementation versions')
            if result['implementation_versions'] != {'Elsa':'0.3.0-alpha.2','Joanna':'0.3.0-alpha.2'}:fail('API_RESPONSE','Invalid implementation SemVer values.')
            exact(result['capabilities'],{'operations','source_profiles','authority_effect','physical_effect'},'capabilities')
            if result['capabilities']['operations']!=list(OPERATIONS) or result['capabilities']['authority_effect']!='NONE' or result['capabilities']['physical_effect']!='NONE':fail('API_RESPONSE','Invalid advertised capability contract.')
            from .compiler import ElsaCompiler
            if result['capabilities']['source_profiles']!=['Bangel/1.0',*sorted(ElsaCompiler.compatibility_profiles)]:fail('API_RESPONSE','Invalid source profiles.')
            if result['effective_limits']!=validate_request(request):fail('API_RESPONSE','Effective limits mismatch.')
        elif op=='check':
            exact(result,{'valid','language','source','source_kind','declared_effects','inferred_effects','maximum_call_depth'},'check result')
            if result['valid'] is not True or result['language']!='Bangel/1.0' or result['source']!=p['source']['name'] or result['source_kind'] not in ('ProgramSource','ModuleSource','CompatibilitySource'):fail('API_RESPONSE','Invalid check identity.')
            if type(result['maximum_call_depth']) is not int or not 0<=result['maximum_call_depth']<=64:fail('API_RESPONSE','Invalid check depth.')
            if result['declared_effects']!=result['inferred_effects'] or result['declared_effects'] not in (['pure'],['pure','evidence']):fail('API_RESPONSE','Invalid effect summary.')
        elif op in ('compile','projectBuild'):
            exact(result,{'ir','program_root'} if op=='compile' else {'profile','entry','modules','ir','program_root','project_root'},'compilation result')
            JPIR(result['ir']).verify()
            if result['program_root']!=result['ir']['program_root']:fail('API_RESPONSE','Program root mismatch.')
            if op=='compile':
                source=p['source'];normalized=source['text'].replace('\r\n','\n').replace('\r','\n')
                if result['ir']['source']['name']!=source['name'] or result['ir']['source']['digest']!=digest({'source':normalized}):fail('API_RESPONSE','Compiled source differs from request.')
            if op=='projectBuild':
                if result['profile']!='Bangel-Project-Build/1' or result['entry']!=result['ir']['source']['name']:fail('API_RESPONSE','Project identity mismatch.')
                if digest({k:v for k,v in result.items() if k!='project_root'})!=result['project_root']:fail('API_RESPONSE','Project root mismatch.')
                expected=[{'name':m['name'],'source_digest':m['source']['digest'],'exports':m['exports']} for m in result['ir']['modules']]
                if result['modules']!=expected:fail('API_RESPONSE','Project modules differ from linked IR.')
        elif op=='run':
            exact(result,{'receipt','program_root','receipt_root','resources'},'run result')
            r=result['receipt'];verify_receipt(r)
            if any(result[k]!=r[k] for k in ('program_root','receipt_root')):fail('API_RESPONSE','Receipt root linkage mismatch.')
            if result['resources']!={'limits':validate_request(request),'usage':r['resource_limits']}:fail('API_RESPONSE','Runtime resources mismatch.')
            if 'ir' in p: expected_root=p['ir']['program_root']
            else:
                from .compiler import ElsaCompiler
                compiler=ElsaCompiler(compatibility_profile=p.get('options',{}).get('compatibility'))
                expected_ir=_project(compiler,p['project']) if 'project' in p else compiler.compile(p['source']['name'],p['source']['text']).to_dict()
                expected_root=expected_ir['program_root']
            if r['program_root']!=expected_root:fail('API_RESPONSE','Executed program differs from request.')
        elif op=='format':
            exact(result,{'text','changed'},'format result')
            if type(result['text']) is not str or type(result['changed']) is not bool or result['changed']!=(result['text']!=p['source']['text']):fail('API_RESPONSE','Invalid formatting result.')
        elif op=='inspect':
            action=p.get('action','view')
            if action=='view':expected=inspect_receipt(p['receipt'])
            elif action=='query':expected=query_receipt(p['receipt'],p['path'])
            elif action=='compare':expected=compare_receipts(p['receipt'],p['other'])
            else:verify_receipt(p['receipt']);expected={'valid':True,'receipt_root':p['receipt']['receipt_root']}
            if result!=expected:fail('API_RESPONSE','Read-only inspection result differs.')
        elif op=='conformance':
            exact(result,{'profile','passed','total','results'},'conformance result')
            if result['profile']!='Bangel-Conformance/1' or type(result['results']) is not list:fail('API_RESPONSE','Invalid conformance result.')
            for row in result['results']:
                exact(row,{'id','status'},'conformance row')
                if type(row['id']) is not str or row['status'] not in ('PASS','FAIL'):fail('API_RESPONSE','Invalid named vector result.')
            if type(result['passed']) is not int or type(result['total']) is not int or result['total']!=len(result['results']) or result['passed']!=sum(r['status']=='PASS' for r in result['results']):fail('API_RESPONSE','Invalid conformance counts.')
    except (BangelDiagnostic,KeyError,TypeError,ValueError,RecursionError) as error:
        if isinstance(error,BangelDiagnostic) and error.code=='API_RESPONSE':raise
        fail('API_RESPONSE','Malformed or inconsistent BANGEL-API/1 response.')


def _worker_command():return [sys.executable,'-m','bangel.api','--worker','--parent-pid',str(os.getpid())]

def _worker_result(request,returncode,data):
    try:
        if returncode!=0:fail('API_WORKER_FAILURE','Worker exited without a response.')
        response=decode_frame(data);validate_response(response,request);return response
    except BangelDiagnostic:return error_response(request,'API_WORKER_FAILURE','Worker did not produce a valid response.')

def _communicate_bounded(child,request):
    """Bound stdout during reading, including a faulty worker that floods output."""
    def write_input():
        try:
            child.stdin.write(canonical_bytes(request));child.stdin.close()
        except (BrokenPipeError,OSError):
            pass
    writer=threading.Thread(target=write_input,daemon=True);writer.start()
    data=child.stdout.read(MAX_FRAME+2)
    if len(data)>MAX_FRAME+1:
        child.kill();child.wait();writer.join(timeout=1)
        child.stdout.close()
        return child.returncode,b''
    child.wait();writer.join(timeout=1);child.stdout.close()
    return child.returncode,data


def call_isolated(request):
    try:limits=validate_request(request)
    except BangelDiagnostic as error:return _response(request,error=error)
    if request['params'].get('cancelled',False):return error_response(request,'API_CANCELLED','Request was cancelled.')
    try:
        child=subprocess.Popen(_worker_command(),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    except OSError:return error_response(request,'API_WORKER_FAILURE','Could not start worker.')
    completed=queue.Queue(maxsize=1)
    def communicate():completed.put(_communicate_bounded(child,request))
    thread=threading.Thread(target=communicate,daemon=True);thread.start()
    try:code,data=completed.get(timeout=limits['wall_time_ms']/1000)
    except queue.Empty:
        child.kill();child.wait();thread.join(timeout=1)
        return error_response(request,'API_TIMEOUT','Request exceeded its host deadline.')
    except BaseException:
        child.kill();child.wait();thread.join(timeout=1);raise
    return _worker_result(request,code,data)


def serve_stdin():
    def interrupted(_signum,_frame):raise KeyboardInterrupt
    previous_term=signal.signal(signal.SIGTERM,interrupted)
    incoming=queue.Queue(maxsize=2);complete=queue.Queue(maxsize=1)
    def reader():
        while True:
            data=sys.stdin.buffer.readline(MAX_FRAME+2)
            if not data:incoming.put(None);return
            oversized=len(data.rstrip(b'\n'))>MAX_FRAME
            if oversized and not data.endswith(b'\n'):
                while data and not data.endswith(b'\n'):data=sys.stdin.buffer.readline(65536)
            incoming.put(BangelDiagnostic('API_JSON','Frame exceeds 16 MiB.') if oversized else data.rstrip(b'\n'))
    threading.Thread(target=reader,daemon=True).start();active=None;eof=False
    def send(response):sys.stdout.buffer.write(canonical_bytes(response)+b'\n');sys.stdout.buffer.flush()
    def communicate(child,request):
        code,data=_communicate_bounded(child,request);complete.put((child,code,data))
    try:
        while not eof or active is not None:
            if active is not None:
                child,request,deadline=active
                try:
                    finished,code,data=complete.get_nowait()
                    if finished is child:send(_worker_result(request,code,data));active=None
                except queue.Empty:pass
                if active is not None and time.monotonic()>=deadline:
                    child.kill();child.wait();complete.get(timeout=5)
                    send(error_response(request,'API_TIMEOUT','Request exceeded its host deadline.'));active=None
            if eof:time.sleep(.005);continue
            try:data=incoming.get(timeout=.01)
            except queue.Empty:continue
            if data is None:eof=True;continue
            request=None
            try:
                if isinstance(data,BangelDiagnostic):raise data
                request=decode_frame(data);limits=validate_request(request)
            except BangelDiagnostic as error:send(_response(request,error=error));continue
            if request['params'].get('cancelled',False):
                send(error_response(request,'API_CANCELLED','Request was cancelled.'));continue
            if active is not None:
                code='API_ID_ACTIVE' if request['id']==active[1]['id'] else 'API_BUSY'
                send(error_response(request,code,'One request is already active.'));continue
            try:
                child=subprocess.Popen(_worker_command(),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
                active=(child,request,time.monotonic()+limits['wall_time_ms']/1000)
                threading.Thread(target=communicate,args=(child,request),daemon=True).start()
            except OSError:send(error_response(request,'API_WORKER_FAILURE','Could not start worker.'))
    except KeyboardInterrupt:
        if active is not None:send(error_response(active[1],'API_CANCELLED','Request was cancelled by host interruption.'))
        return 0
    except BrokenPipeError:return 0
    finally:
        if active is not None:active[0].kill();active[0].wait()
        signal.signal(signal.SIGTERM,previous_term)
    return 0

def main(argv=None):
    parser=argparse.ArgumentParser(description='BANGEL-API/1 local service')
    group=parser.add_mutually_exclusive_group(required=True);group.add_argument('--stdio',action='store_true');group.add_argument('--worker',action='store_true')
    parser.add_argument('--parent-pid',type=int)
    args=parser.parse_args(argv)
    if args.stdio:return serve_stdin()
    if args.parent_pid is not None and sys.platform=='linux':
        import ctypes
        if ctypes.CDLL(None,use_errno=True).prctl(1,signal.SIGKILL,0,0,0)!=0:return 2
        if os.getppid()!=args.parent_pid:return 2
    try:request=decode_frame(sys.stdin.buffer.read(MAX_FRAME+1));response=handle_request(request)
    except BangelDiagnostic as error:response=_response(None,error=error)
    sys.stdout.buffer.write(canonical_bytes(response)+b'\n');return 0
if __name__=='__main__':raise SystemExit(main())
