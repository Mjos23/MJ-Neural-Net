from __future__ import annotations

from dataclasses import dataclass

from .ast import Expression, Program
from .diagnostics import BangelDiagnostic


BUILTINS = {
    "unknown", "abs", "min", "max", "mean", "variance", "dampen",
    "step_cap", "bound", "shadow_speed", "floor_challenge", "signed_mass_delta",
    "length", "at", "sum", "dot", "norm", "select", "sqrt", "moving_mean", "slope",
}


@dataclass(frozen=True, slots=True)
class SemanticProgram:
    program: Program
    symbols: tuple[str, ...]
    functions: tuple[str, ...] = ()
    mutable_symbols: tuple[str, ...] = ()


def _names(expression: Expression) -> set[str]:
    names: set[str] = set()
    if expression.kind == "name":
        names.add(str(expression.value))
    for operand in expression.operands:
        names.update(_names(operand))
    return names


def _calls(expression: Expression) -> set[str]:
    calls: set[str] = set()
    if expression.kind == "call":
        calls.add(str(expression.value))
    for operand in expression.operands:
        calls.update(_calls(operand))
    return calls


def analyze(program: Program) -> SemanticProgram:
    symbols: set[str] = set()
    functions: set[str] = set()
    mutables: set[str] = set()
    declared: set[str] = set()
    last_node = 0
    node_values: set[str] = set()

    for statement in program.statements:
        if statement.kind == "function":
            assert statement.name is not None and statement.expression is not None
            if statement.name in declared:
                raise BangelDiagnostic("NAME_DUPLICATE", f"Duplicate name {statement.name!r}.", statement.span)
            params = tuple(statement.details["params"])
            missing = sorted(_names(statement.expression) - symbols - set(params))
            if missing:
                raise BangelDiagnostic("NAME_UNBOUND", f"Unbound name(s): {', '.join(missing)}.", statement.span)
            unknown_calls = sorted(_calls(statement.expression) - BUILTINS - functions - {statement.name})
            if unknown_calls:
                raise BangelDiagnostic(
                    "FUNCTION_UNKNOWN",
                    f"Unknown function(s): {', '.join(unknown_calls)}.",
                    statement.expression.span,
                )
            declared.add(statement.name)
            functions.add(statement.name)
            continue

        if statement.expression:
            missing = sorted(_names(statement.expression) - symbols)
            if missing:
                raise BangelDiagnostic("NAME_UNBOUND", f"Unbound name(s): {', '.join(missing)}.", statement.span)
            unknown_calls = sorted(_calls(statement.expression) - BUILTINS - functions)
            if unknown_calls:
                raise BangelDiagnostic(
                    "FUNCTION_UNKNOWN",
                    f"Unknown function(s): {', '.join(unknown_calls)}.",
                    statement.expression.span,
                )

        if statement.kind == "set":
            assert statement.name is not None
            if statement.name not in mutables:
                raise BangelDiagnostic("SET_IMMUTABLE", f"Only a var binding can be set: {statement.name!r}.", statement.span)
            continue

        if statement.kind == "evidence" and "evidence" not in program.effects:
            raise BangelDiagnostic("EFFECT_REQUIRED", "Evidence statements require the evidence effect.", statement.span)

        if statement.kind == "node":
            logical_node = statement.details["node"]
            if logical_node.startswith("N"):
                node = int(logical_node[1:])
                if node < last_node:
                    raise BangelDiagnostic("NODE_ORDER", "Explicit N-node traversal cannot move backward.", statement.span)
                last_node = node
            node_values.add(logical_node)
        if statement.kind == "mirror":
            source, target = statement.details["source"], statement.details["target"]
            if source.startswith("N") and target.startswith("N") and int(target[1:]) < int(source[1:]):
                raise BangelDiagnostic("MIRROR_ORDER", "Mirror models cannot move backward through N nodes.", statement.span)
        if statement.kind == "collect" and statement.details["node"] not in node_values:
            raise BangelDiagnostic("COLLECT_NODE", "Collector requires a previously evaluated explicit node.", statement.span)

        if statement.name:
            if statement.name in declared:
                raise BangelDiagnostic("NAME_DUPLICATE", f"Duplicate name {statement.name!r}.", statement.span)
            declared.add(statement.name)
            symbols.add(statement.name)
            if statement.kind == "var":
                mutables.add(statement.name)

    return SemanticProgram(program, tuple(sorted(symbols)), tuple(sorted(functions)), tuple(sorted(mutables)))
