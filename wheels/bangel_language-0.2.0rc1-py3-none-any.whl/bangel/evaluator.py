from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Callable

from .diagnostics import BangelDiagnostic
from .units import DIMENSIONLESS, MASS, UNITS, require_unit
from .values import Quantity


@dataclass(slots=True)
class EvaluationBudget:
    limit: int
    used: int = 0
    cancelled: Callable[[], bool] | None = None

    def __post_init__(self) -> None:
        if type(self.limit) is not int or self.limit <= 0:
            raise BangelDiagnostic("RUNTIME_LIMIT", "Runtime limits must be positive integers.")

    def consume(self) -> None:
        if self.cancelled is not None and self.cancelled():
            raise BangelDiagnostic("CANCELLED", "Execution was cancelled.")
        self.used += 1
        if self.used > self.limit:
            raise BangelDiagnostic(
                "EVALUATION_LIMIT",
                f"Expression evaluation count exceeds {self.limit}.",
            )


def _truth(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    raise BangelDiagnostic("BOOLEAN_REQUIRED", "A condition must evaluate to Bool or Unknown.")


def _quantity(value: Any) -> Quantity:
    if isinstance(value, Quantity):
        return value
    if isinstance(value, int | Decimal):
        return Quantity.known(Decimal(value))
    raise BangelDiagnostic("QUANTITY_REQUIRED", "Numeric operation requires a quantity.")


def _vector(value: Any, name: str) -> tuple[Any, ...]:
    if not isinstance(value, tuple | list):
        raise BangelDiagnostic("VECTOR_REQUIRED", f"{name}() requires a vector.")
    return tuple(value)


def _integer(value: Any, name: str) -> int:
    quantity = _quantity(value)
    if quantity.dimension != DIMENSIONLESS or quantity.is_unknown or quantity.magnitude_si is None:
        raise BangelDiagnostic("INTEGER_REQUIRED", f"{name}() requires a known dimensionless integer.")
    integer = int(quantity.magnitude_si)
    if Decimal(integer) != quantity.magnitude_si:
        raise BangelDiagnostic("INTEGER_REQUIRED", f"{name}() requires a known dimensionless integer.")
    return integer


def evaluate(
    expression: dict[str, Any],
    environment: dict[str, Any],
    functions: dict[str, dict[str, Any]] | None = None,
    depth: int = 0,
    max_depth: int = 64,
    budget: EvaluationBudget | None = None,
) -> Any:
    if budget is not None:
        budget.consume()
    functions = functions or {}
    kind = expression["kind"]
    if kind == "literal":
        return expression.get("value")
    if kind == "name":
        name = expression["value"]
        if name not in environment:
            raise BangelDiagnostic("NAME_UNBOUND", f"Unbound name {name!r}.")
        return environment[name]
    if kind == "quantity":
        value = expression["value"]
        unit_symbol = value["unit"]
        if unit_symbol in UNITS:
            return Quantity.known(Decimal(value["magnitude"]), unit_symbol)
        unit = expression.get("type", {}).get("unit", {})
        if unit.get("text") != unit_symbol:
            raise BangelDiagnostic("IR_QUANTITY", "Compound quantity type is inconsistent.")
        return Quantity(
            Decimal(value["magnitude"]) * Decimal(unit["scale"]),
            tuple(unit["dimension"]),
            "1",
        )
    if kind == "mass_delta":
        magnitude = _quantity(
            evaluate(expression["operands"][0], environment, functions, depth, max_depth, budget)
        )
        if magnitude.dimension != DIMENSIONLESS or magnitude.is_unknown or magnitude.magnitude_si is None:
            raise BangelDiagnostic("MASS_DELTA_VALUE", "MassDelta magnitude must be known and dimensionless.")
        unit = expression.get("type", {}).get("unit", {})
        if unit.get("text") != expression.get("value", {}).get("unit") or tuple(unit.get("dimension", ())) != MASS:
            raise BangelDiagnostic("IR_MASS_DELTA", "MassDelta unit metadata is inconsistent.")
        return Quantity(
            magnitude.magnitude_si * Decimal(unit["scale"]),
            MASS,
            unit["text"] if unit["text"] in UNITS else "1",
            signed_delta=True,
        )
    if kind == "unknown":
        encoded = expression.get("type", {})
        arguments = encoded.get("arguments", [])
        base = arguments[0] if len(arguments) == 1 else {}
        while base.get("kind") in {"Unknown", "Measurement"}:
            nested = base.get("arguments", [])
            base = nested[0] if len(nested) == 1 else {}
        if base.get("kind") == "Bool":
            return None
        if base.get("kind") in {"Int", "Real"}:
            return Quantity.unknown()
        if base.get("kind") in {"Quantity", "MassDelta"}:
            unit = base.get("unit", {})
            text = unit.get("text", "1")
            return Quantity(
                None,
                tuple(unit.get("dimension", DIMENSIONLESS)),
                text if text in UNITS else "1",
                signed_delta=base.get("kind") == "MassDelta",
            )
        raise BangelDiagnostic("IR_UNKNOWN", "Unknown runtime type is unsupported.")
    if kind == "vector":
        return tuple(
            evaluate(item, environment, functions, depth, max_depth, budget)
            for item in expression.get("operands", [])
        )
    if kind == "argument":
        operands = expression.get("operands", [])
        if len(operands) != 1:
            raise BangelDiagnostic("IR_ARGUMENT", "Argument requires one value operand.")
        return evaluate(operands[0], environment, functions, depth, max_depth, budget)
    if kind == "unary":
        operand = evaluate(expression["operands"][0], environment, functions, depth, max_depth, budget)
        operator = expression["value"]
        if operator == "+":
            return operand
        if operator == "not":
            truth = _truth(operand)
            return None if truth is None else not truth
        return _quantity(operand).negate()
    if kind == "binary":
        operator = expression["value"]
        left = evaluate(expression["operands"][0], environment, functions, depth, max_depth, budget)
        if operator in {"and", "or"}:
            left_truth = _truth(left)
            if operator == "and" and left_truth is False:
                return False
            if operator == "or" and left_truth is True:
                return True
            right_truth = _truth(
                evaluate(expression["operands"][1], environment, functions, depth, max_depth, budget)
            )
            if operator == "and":
                return False if right_truth is False else None if left_truth is None or right_truth is None else True
            return True if right_truth is True else None if left_truth is None or right_truth is None else False
        right = evaluate(expression["operands"][1], environment, functions, depth, max_depth, budget)
        if operator in {"+", "-", "*", "/"}:
            lq, rq = _quantity(left), _quantity(right)
            if operator == "+":
                return lq.add(rq)
            if operator == "-":
                return lq.add(rq, -1)
            return lq.multiply(rq, divide=operator == "/")
        if operator in {"==", "!="} and not isinstance(left, Quantity) and not isinstance(right, Quantity):
            return left == right if operator == "==" else left != right
        return _quantity(left).compare(_quantity(right), operator)
    if kind == "call":
        encoded_target = expression["value"]
        name = (
            encoded_target.get("target")
            if isinstance(encoded_target, dict)
            else encoded_target
        )
        if not isinstance(name, str):
            raise BangelDiagnostic("IR_CALL", "Call target must resolve to a string identity.")
        arguments = [
            evaluate(item, environment, functions, depth, max_depth, budget)
            for item in expression.get("operands", [])
        ]
        function_name = name
        if function_name not in functions and name.rsplit(".", 1)[-1] in functions:
            function_name = name.rsplit(".", 1)[-1]
        if function_name in functions:
            if depth >= max_depth:
                raise BangelDiagnostic("FUNCTION_DEPTH", f"Function call depth exceeds {max_depth}.")
            function = functions[function_name]
            params = function["params"]
            if len(arguments) != len(params):
                raise BangelDiagnostic("ARGUMENT_COUNT", f"{name}() accepts {len(params)} argument(s).")
            local = dict(function["closure"])
            local.update(zip(params, arguments, strict=True))
            return evaluate(function["expression"], local, functions, depth + 1, max_depth, budget)
        builtin_name = name.rsplit(".", 1)[-1]
        if builtin_name == "node_variance":
            builtin_name = "variance"
        return call_builtin(builtin_name, arguments)
    raise BangelDiagnostic("EXPRESSION_KIND", f"Unknown expression kind {kind!r}.")


def _quantities(arguments: list[Any], name: str) -> list[Quantity]:
    if len(arguments) == 1 and isinstance(arguments[0], tuple | list):
        arguments = list(arguments[0])
    if not arguments:
        raise BangelDiagnostic("ARGUMENT_COUNT", f"{name}() requires arguments.")
    return [_quantity(item) for item in arguments]


def _aggregate(name: str, arguments: list[Any]) -> Quantity:
    quantities = _quantities(arguments, name)
    first = quantities[0]
    for item in quantities[1:]:
        first._same_dimension(item)
    if any(item.is_unknown for item in quantities):
        return Quantity.unknown(first.display_unit)
    values = [item.magnitude_si for item in quantities]
    assert all(value is not None for value in values)
    if name == "min":
        selected = min(values)
    elif name == "max":
        selected = max(values)
    else:
        selected = sum(values, Decimal(0))
        if name == "mean":
            selected /= len(values)
    return Quantity(selected, first.dimension, first.display_unit)


def call_builtin(name: str, arguments: list[Any]) -> Any:
    if name == "is_known":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "is_known() accepts one argument.")
        value = arguments[0]
        return value is not None and not (isinstance(value, Quantity) and value.is_unknown)
    if name == "nominal":
        if len(arguments) != 1 or not isinstance(arguments[0], Quantity):
            raise BangelDiagnostic("ARGUMENT_COUNT", "nominal() accepts one Measurement.")
        value = arguments[0]
        return Quantity(value.magnitude_si, value.dimension, value.display_unit, signed_delta=value.signed_delta)
    if name == "uncertainty":
        if len(arguments) != 1 or not isinstance(arguments[0], Quantity):
            raise BangelDiagnostic("ARGUMENT_COUNT", "uncertainty() accepts one Measurement.")
        value = arguments[0]
        if value.uncertainty_si is None:
            raise BangelDiagnostic("UNCERTAINTY_REQUIRED", "Measurement has no runtime uncertainty.")
        return Quantity(value.uncertainty_si, value.dimension, value.display_unit)
    if name == "convert":
        if len(arguments) != 2 or not isinstance(arguments[0], Quantity) or not isinstance(arguments[1], str):
            raise BangelDiagnostic("ARGUMENT_COUNT", "convert() accepts a physical value and unit text.")
        value, unit_text = arguments
        unit = require_unit(unit_text)
        if unit.dimension != value.dimension:
            raise BangelDiagnostic("DIMENSION_MISMATCH", "convert() unit dimension differs from its value.")
        return Quantity(value.magnitude_si, value.dimension, unit_text, value.uncertainty_si, value.signed_delta)
    if name == "unknown":
        if len(arguments) == 0:
            return Quantity.unknown()
        if len(arguments) != 1 or not isinstance(arguments[0], str):
            raise BangelDiagnostic("UNKNOWN_ARGUMENT", "unknown() accepts an optional unit string.")
        return Quantity.unknown(arguments[0])
    if name == "abs":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "abs() accepts one argument.")
        value = _quantity(arguments[0])
        if value.is_unknown or value.magnitude_si is None:
            return value
        return Quantity(abs(value.magnitude_si), value.dimension, value.display_unit, value.uncertainty_si, value.signed_delta)
    if name in {"min", "max", "mean", "sum"}:
        return _aggregate(name, arguments)
    if name == "length":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "length() accepts one vector.")
        return Quantity.known(Decimal(len(_vector(arguments[0], name))))
    if name == "at":
        if len(arguments) != 2:
            raise BangelDiagnostic("ARGUMENT_COUNT", "at() accepts a vector and index.")
        values = _vector(arguments[0], name)
        index = _integer(arguments[1], name)
        if index < 0 or index >= len(values):
            raise BangelDiagnostic("VECTOR_INDEX", "Vector index is outside its bounds.")
        return values[index]
    if name == "dot":
        if len(arguments) != 2:
            raise BangelDiagnostic("ARGUMENT_COUNT", "dot() accepts two vectors.")
        left, right = _vector(arguments[0], name), _vector(arguments[1], name)
        if len(left) != len(right) or not left:
            raise BangelDiagnostic("VECTOR_LENGTH", "dot() requires equal non-empty vector lengths.")
        products = [_quantity(a).multiply(_quantity(b)) for a, b in zip(left, right, strict=True)]
        return _aggregate("sum", products)
    if name == "norm":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "norm() accepts one vector.")
        values = _vector(arguments[0], name)
        if not values:
            raise BangelDiagnostic("VECTOR_LENGTH", "norm() requires a non-empty vector.")
        squares = [_quantity(item).multiply(_quantity(item)) for item in values]
        return call_builtin("sqrt", [_aggregate("sum", squares)])
    if name == "select":
        if len(arguments) != 3:
            raise BangelDiagnostic("ARGUMENT_COUNT", "select() accepts condition, true value, and false value.")
        truth = _truth(arguments[0])
        if truth is not None:
            return arguments[1] if truth else arguments[2]
        left, right = arguments[1], arguments[2]
        if isinstance(left, Quantity) and isinstance(right, Quantity):
            left._same_dimension(right)
            return Quantity.unknown(left.display_unit)
        return None
    if name == "sqrt":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "sqrt() accepts one quantity.")
        value = _quantity(arguments[0])
        if any(power % 2 for power in value.dimension):
            raise BangelDiagnostic("SQRT_DIMENSION", "sqrt() requires even dimension exponents.")
        if value.is_unknown or value.magnitude_si is None:
            return Quantity(None, tuple(power // 2 for power in value.dimension), "1")
        if value.magnitude_si < 0:
            raise BangelDiagnostic("SQRT_NEGATIVE", "sqrt() does not admit a negative quantity.")
        return Quantity(value.magnitude_si.sqrt(), tuple(power // 2 for power in value.dimension), "1")
    if name == "moving_mean":
        if len(arguments) != 2:
            raise BangelDiagnostic("ARGUMENT_COUNT", "moving_mean() accepts a vector and window.")
        values = _vector(arguments[0], name)
        window = _integer(arguments[1], name)
        if window <= 0 or window > len(values):
            raise BangelDiagnostic("WINDOW_BOUNDS", "Moving-mean window is outside vector bounds.")
        return tuple(_aggregate("mean", list(values[index:index + window])) for index in range(len(values) - window + 1))
    if name == "slope":
        if len(arguments) != 2:
            raise BangelDiagnostic("ARGUMENT_COUNT", "slope() accepts x and y vectors.")
        xs, ys = _vector(arguments[0], name), _vector(arguments[1], name)
        if len(xs) != len(ys) or len(xs) < 2:
            raise BangelDiagnostic("VECTOR_LENGTH", "slope() requires equal vector lengths of at least two.")
        return _quantity(ys[-1]).add(_quantity(ys[0]), -1).multiply(
            _quantity(xs[-1]).add(_quantity(xs[0]), -1), divide=True
        )
    if name in {"variance", "shadow_speed"}:
        if len(arguments) != 2:
            raise BangelDiagnostic("ARGUMENT_COUNT", f"{name}() accepts two arguments.")
        left, right = _quantity(arguments[0]), _quantity(arguments[1])
        left._same_dimension(right)
        if left.is_unknown or right.is_unknown:
            return Quantity.unknown(left.display_unit)
        assert left.magnitude_si is not None and right.magnitude_si is not None
        return Quantity(abs(right.magnitude_si - left.magnitude_si), left.dimension, left.display_unit)
    if name == "dampen":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "dampen() accepts one argument.")
        return _quantity(arguments[0]).multiply(Quantity.known(Decimal(1) / Decimal(3)))
    if name == "step_cap":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "step_cap() accepts one dimensionless argument.")
        value = _quantity(arguments[0])
        if value.dimension != DIMENSIONLESS:
            raise BangelDiagnostic("STEP_CAP_DIMENSION", "step_cap() requires a dimensionless value.")
        if value.is_unknown or value.magnitude_si is None:
            return value
        cap = Decimal("0.1")
        return Quantity(max(-cap, min(cap, value.magnitude_si)))
    if name == "bound":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "bound() accepts one dimensionless argument.")
        value = _quantity(arguments[0])
        if value.dimension != DIMENSIONLESS:
            raise BangelDiagnostic("BOUND_DIMENSION", "bound() requires a dimensionless value.")
        if value.is_unknown or value.magnitude_si is None:
            return value
        bound = Decimal("0.9")
        return Quantity(max(-bound, min(bound, value.magnitude_si)))
    if name == "floor_challenge":
        if len(arguments) != 1:
            raise BangelDiagnostic("ARGUMENT_COUNT", "floor_challenge() accepts one mass argument.")
        mass = _quantity(arguments[0])
        if mass.dimension != MASS:
            raise BangelDiagnostic("MASS_REQUIRED", "floor_challenge() requires mass.")
        if mass.is_unknown or mass.magnitude_si is None:
            return None
        floor = Quantity.known(Decimal("23"), "mg")
        assert floor.magnitude_si is not None
        return mass.magnitude_si >= floor.magnitude_si
    if name == "signed_mass_delta":
        if len(arguments) != 2:
            raise BangelDiagnostic("ARGUMENT_COUNT", "signed_mass_delta() accepts a dimensionless magnitude and mass-unit string.")
        magnitude, unit = _quantity(arguments[0]), arguments[1]
        if magnitude.dimension != DIMENSIONLESS or magnitude.is_unknown or magnitude.magnitude_si is None:
            raise BangelDiagnostic("MASS_DELTA_VALUE", "Signed mass delta magnitude must be known and dimensionless.")
        if not isinstance(unit, str):
            raise BangelDiagnostic("MASS_DELTA_UNIT", "Signed mass delta unit must be text.")
        return Quantity.mass_delta(magnitude.magnitude_si, unit)
    raise BangelDiagnostic("FUNCTION_UNKNOWN", f"Unknown builtin {name!r}.")


def require_truth(value: Any) -> bool | None:
    return _truth(value)
