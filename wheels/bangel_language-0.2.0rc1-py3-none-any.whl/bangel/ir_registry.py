from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any

from .canonical import digest
from .diagnostics import BangelDiagnostic


REGISTRY_FREEZE = "B03.1"
REGISTRY_PROFILE = "JP-IR/1"
STRICT_A1 = "strict-a1"
COMPATIBILITY = "compatibility"

STANDARD_INSTRUCTION_KEYS = (
    "details",
    "effects",
    "expression",
    "index",
    "kind",
    "name",
    "path",
    "provenance",
    "span",
    "stage",
    "type",
)
LEGACY_INSTRUCTION_KEYS = (
    "details",
    "expression",
    "index",
    "kind",
    "name",
    "span",
    "stage",
)
VALUE_KEYS = (
    "effects",
    "kind",
    "operands",
    "provenance",
    "span",
    "type",
    "value",
)
STRICT_VALUE_KEYS = ("effects", "kind", "provenance", "span", "type")
COMPATIBILITY_VALUE_KEYS = ("kind", "span")


@dataclass(frozen=True, slots=True)
class RegistryEntry:
    kind: str
    lanes: tuple[str, ...]
    operands: tuple[str, ...]
    result_type: str
    effects: dict[str, Any]
    serialization: dict[str, Any]
    invariants: tuple[str, ...]
    failure_behavior: tuple[dict[str, str], ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "lanes": list(self.lanes),
            "operands": list(self.operands),
            "result_type": self.result_type,
            "effects": copy.deepcopy(self.effects),
            "serialization": copy.deepcopy(self.serialization),
            "invariants": list(self.invariants),
            "failure_behavior": copy.deepcopy(list(self.failure_behavior)),
        }


def _failure(diagnostic: str, behavior: str) -> dict[str, str]:
    return {"diagnostic": diagnostic, "behavior": behavior}


def _instruction(
    kind: str,
    *,
    lanes: tuple[str, ...],
    operands: tuple[str, ...],
    result_type: str,
    strict_effects: tuple[tuple[str, ...], ...] = (("pure",),),
    details: tuple[tuple[str, ...], ...] = ((),),
    expression: str = "required",
    name: str | dict[str, str] = "required",
    strict_type: str = "required",
    invariants: tuple[str, ...],
    failures: tuple[dict[str, str], ...],
    legacy: bool = False,
) -> RegistryEntry:
    keys = LEGACY_INSTRUCTION_KEYS if legacy else STANDARD_INSTRUCTION_KEYS
    compatibility_effects: list[list[str]] | str = (
        "field-absent" if legacy else [[]]
    )
    return RegistryEntry(
        kind=kind,
        lanes=lanes,
        operands=operands,
        result_type=result_type,
        effects={
            "strict_a1": [list(item) for item in strict_effects]
            if STRICT_A1 in lanes
            else "not-emitted",
            "compatibility": compatibility_effects
            if COMPATIBILITY in lanes
            else "not-emitted",
        },
        serialization={
            "required_keys": list(keys),
            "optional_keys": [],
            "expression": expression,
            "name": name,
            "type": {
                "strict_a1": strict_type if STRICT_A1 in lanes else "not-emitted",
                "compatibility": (
                    "field-absent"
                    if legacy
                    else "null"
                    if COMPATIBILITY in lanes
                    else "not-emitted"
                ),
            },
            "details_key_sets": [list(item) for item in details],
            "canonical": "compact UTF-8 JSON; object keys sorted; no trailing newline",
        },
        invariants=invariants,
        failure_behavior=(
            *failures,
            _failure(
                "IR_INSTRUCTION_SERIALIZATION",
                "Reject a rehashed instruction whose keys, expression/name form, details, or effects do not match this entry.",
            ),
        ),
    )


def _value(
    kind: str,
    *,
    lanes: tuple[str, ...],
    operands: tuple[str, ...],
    minimum: int,
    maximum: int | None,
    result_type: str,
    value_field: str,
    type_kinds: tuple[str, ...] | str,
    value_shape: str,
    invariants: tuple[str, ...],
    failures: tuple[dict[str, str], ...],
) -> RegistryEntry:
    operands_field = (
        "forbidden"
        if maximum == 0
        else "required"
        if minimum > 0
        else "optional"
    )
    return RegistryEntry(
        kind=kind,
        lanes=lanes,
        operands=operands,
        result_type=result_type,
        effects={
            "strict_a1": [["pure"]] if STRICT_A1 in lanes else "not-emitted",
            "compatibility": "implicit-pure; effects field absent"
            if COMPATIBILITY in lanes
            else "not-emitted",
        },
        serialization={
            "strict_required_keys": list(STRICT_VALUE_KEYS),
            "compatibility_required_keys": list(COMPATIBILITY_VALUE_KEYS),
            "allowed_keys": list(VALUE_KEYS),
            "value_field": value_field,
            "value_shape": value_shape,
            "operands_field": operands_field,
            "operand_count": {"minimum": minimum, "maximum": maximum},
            "type_kinds": list(type_kinds) if isinstance(type_kinds, tuple) else type_kinds,
            "canonical": "compact UTF-8 JSON; object keys sorted; no trailing newline",
        },
        invariants=invariants,
        failure_behavior=(
            *failures,
            _failure(
                "IR_VALUE_SERIALIZATION",
                "Reject a rehashed value whose fields or field forms do not match this entry.",
            ),
            _failure(
                "IR_VALUE_OPERANDS",
                "Reject a rehashed value whose operand count does not match this entry.",
            ),
        ),
    )


INSTRUCTION_SPECS = (
    _instruction(
        "let",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: initializer",),
        result_type="Strict A1 instruction.type is the resolved binding type; compatibility type is null.",
        invariants=("name is non-empty", "stage is R1", "details is empty"),
        failures=(_failure("NAME_DUPLICATE", "Elsa rejects a duplicate binding before IR emission."),),
    ),
    _instruction(
        "derive",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: initializer",),
        result_type="Strict A1 instruction.type is the resolved derived binding type; compatibility type is null.",
        invariants=("name is non-empty", "stage is N1 through N7 in source derive order", "details is empty"),
        failures=(_failure("TYPE_MISMATCH", "Elsa rejects an initializer that disagrees with its annotation before IR emission."),),
    ),
    _instruction(
        "var",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: mutable binding initializer",),
        result_type="Strict A1 instruction.type is the mandatory resolved annotation; compatibility type is null.",
        invariants=("name is non-empty", "stage is R1", "details is empty"),
        failures=(_failure("TYPE_MISMATCH", "Elsa rejects an initializer outside the annotated type."),),
    ),
    _instruction(
        "set",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: replacement value",),
        result_type="Strict A1 instruction.type is the resolved target type; compatibility type is null.",
        invariants=("name names a visible mutable binding", "stage is R1", "details is empty"),
        failures=(_failure("SET_IMMUTABLE", "Elsa rejects missing or immutable targets before IR emission."),),
    ),
    _instruction(
        "measure",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: nominal physical value", "details.uncertainty: explicit nonnegative uncertainty value"),
        result_type="Strict A1 instruction.type is Measurement[T] for the nominal physical type T; compatibility type is null.",
        strict_effects=(("pure", "evidence"),),
        details=(("uncertainty",),),
        invariants=("uncertainty is explicit", "nominal and uncertainty dimensions agree", "stage is R1"),
        failures=(_failure("UNCERTAINTY_NEGATIVE", "Elsa rejects negative direct uncertainty before IR emission."),),
    ),
    _instruction(
        "evidence",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: classified evidence value",),
        result_type="Strict A1 instruction.type is the resolved evidence binding type; compatibility type is null.",
        strict_effects=(("pure", "evidence"),),
        details=(("class",),),
        invariants=("class is MODEL, SIMULATED, OBSERVED, or EXTERNAL", "stage is R1", "authority effect remains NONE"),
        failures=(_failure("EFFECT_REQUIRED", "Elsa rejects evidence when the enclosing source omits the evidence effect."),),
    ),
    _instruction(
        "require",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: Bool or Unknown[Bool] condition",),
        result_type="null; require is a control assertion and binds no value.",
        details=(("code",),),
        name="null",
        strict_type="null",
        invariants=("details.code is an uppercase diagnostic identifier", "stage is N8"),
        failures=(_failure("HOLD", "Joanna records details.code for false and REQUIREMENT_UNKNOWN for an unknown condition."),),
    ),
    _instruction(
        "emit",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: output value",),
        result_type="null; emit binds an output rather than an IR value.",
        name={"strict_a1": "required", "compatibility": "optional"},
        strict_type="null",
        invariants=("strict A1 supplies an explicit output name", "stage is N9", "details is empty"),
        failures=(_failure("EXPRESSION_KIND", "Joanna rejects an expression kind it cannot execute; Elsa-valid but not-yet-runtime-supported values remain a B04 boundary."),),
    ),
    _instruction(
        "if",
        lanes=(STRICT_A1,),
        operands=("expression: Bool or Unknown[Bool] condition", "details.then[*]: ordered instruction list", "details.else[*]: ordered instruction list"),
        result_type="null; branch bodies communicate only through their contained instructions.",
        strict_effects=(("pure",), ("pure", "evidence")),
        details=(("else", "then"),),
        name="null",
        strict_type="null",
        invariants=("both arms are serialized", "nested paths are unique", "stage is N1"),
        failures=(_failure("TYPE_MISMATCH", "Elsa rejects a condition that is neither Bool nor Unknown[Bool]."), _failure("INSTRUCTION_KIND", "Current Joanna execution of strict branch instructions is deferred to B04.")),
    ),
    _instruction(
        "for",
        lanes=(STRICT_A1,),
        operands=("expression: bounded Vector iterable", "details.body[*]: ordered instruction list"),
        result_type="null; loop execution binds no instruction result.",
        strict_effects=(("pure",), ("pure", "evidence")),
        details=(("body", "item_type", "limit"),),
        invariants=("name is the loop item", "limit is 1 through 65536", "item_type matches the Vector item", "stage is N1"),
        strict_type="null",
        failures=(_failure("LOOP_BOUND", "Elsa rejects missing, zero, negative, or excessive bounds."), _failure("INSTRUCTION_KIND", "Current Joanna execution of strict loop instructions is deferred to B04.")),
    ),
    _instruction(
        "match",
        lanes=(STRICT_A1,),
        operands=("expression: Result or enum scrutinee", "details.cases[*].body[*]: ordered instruction list"),
        result_type="null; case bodies communicate only through their contained instructions.",
        strict_effects=(("pure",), ("pure", "evidence")),
        details=(("cases",),),
        name="null",
        strict_type="null",
        invariants=("cases are exhaustive and unique", "tags and bindings are explicit", "nested paths are unique", "stage is N1"),
        failures=(_failure("MATCH_NONEXHAUSTIVE", "Elsa rejects an incomplete case set before IR emission."), _failure("INSTRUCTION_KIND", "Current Joanna execution of strict match instructions is deferred to B04.")),
    ),
    _instruction(
        "function",
        lanes=(STRICT_A1, COMPATIBILITY),
        operands=("expression: return expression", "strict details.body[*]: ordered pre-return instructions", "strict details.parameters[*]: typed parameters", "strict details.captures[*]: explicit immutable captures"),
        result_type="Strict A1 instruction.type and details.return_type are the resolved return type; compatibility type is null.",
        details=(("params",), ("body", "call_depth", "call_depth_limit", "captures", "parameters", "params", "return_type", "target")),
        invariants=("parameter order is source order", "captures are explicit", "call_depth is 1 through 64", "stage is R1"),
        failures=(_failure("RECURSION_UNSUPPORTED", "Elsa rejects direct or mutual recursion and depth above 64."),),
    ),
    _instruction(
        "node",
        lanes=(COMPATIBILITY,),
        operands=("expression: compatibility node value",),
        result_type="null in compatibility IR.",
        details=(("mode", "node"),),
        name="null",
        invariants=("compatibility-only", "node is a recognized logical node", "physical effect remains NONE"),
        failures=(_failure("NODE_ORDER", "Compatibility analysis rejects backward node order."),),
    ),
    _instruction(
        "mirror",
        lanes=(COMPATIBILITY,),
        operands=("expression: compatibility mirror value",),
        result_type="null in compatibility IR.",
        details=(("kind", "source", "target"),),
        name="null",
        invariants=("compatibility-only", "source precedes target", "physical effect remains NONE"),
        failures=(_failure("MIRROR_ORDER", "Compatibility analysis rejects a backward mirror edge."),),
    ),
    _instruction(
        "collect",
        lanes=(COMPATIBILITY,),
        operands=("details.node: previously evaluated compatibility node",),
        result_type="null in compatibility IR; runtime stores the collected node value under name.",
        details=(("kind", "node"),),
        expression="null",
        invariants=("compatibility-only", "name is non-empty", "stage is N9", "physical effect remains NONE"),
        failures=(_failure("COLLECT_NODE", "Analysis/runtime rejects a collector whose node has no prior value."),),
    ),
    _instruction(
        "role",
        lanes=(COMPATIBILITY,),
        operands=("expression: descriptive role value",),
        result_type="null in compatibility IR.",
        invariants=("compatibility-only", "name is non-empty", "stage is R1", "authority effect remains NONE"),
        failures=(_failure("EXPRESSION_REQUIRED", "Joanna rejects a role without an expression."),),
    ),
    _instruction(
        "legacy_operation",
        lanes=(COMPATIBILITY,),
        operands=("details.operation: admitted Bangel 0.1 operation text", "details.input_root: prior 64-hex root"),
        result_type="null; the operation produces a HOLD event, not a value.",
        details=(("compatibility", "generation", "input_root", "operation"),),
        expression="null",
        name="null",
        invariants=("Bangel-0.1 compatibility-only", "generation is 1", "execution performs no physical action"),
        failures=(_failure("PHYSICAL_PROVIDER_UNAVAILABLE", "Joanna deterministically holds every admitted legacy operation without a provider."),),
        legacy=True,
    ),
)


VALUE_SPECS = (
    _value(
        "literal", lanes=(STRICT_A1, COMPATIBILITY), operands=(), minimum=0, maximum=0,
        result_type="Strict A1 type is Bool or Text; compatibility is dynamically represented.",
        value_field="required", type_kinds=("Bool", "Text"), value_shape="Bool or Text JSON scalar",
        invariants=("numbers are represented by quantity, not literal",),
        failures=(_failure("TYPE_MISMATCH", "Elsa rejects a literal outside its expected type."),),
    ),
    _value(
        "quantity", lanes=(STRICT_A1, COMPATIBILITY), operands=(), minimum=0, maximum=0,
        result_type="Int, Real, or Quantity[unit] as recorded in type.",
        value_field="required", type_kinds=("Int", "Real", "Quantity"), value_shape="object with exact magnitude and unit string fields",
        invariants=("magnitude is finite canonical decimal text", "unit is registered or exactly matches resolved compound-unit metadata"),
        failures=(_failure("IR_QUANTITY", "Verifier rejects nonfinite magnitudes and unregistered or inconsistent units."),),
    ),
    _value(
        "name", lanes=(STRICT_A1, COMPATIBILITY), operands=(), minimum=0, maximum=0,
        result_type="Resolved binding type in strict A1; compatibility lookup is dynamic.",
        value_field="required", type_kinds="any-resolved-type", value_shape="non-empty identifier string",
        invariants=("strict A1 provenance identifies the resolved symbol",),
        failures=(_failure("NAME_UNRESOLVED", "Elsa rejects an unresolved strict A1 name before IR emission."), _failure("NAME_UNBOUND", "Compatibility runtime rejects a missing environment binding.")),
    ),
    _value(
        "reference", lanes=(STRICT_A1,), operands=(), minimum=0, maximum=0,
        result_type="Resolved imported symbol type.",
        value_field="required", type_kinds="any-resolved-type", value_shape="object with exact source, symbol_kind, and target string fields",
        invariants=("target is canonical and agrees with provenance.reference",),
        failures=(_failure("NAME_UNRESOLVED", "Elsa rejects missing or private imported symbols."),),
    ),
    _value(
        "vector", lanes=(STRICT_A1, COMPATIBILITY), operands=("operands[*]: item values in source order",), minimum=0, maximum=None,
        result_type="Vector[T; n] or Vector[T] in strict A1.",
        value_field="forbidden", type_kinds=("Vector",), value_shape="field absent",
        invariants=("strict item types are homogeneous", "strict fixed size matches operand count"),
        failures=(_failure("TYPE_MISMATCH", "Elsa rejects heterogeneous strict vectors."),),
    ),
    _value(
        "map", lanes=(STRICT_A1,), operands=("operands[*]: map_entry values in ascending Unicode key order",), minimum=0, maximum=None,
        result_type="Map[Text, T].", value_field="forbidden", type_kinds=("Map",), value_shape="field absent",
        invariants=("keys are unique", "entries are sorted by key", "value types are homogeneous"),
        failures=(_failure("CLOSED_SCHEMA_VIOLATION", "Elsa rejects duplicate keys."),),
    ),
    _value(
        "map_entry", lanes=(STRICT_A1,), operands=("operands[0]: mapped value",), minimum=1, maximum=1,
        result_type="Same resolved type as operands[0].", value_field="required", type_kinds="any-resolved-type",
        value_shape="object with exact key string field", invariants=("key is unique in its enclosing map",),
        failures=(_failure("CLOSED_SCHEMA_VIOLATION", "Elsa rejects duplicate enclosing map keys."),),
    ),
    _value(
        "argument", lanes=(STRICT_A1,), operands=("operands[0]: argument value",), minimum=1, maximum=1,
        result_type="Same resolved type as operands[0].", value_field="required", type_kinds="any-resolved-type",
        value_shape="object with exact name field containing a string or null", invariants=("named arguments are reordered to declared parameter/field order",),
        failures=(_failure("ARGUMENT_COUNT", "Elsa rejects missing or extra arguments."),),
    ),
    _value(
        "unary", lanes=(STRICT_A1, COMPATIBILITY), operands=("operands[0]: operand",), minimum=1, maximum=1,
        result_type="Operator-specific resolved scalar, physical, or Unknown type.", value_field="required",
        type_kinds="any-resolved-type", value_shape="operator string: +, -, or not",
        invariants=("operator is closed", "signed literal metadata retains the enclosing resolved type"),
        failures=(_failure("OPERATOR_TYPE", "Elsa rejects an operator not defined for the operand type."),),
    ),
    _value(
        "binary", lanes=(STRICT_A1, COMPATIBILITY), operands=("operands[0]: left", "operands[1]: right"), minimum=2, maximum=2,
        result_type="Operator-specific resolved scalar, physical, Bool, Measurement, MassDelta, or Unknown type.",
        value_field="required", type_kinds="any-resolved-type", value_shape="closed binary operator string",
        invariants=("operand order is left then right", "physical dimensions obey the frozen table", "Measurement multiplication/division is never emitted"),
        failures=(_failure("UNCERTAINTY_PROPAGATION_POLICY", "Elsa rejects Measurement multiplication and division; no propagation formula is invented."), _failure("DIMENSION_MISMATCH", "Elsa rejects invalid physical dimensions.")),
    ),
    _value(
        "call", lanes=(STRICT_A1, COMPATIBILITY), operands=("operands[*]: strict argument wrappers or compatibility positional values",), minimum=0, maximum=None,
        result_type="Resolved callable return type in strict A1; compatibility result is dynamic.",
        value_field="required", type_kinds="any-resolved-type", value_shape="strict target object or compatibility target string",
        invariants=("strict target is canonical", "strict operands follow declared order", "strict calls contribute to depth metadata"),
        failures=(_failure("ARGUMENT_COUNT", "Elsa/runtime rejects arity mismatch."), _failure("FUNCTION_DEPTH", "Joanna rejects compatibility execution beyond its configured depth.")),
    ),
    _value(
        "mass_delta", lanes=(STRICT_A1,), operands=("operands[0]: known dimensionless signed magnitude",), minimum=1, maximum=1,
        result_type="MassDelta[mass-unit].", value_field="required", type_kinds=("MassDelta",),
        value_shape="object with exact unit string field", invariants=("unit dimension is mass", "negative magnitude is valid", "value.unit equals type.unit.text"),
        failures=(_failure("IR_MASS_DELTA", "Verifier rejects inconsistent value/type unit metadata."),),
    ),
    _value(
        "unknown", lanes=(STRICT_A1,), operands=(), minimum=0, maximum=0,
        result_type="Unknown[T] with exactly one resolved underlying type T.", value_field="required", type_kinds=("Unknown",),
        value_shape="object with exact reason field containing Text or null", invariants=("unknown is typed", "reason is descriptive only"),
        failures=(_failure("IR_UNKNOWN", "Verifier rejects an Unknown without exactly one underlying type."),),
    ),
    _value(
        "index", lanes=(STRICT_A1,), operands=("operands[0]: Vector or Map", "operands[1]: Int index or Text key"), minimum=2, maximum=2,
        result_type="Result[T].", value_field="forbidden", type_kinds=("Result",), value_shape="field absent",
        invariants=("out-of-range/missing lookup remains a Result value, not an unchecked trap"),
        failures=(_failure("TYPE_MISMATCH", "Elsa rejects an index/key of the wrong type."), _failure("EXPRESSION_KIND", "Current Joanna execution of index is deferred to B04.")),
    ),
    _value(
        "field", lanes=(STRICT_A1,), operands=("operands[0]: record or structured target",), minimum=1, maximum=1,
        result_type="Resolved declared field type.", value_field="required", type_kinds="any-resolved-type",
        value_shape="field-name string", invariants=("field exists in the closed target schema",),
        failures=(_failure("CLOSED_SCHEMA_VIOLATION", "Elsa rejects a missing field."), _failure("EXPRESSION_KIND", "Current Joanna execution of field access is deferred to B04.")),
    ),
    _value(
        "result", lanes=(STRICT_A1,), operands=("operands[0]: Ok payload or Failure payload",), minimum=1, maximum=1,
        result_type="Result[T].", value_field="required", type_kinds=("Result",), value_shape="object with exact variant field: Ok or Err",
        invariants=("Ok carries T", "Err carries Failure"),
        failures=(_failure("CLOSED_SCHEMA_VIOLATION", "Elsa rejects an invalid Result variant or payload."), _failure("EXPRESSION_KIND", "Current Joanna execution of Result is deferred to B04.")),
    ),
    _value(
        "failure", lanes=(STRICT_A1,), operands=("operands[0]: named code Text argument", "operands[1]: named message Text argument"), minimum=2, maximum=2,
        result_type="Failure.", value_field="forbidden", type_kinds=("Failure",), value_shape="field absent",
        invariants=("arguments are ordered code then message",),
        failures=(_failure("CLOSED_SCHEMA_VIOLATION", "Elsa rejects missing, duplicate, or unknown Failure fields."), _failure("EXPRESSION_KIND", "Current Joanna execution of Failure is deferred to B04.")),
    ),
    _value(
        "record", lanes=(STRICT_A1,), operands=("operands[*]: named field arguments in declaration order",), minimum=0, maximum=None,
        result_type="Nominal Record identity recorded in type.", value_field="required", type_kinds=("Record",),
        value_shape="object with exact identity and name string fields", invariants=("identity resolves exactly one record definition", "field arity/order matches its closed schema"),
        failures=(_failure("CLOSED_SCHEMA_VIOLATION", "Elsa rejects missing, extra, duplicate, or unknown record fields."), _failure("EXPRESSION_KIND", "Current Joanna execution of records is deferred to B04.")),
    ),
    _value(
        "enum", lanes=(STRICT_A1,), operands=("operands[*]: named payload fields in variant declaration order",), minimum=0, maximum=None,
        result_type="Nominal Enum identity recorded in type.", value_field="required", type_kinds=("Enum",),
        value_shape="object with exact identity, name, and variant string fields", invariants=("identity resolves exactly one enum definition", "variant exists", "payload arity/order matches its closed schema"),
        failures=(_failure("CLOSED_SCHEMA_VIOLATION", "Elsa rejects an unknown variant or invalid payload fields."), _failure("EXPRESSION_KIND", "Current Joanna execution of enums is deferred to B04.")),
    ),
)


def _unique(entries: tuple[RegistryEntry, ...], category: str) -> dict[str, RegistryEntry]:
    result: dict[str, RegistryEntry] = {}
    for entry in entries:
        if entry.kind in result:
            raise RuntimeError(f"Duplicate JP-IR/1 {category} registry entry {entry.kind!r}.")
        result[entry.kind] = entry
    return dict(sorted(result.items()))


INSTRUCTION_REGISTRY = _unique(INSTRUCTION_SPECS, "instruction")
VALUE_REGISTRY = _unique(VALUE_SPECS, "value")


def registry_document() -> dict[str, Any]:
    return {
        "profile": REGISTRY_PROFILE,
        "freeze": REGISTRY_FREEZE,
        "identities": {
            "language": "Bangel/1.0",
            "compiler": "Elsa/1",
            "ir": "JP-IR/1",
            "runtime": "Joanna/1",
            "api": "BANGEL-API/1",
        },
        "instruction_entries": [
            INSTRUCTION_REGISTRY[kind].to_dict() for kind in INSTRUCTION_REGISTRY
        ],
        "value_entries": [VALUE_REGISTRY[kind].to_dict() for kind in VALUE_REGISTRY],
    }


REGISTRY_SHA256 = digest(registry_document())


def registry_identity() -> dict[str, str]:
    return {
        "profile": REGISTRY_PROFILE,
        "freeze": REGISTRY_FREEZE,
        "sha256": REGISTRY_SHA256,
    }


def _serialization_error(category: str, message: str) -> BangelDiagnostic:
    return BangelDiagnostic(f"IR_{category}_SERIALIZATION", message)


def verify_registered_instruction(instruction: dict[str, Any], *, strict: bool) -> None:
    kind = instruction.get("kind")
    entry = INSTRUCTION_REGISTRY.get(kind) if isinstance(kind, str) else None
    if entry is None:
        raise BangelDiagnostic(
            "IR_INSTRUCTION_KIND", f"JP-IR instruction kind {kind!r} is not registered."
        )
    lane = STRICT_A1 if strict else COMPATIBILITY
    if lane not in entry.lanes:
        raise BangelDiagnostic(
            "IR_INSTRUCTION_LANE",
            f"JP-IR instruction {kind!r} is not registered for {lane}.",
        )
    required = set(entry.serialization["required_keys"])
    actual = set(instruction)
    if actual != required:
        raise _serialization_error(
            "INSTRUCTION",
            f"JP-IR instruction {kind!r} must use exactly {sorted(required)!r}.",
        )
    expression_rule = entry.serialization["expression"]
    expression = instruction.get("expression")
    if expression_rule == "required" and not isinstance(expression, dict):
        raise _serialization_error("INSTRUCTION", f"{kind} requires an expression object.")
    if expression_rule == "forbidden" and "expression" in instruction:
        raise _serialization_error("INSTRUCTION", f"{kind} forbids the expression field.")
    if expression_rule == "null" and expression is not None:
        raise _serialization_error("INSTRUCTION", f"{kind} requires a null expression.")
    name_rule = entry.serialization["name"]
    if isinstance(name_rule, dict):
        name_rule = name_rule["strict_a1" if strict else "compatibility"]
    name = instruction.get("name")
    if name_rule == "required" and (not isinstance(name, str) or not name):
        raise _serialization_error("INSTRUCTION", f"{kind} requires a non-empty name.")
    if name_rule == "null" and name is not None:
        raise _serialization_error("INSTRUCTION", f"{kind} requires a null name.")
    if name_rule == "optional" and name is not None and (
        not isinstance(name, str) or not name
    ):
        raise _serialization_error("INSTRUCTION", f"{kind} name must be null or non-empty.")
    type_rule = entry.serialization["type"][
        "strict_a1" if strict else "compatibility"
    ]
    encoded_type = instruction.get("type")
    if type_rule == "required" and not isinstance(encoded_type, dict):
        raise _serialization_error("INSTRUCTION", f"{kind} requires a resolved result type.")
    if type_rule == "null" and encoded_type is not None:
        raise _serialization_error("INSTRUCTION", f"{kind} requires a null result type.")
    detail_sets = {
        frozenset(keys) for keys in entry.serialization["details_key_sets"]
    }
    details = instruction.get("details")
    if not isinstance(details, dict) or frozenset(details) not in detail_sets:
        raise _serialization_error(
            "INSTRUCTION", f"{kind} details do not match a registered key set."
        )
    if strict:
        allowed_effects = {
            tuple(item) for item in entry.effects["strict_a1"]
        }
        if tuple(instruction.get("effects", ())) not in allowed_effects:
            raise _serialization_error(
                "INSTRUCTION", f"{kind} effects do not match the strict A1 registry."
            )
    elif kind != "legacy_operation" and instruction.get("effects") != []:
        raise _serialization_error(
            "INSTRUCTION", f"{kind} compatibility effects must be an empty list."
        )
    if kind == "legacy_operation":
        if type(instruction.get("index")) is not int or instruction["index"] < 0:
            raise _serialization_error("INSTRUCTION", "legacy_operation index is invalid.")
        if instruction.get("span") is not None:
            raise _serialization_error("INSTRUCTION", "legacy_operation span must be null.")
    else:
        if type(instruction.get("index")) is not int or instruction["index"] < 0:
            raise _serialization_error("INSTRUCTION", f"{kind} index is invalid.")
        if not isinstance(instruction.get("path"), list) or not instruction["path"]:
            raise _serialization_error("INSTRUCTION", f"{kind} path is invalid.")
        if not isinstance(instruction.get("span"), dict):
            raise _serialization_error("INSTRUCTION", f"{kind} span is invalid.")
        if not strict and instruction.get("provenance") is not None:
            raise _serialization_error(
                "INSTRUCTION", f"{kind} compatibility provenance must be null."
            )


def _verify_value_payload(kind: str, value: Any, *, strict: bool) -> None:
    def exact_object(keys: set[str]) -> bool:
        return isinstance(value, dict) and set(value) == keys

    valid = True
    if kind == "literal":
        valid = isinstance(value, str | bool)
    elif kind == "quantity":
        valid = exact_object({"magnitude", "unit"}) and all(
            isinstance(value[key], str) for key in ("magnitude", "unit")
        )
    elif kind in {"name", "field"}:
        valid = isinstance(value, str) and bool(value)
    elif kind == "reference":
        valid = exact_object({"source", "symbol_kind", "target"}) and all(
            isinstance(value[key], str) and bool(value[key])
            for key in ("source", "symbol_kind", "target")
        )
    elif kind in {"unary", "binary"}:
        allowed = {"+", "-", "not"} if kind == "unary" else {
            "+", "-", "*", "/", "==", "!=", "<", "<=", ">", ">=", "and", "or"
        }
        valid = value in allowed
    elif kind == "call":
        if strict:
            valid = exact_object({"source", "symbol_kind", "target"}) and all(
                value[key] is None or isinstance(value[key], str)
                for key in ("source", "symbol_kind", "target")
            ) and isinstance(value["target"], str) and bool(value["target"])
        else:
            valid = isinstance(value, str) and bool(value)
    elif kind == "mass_delta":
        valid = exact_object({"unit"}) and isinstance(value["unit"], str)
    elif kind == "unknown":
        valid = exact_object({"reason"}) and (
            value["reason"] is None or isinstance(value["reason"], str)
        )
    elif kind == "map_entry":
        valid = exact_object({"key"}) and isinstance(value["key"], str)
    elif kind == "argument":
        valid = exact_object({"name"}) and (
            value["name"] is None or isinstance(value["name"], str)
        )
    elif kind == "result":
        valid = exact_object({"variant"}) and value["variant"] in {"Ok", "Err"}
    elif kind == "record":
        valid = exact_object({"identity", "name"}) and all(
            isinstance(value[key], str) and bool(value[key])
            for key in ("identity", "name")
        )
    elif kind == "enum":
        valid = exact_object({"identity", "name", "variant"}) and all(
            isinstance(value[key], str) and bool(value[key])
            for key in ("identity", "name", "variant")
        )
    if not valid:
        raise BangelDiagnostic(
            "IR_VALUE_SHAPE", f"JP-IR value payload for {kind!r} is invalid."
        )


def verify_registered_value(expression: dict[str, Any], *, strict: bool) -> None:
    kind = expression.get("kind")
    entry = VALUE_REGISTRY.get(kind) if isinstance(kind, str) else None
    if entry is None:
        raise BangelDiagnostic(
            "IR_VALUE_KIND", f"JP-IR value kind {kind!r} is not registered."
        )
    lane = STRICT_A1 if strict else COMPATIBILITY
    if lane not in entry.lanes:
        raise BangelDiagnostic(
            "IR_VALUE_LANE", f"JP-IR value {kind!r} is not registered for {lane}."
        )
    required_key_name = (
        "strict_required_keys" if strict else "compatibility_required_keys"
    )
    required = set(entry.serialization[required_key_name])
    allowed = (
        set(entry.serialization["allowed_keys"])
        if strict
        else {"kind", "value", "operands", "span"}
    )
    actual = set(expression)
    if not required <= actual or not actual <= allowed:
        raise _serialization_error(
            "VALUE", f"JP-IR value {kind!r} has fields outside its registered form."
        )
    value_mode = entry.serialization["value_field"]
    if value_mode == "required" and "value" not in expression:
        raise _serialization_error("VALUE", f"{kind} requires the value field.")
    if value_mode == "forbidden" and "value" in expression:
        raise _serialization_error("VALUE", f"{kind} forbids the value field.")
    if "value" in expression:
        _verify_value_payload(kind, expression["value"], strict=strict)
    operands = expression.get("operands", [])
    if not isinstance(operands, list):
        raise BangelDiagnostic("IR_VALUE_OPERANDS", f"{kind} operands must be a list.")
    minimum = entry.serialization["operand_count"]["minimum"]
    maximum = entry.serialization["operand_count"]["maximum"]
    if len(operands) < minimum or (maximum is not None and len(operands) > maximum):
        raise BangelDiagnostic(
            "IR_VALUE_OPERANDS",
            f"JP-IR value {kind!r} has {len(operands)} operands; registered bounds are {minimum}..{maximum}.",
        )
    field_mode = entry.serialization["operands_field"]
    if field_mode == "forbidden" and "operands" in expression:
        raise _serialization_error("VALUE", f"{kind} forbids the operands field.")
    if field_mode == "required" and "operands" not in expression:
        raise _serialization_error("VALUE", f"{kind} requires the operands field.")
    if field_mode == "optional" and (bool(operands) != ("operands" in expression)):
        raise _serialization_error(
            "VALUE", f"{kind} must omit empty operands and include non-empty operands."
        )
    if strict:
        if expression.get("effects") != ["pure"]:
            raise _serialization_error("VALUE", f"{kind} effects must be ['pure'].")
        type_kinds = entry.serialization["type_kinds"]
        encoded_type = expression.get("type")
        if type_kinds != "any-resolved-type" and (
            not isinstance(encoded_type, dict)
            or encoded_type.get("kind") not in type_kinds
        ):
            raise BangelDiagnostic(
                "IR_VALUE_TYPE", f"JP-IR value {kind!r} has an unregistered result type."
            )
    elif not isinstance(expression.get("span"), dict):
        raise _serialization_error("VALUE", f"{kind} compatibility span is invalid.")
    if kind == "map":
        keys = [
            item.get("value", {}).get("key") if isinstance(item, dict) else None
            for item in operands
        ]
        if any(not isinstance(item, str) for item in keys) or keys != sorted(set(keys)):
            raise BangelDiagnostic(
                "IR_VALUE_INVARIANT", "JP-IR map keys must be unique and sorted."
            )
    if kind == "failure":
        names = [
            item.get("value", {}).get("name") if isinstance(item, dict) else None
            for item in operands
        ]
        if names != ["code", "message"]:
            raise BangelDiagnostic(
                "IR_VALUE_INVARIANT", "JP-IR Failure fields must be code then message."
            )
