from __future__ import annotations

from dataclasses import dataclass, field

from .diagnostics import BangelDiagnostic
from .identity import CANONICAL_PATH, Stage


STATE_MEANINGS = {
    Stage.R0: "Raw pre-observational origin",
    Stage.R: "Canonical identity and normalization",
    Stage.R1: "Unidentified transition",
    Stage.N1: "First prediction node",
    Stage.N2: "Prediction refinement node",
    Stage.N3: "Propagation node",
    Stage.N4: "Capture and allocation node",
    Stage.N5: "Comparison node",
    Stage.N6: "Variance and correction node",
    Stage.N7: "Bounded result node",
    Stage.N8: "Verification and challenge node",
    Stage.N9: "Evidence presentation node",
    Stage.R2: "Living static",
}


@dataclass(slots=True)
class Traversal:
    events: list[dict[str, object]] = field(default_factory=list)
    last_node: int = 0

    def enter(self, stage: Stage, instruction: int | None, action: str) -> None:
        if stage.name.startswith("N"):
            number = int(stage.value[1:])
            if number < self.last_node:
                raise BangelDiagnostic("TRAVERSAL_BACKWARD", "Runtime traversal cannot move backward.")
            self.last_node = number
        self.events.append({
            "stage": stage.value,
            "meaning": STATE_MEANINGS[stage],
            "instruction": instruction,
            "action": action,
        })

    def complete(self) -> None:
        grouped: dict[str, list[dict[str, object]]] = {}
        for event in self.events:
            grouped.setdefault(str(event["stage"]), []).append(event)
        ordered: list[dict[str, object]] = []
        for stage in CANONICAL_PATH:
            if stage.value in grouped:
                ordered.extend(grouped[stage.value])
            else:
                ordered.append({
                    "stage": stage.value,
                    "meaning": STATE_MEANINGS[stage],
                    "instruction": None,
                    "action": "injected_path_marker",
                })
        self.events[:] = ordered
