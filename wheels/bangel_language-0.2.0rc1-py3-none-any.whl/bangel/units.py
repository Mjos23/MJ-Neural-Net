from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from .diagnostics import BangelDiagnostic


Dimension = tuple[int, int, int, int, int]
DIMENSIONLESS: Dimension = (0, 0, 0, 0, 0)
MASS: Dimension = (1, 0, 0, 0, 0)
LENGTH: Dimension = (0, 1, 0, 0, 0)
TIME: Dimension = (0, 0, 1, 0, 0)
CURRENT: Dimension = (0, 0, 0, 1, 0)
TEMPERATURE: Dimension = (0, 0, 0, 0, 1)


@dataclass(frozen=True, slots=True)
class Unit:
    symbol: str
    dimension: Dimension
    scale: Decimal


UNITS: dict[str, Unit] = {
    "1": Unit("1", DIMENSIONLESS, Decimal("1")),
    "kg": Unit("kg", MASS, Decimal("1")),
    "g": Unit("g", MASS, Decimal("0.001")),
    "mg": Unit("mg", MASS, Decimal("0.000001")),
    "m": Unit("m", LENGTH, Decimal("1")),
    "cm": Unit("cm", LENGTH, Decimal("0.01")),
    "mm": Unit("mm", LENGTH, Decimal("0.001")),
    "s": Unit("s", TIME, Decimal("1")),
    "ms": Unit("ms", TIME, Decimal("0.001")),
    "A": Unit("A", CURRENT, Decimal("1")),
    "K": Unit("K", TEMPERATURE, Decimal("1")),
    "Hz": Unit("Hz", (0, 0, -1, 0, 0), Decimal("1")),
    "Pa": Unit("Pa", (1, -1, -2, 0, 0), Decimal("1")),
    "W": Unit("W", (1, 2, -3, 0, 0), Decimal("1")),
    "V": Unit("V", (1, 2, -3, -1, 0), Decimal("1")),
}


def require_unit(symbol: str) -> Unit:
    unit = UNITS.get(symbol)
    if unit is None:
        raise BangelDiagnostic("UNIT_UNKNOWN", f"Unknown unit {symbol!r}.")
    return unit


def combine_dimensions(left: Dimension, right: Dimension, sign: int) -> Dimension:
    return tuple(a + sign * b for a, b in zip(left, right, strict=True))


def dimension_text(dimension: Dimension) -> str:
    names = ("kg", "m", "s", "A", "K")
    parts = [f"{name}^{power}" for name, power in zip(names, dimension, strict=True) if power]
    return "1" if not parts else " ".join(parts)

