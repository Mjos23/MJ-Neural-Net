from __future__ import annotations

from dataclasses import dataclass
from copy import deepcopy
from typing import Any, Callable

from .canonical import canonical_bytes, digest
from .diagnostics import BangelDiagnostic
from .evaluator import EvaluationBudget, evaluate, require_truth
from .identity import COMPILER, COMPILER_PROTOCOL, PREDICTION_NODES, RUNTIME_PROTOCOL, Stage
from .ir import JPIR
from .receipts import bind_receipt, verify_receipt
from .state import Traversal
from .values import Quantity


@dataclass(frozen=True, slots=True)
class JoannaReceipt:
    value: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return deepcopy(self.value)

    def verify(self) -> None:
        verify_receipt(self.value)


class JoannaRuntime:
    name = "Joanna"
    version = "0.3.0a2"

    def __init__(
        self,
        *,
        instruction_limit: int = 4096,
        event_limit: int = 8192,
        function_depth: int = 64,
        evaluation_limit: int = 16384,
        allocation_limit: int = 1000000,
        output_limit: int = 1048576,
        receipt_limit: int = 4194304,
    ):
        limits = (instruction_limit, event_limit, function_depth, evaluation_limit, allocation_limit, output_limit, receipt_limit)
        if any(type(limit) is not int or limit <= 0 for limit in limits):
            raise BangelDiagnostic("RUNTIME_LIMIT", "Runtime limits must be positive integers.")
        self.instruction_limit = instruction_limit
        self.event_limit = event_limit
        self.function_depth = function_depth
        self.evaluation_limit = evaluation_limit
        self.allocation_limit = allocation_limit
        self.output_limit = output_limit
        self.receipt_limit = receipt_limit

    def execute(self, compilation: dict[str, Any], *, cancelled: Callable[[], bool] | None = None) -> JoannaReceipt:
        JPIR(compilation).verify()
        if cancelled is not None and cancelled():
            raise BangelDiagnostic("CANCELLED", "Execution was cancelled.")
        if compilation.get("analysis"):
            from .strict_runtime import execute_strict
            return JoannaReceipt(execute_strict(compilation, self, cancelled=cancelled))
        if (self.allocation_limit, self.output_limit, self.receipt_limit) != (1000000, 1048576, 4194304):
            raise BangelDiagnostic("RUNTIME_LIMIT_UNSUPPORTED", "Compatibility receipts retain their four-limit contract; custom allocation/output/receipt limits require strict Bangel/1.0.")
        if compilation.get("profile") != "JP-IR/1":
            raise BangelDiagnostic("IR_PROFILE", "Joanna requires JP-IR/1.")
        compiler = compilation.get("compiler", {})
        if (
            compiler.get("name") != COMPILER
            or compiler.get("protocol") != COMPILER_PROTOCOL
        ):
            raise BangelDiagnostic(
                "COMPILER_IDENTITY",
                f"Joanna admits {COMPILER_PROTOCOL} compiled IR only.",
            )
        claimed = compilation.get("program_root")
        basis = {key: value for key, value in compilation.items() if key != "program_root"}
        if not isinstance(claimed, str) or digest(basis) != claimed:
            raise BangelDiagnostic("PROGRAM_ROOT", "JP-IR program root is invalid.")
        instructions = compilation.get("instructions")
        if not isinstance(instructions, list):
            raise BangelDiagnostic("IR_INSTRUCTIONS", "JP-IR instructions must be a list.")
        if len(instructions) > self.instruction_limit:
            raise BangelDiagnostic("INSTRUCTION_LIMIT", f"Instruction count exceeds {self.instruction_limit}.")

        environment: dict[str, Any] = {}
        functions: dict[str, dict[str, Any]] = {}
        mutables: set[str] = set()
        outputs: dict[str, Any] = {}
        roles: dict[str, Any] = {}
        node_values: dict[str, Any] = {}
        evidence_records: list[dict[str, Any]] = []
        events: list[dict[str, Any]] = []
        evaluation_budget = EvaluationBudget(self.evaluation_limit, cancelled=cancelled)
        traversal = Traversal()
        traversal.enter(Stage.R0, None, "source_arrival")
        traversal.enter(Stage.R, None, "identity_normalization")
        status = "PASS"
        hold_code: str | None = None

        allocations_used = 0
        receipt_payload_bytes = 0

        def encode_value(value: Any) -> Any:
            nonlocal allocations_used
            if cancelled is not None and cancelled():
                raise BangelDiagnostic("CANCELLED", "Execution was cancelled.")
            allocations_used += 1
            if isinstance(value, str):
                allocations_used += len(value.encode("utf-8"))
            if allocations_used > self.allocation_limit:
                raise BangelDiagnostic("ALLOCATION_LIMIT", "Compatibility allocation guard exceeded.")
            if isinstance(value, Quantity):
                # Check a fixed-spelling upper bound before Decimal formatting.
                for magnitude in (value.magnitude_si, value.uncertainty_si):
                    if magnitude is not None:
                        digits, exponent = len(magnitude.as_tuple().digits), magnitude.as_tuple().exponent
                        if not isinstance(exponent, int) or max(digits + exponent, -exponent) + 16 > self.allocation_limit - allocations_used:
                            raise BangelDiagnostic("ALLOCATION_LIMIT", "Compatibility numeric spelling exceeds its allocation guard.")
                return encode_value(value.to_dict())
            if isinstance(value, tuple):
                return [encode_value(item) for item in value]
            if isinstance(value, dict):
                return {key: encode_value(item) for key, item in sorted(value.items())}
            return value

        def append_event(event: dict[str, Any]) -> None:
            nonlocal receipt_payload_bytes
            receipt_payload_bytes += len(canonical_bytes(event))
            if receipt_payload_bytes > self.receipt_limit:
                raise BangelDiagnostic("RECEIPT_LIMIT", "Compatibility receipt byte guard exceeded.")
            if len(events) >= self.event_limit:
                raise BangelDiagnostic("EVENT_LIMIT", f"Runtime event count exceeds {self.event_limit}.")
            events.append(event)

        def eval_expression(expression: dict[str, Any]) -> Any:
            return evaluate(
                expression,
                environment,
                functions,
                max_depth=self.function_depth,
                budget=evaluation_budget,
            )

        for instruction in instructions:
            if cancelled is not None and cancelled():
                raise BangelDiagnostic("CANCELLED", "Execution was cancelled.")
            if not isinstance(instruction, dict):
                raise BangelDiagnostic("IR_INSTRUCTION", "Every JP-IR instruction must be an object.")
            try:
                stage = Stage(instruction["stage"])
                index = int(instruction["index"])
                kind = instruction["kind"]
            except (KeyError, TypeError, ValueError) as exc:
                raise BangelDiagnostic("IR_INSTRUCTION", "JP-IR instruction metadata is invalid.") from exc
            traversal.enter(stage, index, kind)
            expression = instruction.get("expression")

            if kind == "function":
                if not isinstance(expression, dict):
                    raise BangelDiagnostic("FUNCTION_BODY", "Function requires an expression body.")
                params = instruction.get("details", {}).get("params", [])
                if not isinstance(params, list | tuple) or not all(isinstance(item, str) for item in params):
                    raise BangelDiagnostic("FUNCTION_PARAMETER", "Function parameters are invalid in JP-IR.")
                functions[instruction["name"]] = {
                    "params": tuple(params),
                    "expression": expression,
                    "closure": dict(environment),
                }
                append_event({"event": "function", "name": instruction["name"], "params": list(params), "pure": True, "stage": stage.value})
            elif kind in {"let", "var", "derive", "measure", "evidence"}:
                if not isinstance(expression, dict):
                    raise BangelDiagnostic("EXPRESSION_REQUIRED", f"{kind} requires an expression.")
                value = eval_expression(expression)
                uncertainty = instruction.get("details", {}).get("uncertainty")
                if kind == "measure" and uncertainty is not None:
                    if not isinstance(value, Quantity):
                        raise BangelDiagnostic("MEASURE_QUANTITY", "Measurements require a quantity.")
                    uncertainty_value = eval_expression(uncertainty)
                    if not isinstance(uncertainty_value, Quantity):
                        raise BangelDiagnostic("UNCERTAINTY_QUANTITY", "Uncertainty requires a quantity.")
                    value = value.with_uncertainty(uncertainty_value)
                name = instruction["name"]
                environment[name] = value
                if kind == "var":
                    mutables.add(name)
                event = {"event": kind, "name": name, "value": encode_value(value), "stage": stage.value}
                if kind == "evidence":
                    evidence_class = instruction.get("details", {}).get("class")
                    trust = "DERIVED" if evidence_class in {"MODEL", "SIMULATED"} else "UNATTESTED"
                    record = {"name": name, "class": evidence_class, "trust": trust, "value": encode_value(value)}
                    evidence_records.append(record)
                    event.update({"class": evidence_class, "trust": trust, "authority_effect": "NONE"})
                append_event(event)
            elif kind == "set":
                if instruction.get("name") not in mutables:
                    raise BangelDiagnostic("SET_IMMUTABLE", "Runtime set target is not mutable.")
                if not isinstance(expression, dict):
                    raise BangelDiagnostic("EXPRESSION_REQUIRED", "set requires an expression.")
                value = eval_expression(expression)
                environment[instruction["name"]] = value
                append_event({"event": "set", "name": instruction["name"], "value": encode_value(value), "stage": stage.value})
            elif kind == "require":
                if not isinstance(expression, dict):
                    raise BangelDiagnostic("EXPRESSION_REQUIRED", "require requires an expression.")
                result = require_truth(eval_expression(expression))
                if result is not True:
                    status = "HOLD"
                    hold_code = instruction["details"]["code"] if result is False else "REQUIREMENT_UNKNOWN"
                    append_event({"event": "require", "result": result, "hold_code": hold_code, "stage": stage.value})
                    break
                append_event({"event": "require", "result": True, "stage": stage.value})
            elif kind == "emit":
                if not isinstance(expression, dict):
                    raise BangelDiagnostic("EXPRESSION_REQUIRED", "emit requires an expression.")
                value = eval_expression(expression)
                name = instruction.get("name") or f"output_{len(outputs) + 1}"
                outputs[name] = encode_value(value)
                if len(canonical_bytes(outputs)) > self.output_limit:
                    raise BangelDiagnostic("OUTPUT_LIMIT", "Compatibility output byte guard exceeded.")
                append_event({"event": "emit", "name": name, "stage": stage.value})
            elif kind == "node":
                if not isinstance(expression, dict):
                    raise BangelDiagnostic("EXPRESSION_REQUIRED", "node requires an expression.")
                node = instruction["details"]["node"]
                value = eval_expression(expression)
                node_values[node] = value
                append_event({
                    "event": "node", "node": node, "mode": instruction["details"]["mode"],
                    "value": encode_value(value), "model_only": True,
                    "physical_effect": "NONE", "stage": stage.value,
                })
            elif kind == "mirror":
                if not isinstance(expression, dict):
                    raise BangelDiagnostic("EXPRESSION_REQUIRED", "mirror requires an expression.")
                append_event({
                    "event": "mirror", **instruction["details"],
                    "value": encode_value(eval_expression(expression)),
                    "model_only": True, "physical_effect": "NONE", "stage": stage.value,
                })
            elif kind == "collect":
                node = instruction["details"]["node"]
                if node not in node_values:
                    raise BangelDiagnostic("COLLECT_NODE", "Collector node has no runtime value.")
                value = node_values[node]
                environment[instruction["name"]] = value
                append_event({
                    "event": "collect", "collector": instruction["details"]["kind"], "node": node,
                    "name": instruction["name"], "value": encode_value(value),
                    "model_only": True, "physical_effect": "NONE", "stage": stage.value,
                })
            elif kind == "role":
                if not isinstance(expression, dict):
                    raise BangelDiagnostic("EXPRESSION_REQUIRED", "role requires an expression.")
                roles[instruction["name"]] = encode_value(eval_expression(expression))
                append_event({"event": "role", "name": instruction["name"], "authority_effect": "NONE", "stage": stage.value})
            elif kind == "legacy_operation":
                status = "HOLD"
                hold_code = "PHYSICAL_PROVIDER_UNAVAILABLE"
                append_event({
                    "event": "legacy_operation", **instruction["details"], "status": "HOLD",
                    "hold_code": hold_code, "stage": stage.value,
                })
            else:
                raise BangelDiagnostic("INSTRUCTION_KIND", f"Unknown instruction {kind!r}.")

        traversal.enter(Stage.R2, None, "receipt_binding_living_static")
        traversal.complete()
        receipt = bind_receipt({
            "profile": "Joanna-Receipt/1",
            "runtime": {
                "name": self.name,
                "protocol": RUNTIME_PROTOCOL,
                "version": self.version,
            },
            "program": compilation["program"],
            "program_root": compilation["program_root"],
            "status": status,
            "hold_code": hold_code,
            "outputs": outputs,
            "roles": roles,
            "evidence": evidence_records,
            "events": events,
            "traversal": traversal.events,
            "resource_limits": {
                "instruction_limit": self.instruction_limit,
                "event_limit": self.event_limit,
                "function_depth": self.function_depth,
                "evaluation_limit": self.evaluation_limit,
                "evaluations_used": evaluation_budget.used,
            },
            "state_meanings": {"R1": "Unidentified transition", "R2": "Living static", "N1": "First prediction node"},
            "prediction_nodes": [node.value for node in PREDICTION_NODES],
        })
        if len(canonical_bytes(receipt)) > self.receipt_limit:
            raise BangelDiagnostic("RECEIPT_LIMIT", "Compatibility receipt byte guard exceeded.")
        result = JoannaReceipt(receipt)
        result.verify()
        return result
