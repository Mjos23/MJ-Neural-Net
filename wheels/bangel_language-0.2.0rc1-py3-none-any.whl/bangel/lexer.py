from __future__ import annotations

import re

from .diagnostics import BangelDiagnostic, SourceSpan
from .tokens import Token, TokenKind


_TOKEN = re.compile(
    r"""
    (?P<SPACE>\s+)
  | (?P<STRING>"(?:\\.|[^"\\])*")
  | (?P<NUMBER>(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)
  | (?P<IDENT>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<OP>\+/-|±|\*\*|==|!=|<=|>=|[+\-*/<>])
  | (?P<COMMA>,)
  | (?P<LPAREN>\()
  | (?P<RPAREN>\))
  | (?P<LBRACKET>\[)
  | (?P<RBRACKET>\])
    """,
    re.VERBOSE,
)


def lex_expression(text: str, line: int, start_column: int = 1) -> tuple[Token, ...]:
    tokens: list[Token] = []
    index = 0
    while index < len(text):
        match = _TOKEN.match(text, index)
        if match is None:
            raise BangelDiagnostic(
                "LEX_CHARACTER",
                f"Unexpected character {text[index]!r}.",
                SourceSpan(line, start_column + index),
            )
        kind = match.lastgroup
        value = match.group()
        column = start_column + match.start()
        index = match.end()
        if kind == "SPACE":
            continue
        tokens.append(Token(TokenKind[kind], value, SourceSpan(line, column)))
    tokens.append(Token(TokenKind.EOF, "", SourceSpan(line, start_column + len(text))))
    return tuple(tokens)
