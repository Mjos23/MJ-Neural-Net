"""Bangel public imports, loaded lazily so JP-IR verification is independent."""
from importlib import import_module

_EXPORTS = {
    "ElsaCompilation": ".compiler", "ElsaCompiler": ".compiler",
    "ElsaProjectBuilder": ".project", "ProjectBuild": ".project",
    "SourceFile": ".frontend", "ProgramSource": ".frontend",
    "ModuleSource": ".frontend", "lex": ".frontend", "parse_source": ".frontend",
    "JoannaReceipt": ".runtime", "JoannaRuntime": ".runtime",
    "JoannaScheduler": ".scheduler", "ScheduledJob": ".scheduler",
}
__all__ = list(_EXPORTS)
__version__ = "0.2.0rc1"


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = getattr(import_module(_EXPORTS[name], __name__), name)
    globals()[name] = value
    return value


def __dir__():
    return sorted(set(globals()) | set(__all__))
