"""GIN interval calculations executed as Bangel 1.0 source.

The recovered GIN-RP001 interval mathematics is the reference. This adapter
validates input shape and emits source; Elsa and Joanna perform the arithmetic.
Physical clock calibration, the complete GIN object lifecycle, and MJ permits are
separate contracts. Missing or incomparable inputs produce non-authorizing HOLD.
"""
from __future__ import annotations

import json
from pathlib import Path
import re

from .compiler import ElsaCompiler
from .runtime import JoannaRuntime

MAX_TICK = 9007199254740991
MAX_INPUT_BYTES = 65536
_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:/-]{0,255}\Z")
_FIELDS = {"lower", "upper", "precision", "clock", "unit"}
_OPERATIONS = {
    "difference": (("later", "earlier"), ()),
    "add": (("left", "right"), ()),
    "order": (("left", "right"), ()),
    "staleness": (("evaluation", "anchor"), ("horizon",)),
    "tolerance": (("variance",), ("early", "late")),
    "normalize": (("interval",), ()),
}


class GinInputError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


def _integer(value, name):
    if value is None:
        return f'unknown[Int]("missing {name}")'
    if type(value) is not int or not -(2**63) < value < 2**63:
        raise GinInputError("GIN_INPUT_INTEGER", name + " requires an integer with magnitude below 2**63, or null.")
    return str(value)


def read_request(path):
    """Read a bounded JSON request, rejecting duplicates and nonfinite values."""
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise GinInputError("GIN_INPUT_DUPLICATE", "Duplicate key: " + key)
            result[key] = value
        return result

    def nonfinite(value):
        raise GinInputError("GIN_INPUT_NONFINITE", "Nonfinite JSON value: " + value)

    with Path(path).open("rb") as stream:
        raw = stream.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise GinInputError("GIN_INPUT_LIMIT", "Request exceeds 65536 bytes.")
    try:
        request = json.loads(raw.decode("utf-8"), object_pairs_hook=unique, parse_constant=nonfinite)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as error:
        raise GinInputError("GIN_INPUT_JSON", "A UTF-8 JSON request is required.") from error
    if type(request) is not dict:
        raise GinInputError("GIN_INPUT_SHAPE", "A JSON request object is required.")
    return request


def make_source(request):
    """Generate executable .bangel source without computing interval results."""
    if type(request) is not dict or type(request.get("operation")) is not str:
        raise GinInputError("GIN_INPUT_SHAPE", "A request object with an operation is required.")
    operation = request["operation"]
    if operation in {"temporal", "evidence"}:
        from .gin_models import make_model_source
        return make_model_source(request)
    if operation not in _OPERATIONS:
        raise GinInputError("GIN_OPERATION", "Unsupported interval operation.")
    intervals, scalars = _OPERATIONS[operation]
    extra = {"transform"} if operation == "normalize" else set()
    if set(request) != {"operation", *intervals, *scalars, *extra}:
        raise GinInputError("GIN_INPUT_SHAPE", "Request fields do not match the operation.")
    lines = ["bangel 1.0", "program gin_" + operation, "effects pure"]
    if operation == "normalize":
        from .gin_clock import BODY, FUNCTIONS, transform_source
        lines.extend(FUNCTIONS.splitlines())
    numeric = []
    for name in intervals:
        value = request[name]
        if type(value) is not dict or set(value) != _FIELDS:
            raise GinInputError("GIN_INTERVAL_INVALID", name + " requires exactly five interval fields.")
        for field in ("lower", "upper", "precision"):
            symbol = "p_" + name + "_" + field
            lines.append("let " + symbol + " = " + _integer(value[field], symbol))
            numeric.append(symbol)
        for field in ("clock", "unit"):
            if type(value[field]) is not str or not _IDENTIFIER.fullmatch(value[field]):
                raise GinInputError("GIN_IDENTITY_INVALID", name + "." + field + " requires a bounded identifier.")
            lines.append("let p_" + name + "_" + field + " = " + json.dumps(value[field]))
    for name in scalars:
        symbol = "p_" + name
        lines.append("let " + symbol + " = " + _integer(request[name], symbol))
        numeric.append(symbol)
    if operation == "normalize":
        declarations, transform_numeric, transform_guards = transform_source(request["transform"])
        lines.extend(declarations)
        numeric.extend(transform_numeric)
    # Missingness is evaluated before arithmetic, including precision checks.
    for symbol in numeric:
        lines.append(f"require is_known({symbol}) else GIN_UNKNOWN")
    for symbol in numeric:
        lines.append(f"require {symbol} >= -{MAX_TICK} and {symbol} <= {MAX_TICK} else GIN_UNSAFE_QUANTITY")
    for name in intervals:
        prefix = "p_" + name
        lines.extend([
            f"require {prefix}_precision >= 0 else GIN_QUANTITY_NEGATIVE",
            f"require {prefix}_lower <= {prefix}_upper else GIN_INTERVAL_BOUNDS",
            f"require {prefix}_precision >= {prefix}_upper - {prefix}_lower else GIN_PRECISION_FALSE",
        ])
    for name in scalars:
        lines.append(f"require p_{name} >= 0 else GIN_QUANTITY_NEGATIVE")
    if operation == "normalize":
        lines.extend(transform_guards)
    if len(intervals) == 2:
        left, right = ("p_" + name for name in intervals)
        lines.append(f"require {left}_clock == {right}_clock and {left}_unit == {right}_unit else GIN_CLOCK_INCOMPARABLE")
    body_start = len(lines)
    if operation in {"difference", "staleness", "add"}:
        if operation == "add":
            lower, upper = left + "_lower + " + right + "_lower", left + "_upper + " + right + "_upper"
        else:
            lower, upper = left + "_lower - " + right + "_upper", left + "_upper - " + right + "_lower"
        lines.extend([
            "derive lower = " + lower,
            "derive upper = " + upper,
            f"derive precision = {left}_precision + {right}_precision",
            f"require lower >= -{MAX_TICK} and lower <= {MAX_TICK} else GIN_ARITHMETIC_OVERFLOW",
            f"require upper >= -{MAX_TICK} and upper <= {MAX_TICK} else GIN_ARITHMETIC_OVERFLOW",
            f"require precision <= {MAX_TICK} else GIN_ARITHMETIC_OVERFLOW",
        ])
        if operation == "staleness":
            lines.extend([
                "if upper <= p_horizon", '  emit state = "current"',
                "else", "  if lower > p_horizon", '    emit state = "stale"',
                "  else", '    emit state = "staleness-indeterminate"', "  end", "end",
                "emit wrongdoing_inferred = false", "emit financial_risk_inferred = false",
            ])
        else:
            lines.extend(["if lower == upper", '  emit state = "known"', "else", '  emit state = "bounded"', "end"])
        lines.extend(["emit lower = lower", "emit upper = upper", "emit precision = precision",
                      "emit clock = " + left + "_clock", "emit unit = " + left + "_unit"])
    elif operation == "order":
        lines.extend([
            f"if {left}_upper < {right}_lower", '  emit state = "before"', "else",
            f"  if {left}_lower > {right}_upper", '    emit state = "after"', "  else",
            '    emit state = "overlaps"', "  end", "end",
        ])
    elif operation == "normalize":
        lines.extend(BODY.splitlines())
        if request["transform"]["calibrationEvidenceRefs"]:
            lines.append("emit calibration_evidence_refs = t_calibration_refs")
    else:
        lines.extend([
            "if p_variance_upper < -p_early", '  emit state = "early"', "else",
            "  if p_variance_lower >= -p_early and p_variance_upper <= p_late",
            '    emit state = "within-declared-window"', "  else",
            "    if p_variance_lower > p_late", '      emit state = "late"', "    else",
            '      emit state = "classification-indeterminate"', "    end", "  end", "end",
        ])
    # A1 declarations belong to a block prelude. Enter a nested block only
    # after the outer guards pass, so invalid inputs never reach arithmetic.
    return "\n".join(lines[:body_start] + ["if true"] +
                     ["  " + line for line in lines[body_start:]] + ["end"]) + "\n"


def evaluate(request, *, source_name="gin.bangel"):
    """Execute generated source through Elsa, independent JP admission, and Joanna."""
    if type(source_name) is not str or not re.fullmatch(r"[A-Za-z0-9_-]+\.bangel", source_name):
        raise GinInputError("GIN_SOURCE_NAME", "Use a simple .bangel source filename.")
    ir = ElsaCompiler().compile(source_name, make_source(request)).to_dict()
    return JoannaRuntime().execute(ir).to_dict()


def verify_expected(receipt, expected):
    """Check a receipt against an independently supplied conformance expectation."""
    if receipt["status"] != expected["status"]:
        raise ValueError("GIN receipt status differs from the expectation.")
    if receipt["authority_effect"] != "NONE" or receipt["physical_effect"] != "NONE":
        raise ValueError("GIN interval execution must not grant authority or physical effects.")
    if expected["status"] == "HOLD":
        if receipt["hold_code"] != expected["hold_code"] or receipt["outputs"]:
            raise ValueError("GIN HOLD must have the expected code and no outputs.")
        return
    if "gin_value" in expected:
        from .gin_models import model_from_receipt
        if model_from_receipt(receipt) != expected["gin_value"]:
            raise ValueError("GIN model differs from the expectation.")
        return
    outputs = receipt["outputs"]
    if set(outputs) != set(expected["outputs"]):
        raise ValueError("GIN output names differ from the expectation.")
    for name, value in expected["outputs"].items():
        actual = outputs[name]
        if type(value) is int:
            valid = actual == {"kind": "int", "value": str(value)}
        else:
            valid = actual == value and type(actual) is type(value)
        if not valid:
            raise ValueError("GIN output differs from the expectation: " + name)
