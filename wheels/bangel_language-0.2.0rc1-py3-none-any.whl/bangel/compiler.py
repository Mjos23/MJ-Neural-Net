from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .ast import Program, Statement
from .canonical import digest
from .diagnostics import BangelDiagnostic
from .frontend import (
    ProjectSemanticModel,
    SemanticModel,
    SourceFile,
    analyze_project,
    analyze_source,
    parse_source,
)
from .frontend.lower import lower_source
from .identity import COMPILER_PROTOCOL, SOURCE_EXTENSION, Stage
from .ir import JPIR, assigned_stage, build_ir
from .legacy import parse_legacy_01
from .parser import parse_program
from .semantics import analyze
from .source import normalize_source
from .topology import canonical_stage


@dataclass(frozen=True, slots=True)
class ElsaCompilation:
    ir: JPIR

    def to_dict(self) -> dict[str, Any]:
        return self.ir.to_dict()

    def to_bytes(self) -> bytes:
        return self.ir.to_bytes()

    @classmethod
    def from_bytes(cls, data: bytes) -> "ElsaCompilation":
        return cls(JPIR.from_bytes(data))


@dataclass(frozen=True, slots=True)
class ElsaSemanticCheck:
    model: SemanticModel

    def to_dict(self) -> dict[str, Any]:
        return self.model.to_dict()


@dataclass(frozen=True, slots=True)
class ElsaProjectSemanticCheck:
    model: ProjectSemanticModel

    def to_dict(self) -> dict[str, Any]:
        return self.model.to_dict()


class ElsaCompiler:
    name = "Elsa"
    protocol = COMPILER_PROTOCOL
    version = "0.3.0a2"

    compatibility_profiles = frozenset(
        {"bangel-alpha-0.3", "bangel-physics-0.1", "bangel-0.1"}
    )

    def __init__(self, *, compatibility_profile: str | None = None):
        if (
            compatibility_profile is not None
            and compatibility_profile not in self.compatibility_profiles
        ):
            raise BangelDiagnostic(
                "COMPATIBILITY_PROFILE_UNKNOWN",
                f"Unknown Elsa compatibility profile {compatibility_profile!r}.",
            )
        self.compatibility_profile = compatibility_profile

    @staticmethod
    def _require_extension(source_name: str) -> None:
        if Path(source_name).suffix != SOURCE_EXTENSION:
            raise BangelDiagnostic("SOURCE_EXTENSION", "Elsa accepts .bangel source only.")

    def parse(self, source_name: str, source: str) -> SourceFile:
        """Parse only the frozen Bangel/1.0 source surface into its typed AST."""

        self._require_extension(source_name)
        return parse_source(source, source_name=source_name)

    def check(self, source_name: str, source: str) -> ElsaSemanticCheck:
        """Parse, resolve, and type-check frozen Bangel/1.0 without lowering."""

        tree = self.parse(source_name, source)
        return ElsaSemanticCheck(analyze_source(tree))

    def check_project(self, sources: dict[str, str]) -> ElsaProjectSemanticCheck:
        """Resolve and type-check a closed offline source collection."""

        trees = tuple(
            self.parse(source_name, sources[source_name])
            for source_name in sorted(sources)
        )
        return ElsaProjectSemanticCheck(analyze_project(trees))

    def compile_project(
        self,
        sources: dict[str, str],
        *,
        entry_source_name: str | None = None,
    ) -> ElsaCompilation:
        """Link a closed A1 source set into one deterministic entry-program IR."""

        trees = tuple(
            self.parse(source_name, sources[source_name])
            for source_name in sorted(sources)
        )
        project = analyze_project(trees)
        programs = {
            model.source_name: model
            for model in project.programs
            if model.source_name is not None
        }
        candidates = sorted(programs)
        if entry_source_name is None:
            if len(candidates) != 1:
                raise BangelDiagnostic(
                    "PROJECT_ENTRY_REQUIRED",
                    "Project compilation requires exactly one program or an explicit entry source.",
                    details={"candidates": candidates},
                )
            entry_source_name = candidates[0]
        if entry_source_name not in programs:
            raise BangelDiagnostic(
                "PROJECT_ENTRY_REQUIRED",
                f"Project entry source {entry_source_name!r} is not a program in the source set.",
                details={"entry": entry_source_name, "candidates": candidates},
            )

        modules = []
        for model in project.modules:
            source_name = model.source_name
            assert source_name is not None
            normalized = sources[source_name].replace("\r\n", "\n").replace("\r", "\n")
            modules.append(
                self._module_fragment(
                    source_name,
                    normalized,
                    lower_source(model.source, model),
                )
            )

        entry_model = programs[entry_source_name]
        normalized = sources[entry_source_name].replace("\r\n", "\n").replace("\r", "\n")
        return self._compile_program(
            entry_source_name,
            normalized,
            lower_source(entry_model.source, entry_model),
            semantically_admitted=True,
            modules=modules,
        )

    def compile(
        self,
        source_name: str,
        source: str,
        *,
        compatibility_profile: str | None = None,
    ) -> ElsaCompilation:
        self._require_extension(source_name)
        compatibility = (
            compatibility_profile
            if compatibility_profile is not None
            else self.compatibility_profile
        )
        if compatibility is not None and compatibility not in self.compatibility_profiles:
            raise BangelDiagnostic(
                "COMPATIBILITY_PROFILE_UNKNOWN",
                f"Unknown Elsa compatibility profile {compatibility!r}.",
            )
        if compatibility is None:
            tree = self.parse(source_name, source)
            semantic = analyze_source(tree)
            normalized = source.replace("\r\n", "\n").replace("\r", "\n")
            return self._compile_program(
                source_name,
                normalized,
                lower_source(tree, semantic),
                semantically_admitted=True,
            )

        normalized = normalize_source(source)
        if compatibility == "bangel-0.1":
            if not normalized.lstrip().startswith("bangel 0.1\n"):
                raise BangelDiagnostic(
                    "COMPATIBILITY_PROFILE_MISMATCH",
                    "bangel-0.1 compatibility requires the 'bangel 0.1' header.",
                )
            legacy = parse_legacy_01(normalized)
            instructions = [
                {
                    "index": index,
                    "kind": "legacy_operation",
                    "stage": f"N{min(index + 1, 7)}",
                    "name": None,
                    "expression": None,
                    "details": {
                        "operation": operation,
                        "generation": legacy.generation,
                        "input_root": legacy.input_root,
                        "compatibility": "Bangel-0.1",
                    },
                    "span": None,
                }
                for index, operation in enumerate(legacy.operations)
            ]
            ir = build_ir(
                source_name=source_name,
                source_digest=digest({"source": normalized}),
                profile="bangel 0.1",
                program=f"legacy_generation_{legacy.generation}",
                effects=("pure", "evidence"),
                instructions=instructions,
                compiler_version=self.version,
            )
            ir.verify()
            return ElsaCompilation(ir)

        program = parse_program(normalized)
        allowed_profiles = {
            "bangel-alpha-0.3": {"bangel 1.0", "bangel 1.1"},
            "bangel-physics-0.1": {"bangel physics 0.1"},
        }[compatibility]
        if program.profile not in allowed_profiles:
            raise BangelDiagnostic(
                "COMPATIBILITY_PROFILE_MISMATCH",
                f"{compatibility} does not admit the {program.profile!r} source header.",
            )
        return self._compile_program(source_name, normalized, program)

    def _compile_program(
        self,
        source_name: str,
        normalized: str,
        program: Program,
        *,
        semantically_admitted: bool = False,
        modules: list[dict[str, Any]] | None = None,
    ) -> ElsaCompilation:
        admitted = program if semantically_admitted else analyze(program).program
        instructions = self._instructions(admitted)
        ir = build_ir(
            source_name=source_name,
            source_digest=digest({"source": normalized}),
            profile=admitted.profile,
            program=admitted.name,
            effects=admitted.effects,
            instructions=instructions,
            compiler_version=self.version,
            metadata=admitted.metadata,
            definitions=list(admitted.definitions),
            imports=list(admitted.imports),
            modules=modules,
        )
        ir.verify()
        return ElsaCompilation(ir)

    @classmethod
    def _instructions(cls, program: Program) -> list[dict[str, Any]]:
        instructions: list[dict[str, Any]] = []
        derive_index = 0
        for index, statement in enumerate(program.statements):
            if statement.kind == "derive":
                stage = assigned_stage(statement.kind, derive_index)
                derive_index += 1
            elif statement.kind == "node":
                stage = canonical_stage(statement.details["node"])
            elif statement.kind == "mirror":
                stage = canonical_stage(statement.details["target"])
            else:
                stage = assigned_stage(statement.kind)
            instructions.append(cls._instruction(index, statement, stage))
        return instructions

    @classmethod
    def _module_fragment(
        cls,
        source_name: str,
        normalized: str,
        module: Program,
    ) -> dict[str, Any]:
        return {
            "name": module.name,
            "source": {
                "name": source_name,
                "digest": digest({"source": normalized}),
                "profile": module.profile,
            },
            "effects": list(module.effects),
            "imports": list(module.imports),
            "exports": list(module.exports),
            "analysis": dict(module.metadata),
            "type_definitions": list(module.definitions),
            "instructions": cls._instructions(module),
        }

    @classmethod
    def _instruction(
        cls,
        index: int,
        statement: Statement,
        stage: Stage,
        path: list[int | str] | None = None,
    ) -> dict[str, Any]:
        instruction_path = [index] if path is None else path
        value: dict[str, Any] = {
            "index": index,
            "path": instruction_path,
            "kind": statement.kind,
            "stage": stage.value,
            "name": statement.name,
            "expression": statement.expression.to_ir() if statement.expression else None,
            "details": cls._encode_details(statement.details, instruction_path),
            "span": statement.span.to_dict() if statement.span else None,
            "type": statement.result_type,
            "effects": list(statement.effects),
            "provenance": statement.provenance,
        }
        return value

    @classmethod
    def _encode_details(
        cls, details: dict[str, Any], parent_path: list[int | str]
    ) -> dict[str, Any]:
        def encode(value: Any, path: list[int | str]) -> Any:
            if isinstance(value, Statement):
                stage = assigned_stage(value.kind)
                local_index = path[-1]
                assert isinstance(local_index, int)
                return cls._instruction(local_index, value, stage, path)
            if isinstance(value, tuple | list):
                return [encode(item, [*path, index]) for index, item in enumerate(value)]
            if isinstance(value, dict):
                return {
                    key: encode(item, [*path, key])
                    for key, item in sorted(value.items())
                }
            return value

        return {
            key: encode(value, [*parent_path, key])
            for key, value in sorted(details.items())
        }
